<?php
   require_once '../../global.php';    
     
   
   
   $url= $_SERVER["REQUEST_URI"];
   ?>
<div id="appcontent">
<style>
   body {
   background: rgb(233, 233, 225);
   }
</style>
<div id="b1">
   <div id="webcenter">
      <a href="<?php echo PATH ?>/shop" place="<?php echo $SHORTNAME; ?>: Comprar furnis o placas">
         <div id="b2">
            <div id="b3">
               <img alt="Página de inicio" src="<?php echo PATH ?>/app/assets/img/Shop/icone_accueil.png" />
            </div>
            Inicio
         </div>
      </a>
      <a href="<?php echo PATH ?>/shop/economy" place="<?php echo $SHORTNAME; ?>: Economía">
         <div id="b2">
            <div id="b3">
               <img alt="Página de Economía" src="<?php echo PATH ?>/app/assets/img/Shop/icone_economie.png" />
            </div>
            Economía
         </div>
      </a>
      <div onclick="BoutiquePage('Únase al VIPClub','<?php echo PATH ?>/app/load/BoutiquePage.php?page=vip');" id="b2">
         <div id="b3">
            <img alt="VipClub" src="<?php echo PATH ?>/app/assets/img/Shop/icone_vip.png" />
         </div>
         VIPClub
      </div>
      <a href="<?php echo PATH ?>/shop/lottery" place="<?php echo $SHORTNAME; ?>: Lotería">
         <div id="b2">
            <div id="b3">
               <img alt="Página de lotería" src="<?php echo PATH ?>/app/assets/img/Shop/icone_loto.png" />
            </div>
            Lotería
         </div>
      </a>
      <a href="<?php echo PATH ?>/shop/chests" place="<?php echo $SHORTNAME; ?>: Cofres">
         <div id="b2">
            <div id="b3">
               <img alt="Página de los Cofres" src="<?php echo PATH ?>/app/assets/img/Shop/icone_coffres.png" />
            </div>
            Cofres
         </div>
      </a>
      <a href="<?php echo PATH ?>/shop/badges" place="<?php echo $SHORTNAME; ?>: Comprar placas">
         <div id="b2">
            <div id="b3">
               <img alt="Página de las placas" src="<?php echo PATH ?>/app/assets/img/Shop/icone_badge.png" />
            </div>
            Placas
         </div>
      </a>
      <div onclick="BoutiquePage('Mi inventario','<?php echo PATH ?>/app/load/BoutiquePage.php?page=inventaire&type=mobis');" id="b3inven">
         <center>
            <div id="b3invenicone"></div>
         </center>
      </div>
   </div>
</div>