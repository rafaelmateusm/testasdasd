<?php
   ob_start();
   require_once '../../global.php';
   
      $Functions->Logged("allow");
      $Functions->pin("true");
   
   //HOTEL CONFIG
   $result2 = $db->query("SELECT * FROM cms_settings WHERE id = 1 LIMIT 1");
   $yezz = $result2->fetch_array();
   //END HOTEL CONFIG
   
   $users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
   $user = $users->fetch_array();
   
      $TplClass->SetAll();
   
      $TplClass->SetParam('title', $yezz['hotelname'] .': Equipo');  
      $TplClass->SetParam('description', $yezz['hotelname'] .': Equipo');
   
    	$TplClass->AddTemplate("header", "menu");
   
   ob_end_flush();
   ?>
<div id="appcontent">
   <style>
      body {
      background: rgb(238, 238, 238);
      }
   </style>
   <div id="stream29"></div>
   <div id="team1">
      <div id="team2" style="background:#EC6953">
         <h1>
         <strong>Dirección y desarrollo</strong>
         <h1>
      </div>
      <div id="team1n">
      <?php 	global $db;
					$dd = $db->query("SELECT * FROM ranks WHERE id >= 15 ORDER BY id DESC");
					while($rank = $dd->fetch_array()){
            $ru = $db->query("SELECT * FROM users WHERE rank = '". $rank['id'] ."' ORDER BY rank DESC");
            while($us = $ru->fetch_array()){
                if($us['online'] == 1){
                    $status = '#63C862';
                }else{
                    $status = '#ED1C24';
            }
            if($us['cms_staffocult'] == 0){
                if($us['rank'] == 15) {
                    $position = '-80';                
                 }elseif($us['rank'] == 16) {
                  $position = '-40';                
               }elseif($us['rank'] == 17) {
                $position = '0';                
             }
            ?>
         <a place="<?php echo $us['username']; ?> " href="profile/<?php echo $us['username']; ?> ">
            <div id="boxteam">
               <div id="team3"></div>
               <div id="boxteam2">
               <?php echo $us['cms_role']; ?> 
               </div>
               <div id='teamonline' style='background:<?php echo $status; ?>;'></div>
               <div id="team3"></div>
               <div id="teamavatar">
                  <img class="lazy" alt="<?php echo $us['username']; ?> " src="<?php echo AVATARIMAGE . $us['look']; ?>&head_direction=3&gesture=sml&direction=2&size=l" />
               </div>
               <div id="teamshadow">
                  <div id="teamshadowbox"></div>
               </div>
               <div id="teambackground" style="background:url(<?php echo PATH ?>/app/assets/img/staff_bg.png);background-position-y: -550px;"></div>
               <div id="teampseudo">
                  <h2>
                  <?php echo $us['username']; ?> 
                  <h2>
               </div>
               <div id="teamgrade">
                  <p><?php echo $us['cms_rank']; ?> </p>
               </div>
               <div id="teambadge" style="background:url(<?php echo PATH ?>/app/assets/img/staff_badge.png?20022018);background-position-x:<?php echo $position; ?>px;"></div>
            </div>
         </a>
         <?php }}} ?>
         <div class="end"></div>
      </div>
      <div style="width:calc(100% - 10px)" id="profil45n">
      <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- test1 -->
<ins class="adsbygoogle"
     style="display:inline-block;width:728px;height:90px"
     data-ad-client="ca-pub-3241001792568207"
     data-ad-slot="4095236187"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
      </div>
   </div>
   <div id="team1">
      <div id="team2" style="background:#FEA64B">
         <h1>
         <strong>Eventos y Animación</strong>
         <h1>
      </div>
      <div id="team2n">Eventos</div>
      <div id="team1n">

<?php 	global $db;
					$dd = $db->query("SELECT * FROM ranks WHERE id = 14 || id = 9 ORDER BY id DESC");
					while($rank = $dd->fetch_array()){
            $ru = $db->query("SELECT * FROM users WHERE rank = '". $rank['id'] ."' ORDER BY rank DESC");
            while($us = $ru->fetch_array()){
                if($us['online'] == 1){
                    $status = '#63C862';
                }else{
                    $status = '#ED1C24';
            }
            if($us['cms_staffocult'] == 0){
                if($us['rank'] == 14) {
                    $position = '-160';                
                 }elseif($us['rank'] == 9) {
                    $position = '400';                
                 }
            ?>
         <a place="<?php echo $us['username']; ?> " href="profile/<?php echo $us['username']; ?> ">
            <div id="boxteam">
               <div id="team3"></div>
               <div id="boxteam2">
               <?php echo $us['cms_role']; ?> 
               </div>
               <div id='teamonline' style='background:<?php echo $status; ?>;'></div>
               <div id="teamavatar">
                  <img class="lazy" alt="<?php echo $us['username']; ?> " src="<?php echo AVATARIMAGE . $us['look']; ?>&head_direction=3&gesture=sml&direction=2&size=l" />
               </div>
               <div id="teamshadow">
                  <div id="teamshadowbox"></div>
               </div>
               <div id="teambackground" style="background:url(<?php echo PATH ?>/app/assets/img/staff_bg.png);background-position-y: -220px;"></div>
               <div id="teampseudo">
                  <h2>
                  <?php echo $us['username']; ?> 
                  <h2>
               </div>
               <div id="teamgrade">
                  <p><?php echo $us['cms_rank']; ?></p>
               </div>
               <div id="teambadge" style="background:url(<?php echo PATH ?>/app/assets/img/staff_badge.png?20022018);background-position-x:<?php echo $position; ?>px;"></div>
            </div>
         </a>
         <?php }}} ?>

         <div class="end"></div>
      </div>
      <div id="team2n">Animación</div>
      <div id="team1n">
      <?php 	global $db;
					$dd = $db->query("SELECT * FROM ranks WHERE id = 13 ORDER BY id DESC");
					while($rank = $dd->fetch_array()){
            $ru = $db->query("SELECT * FROM users WHERE rank = '". $rank['id'] ."' AND user_rank = 12 ORDER BY rank DESC");
            while($us = $ru->fetch_array()){
                if($us['online'] == 1){
                    $status = '#63C862';
                }else{
                    $status = '#ED1C24';
            }
            if($us['cms_staffocult'] == 0){
                if($us['rank'] == 13) {
                   $position = '-120';                
                             }
            ?>
         <a place="<?php echo $us['username']; ?> " href="profile/<?php echo $us['username']; ?> ">
            <div id="boxteam">
               <div id="team3"></div>
               <div id="boxteam2">
               <?php echo $us['cms_role']; ?>
               </div>
               <div id='teamonline' style='background:<?php echo $status; ?>;'></div>
               <div id="teamavatar">
                  <img class="lazy" alt="<?php echo $us['username']; ?> " src="<?php echo AVATARIMAGE . $us['look']; ?>&head_direction=3&gesture=sml&direction=2&size=l" />
               </div>
               <div id="teamshadow">
                  <div id="teamshadowbox"></div>
               </div>
               <div id="teambackground" style="background:url(<?php echo PATH ?>/app/assets/img/staff_bg.png);background-position-y: -220px;"></div>
               <div id="teampseudo">
                  <h2>
                  <?php echo $us['username']; ?> 
                  <h2>
               </div>
               <div id="teamgrade">
                  <p><?php echo $us['cms_rank']; ?></p>
               </div>
               <div id="teambadge" style="background:url(<?php echo PATH ?>/app/assets/img/staff_badge.png?20022018);background-position-x:<?php echo $position; ?>px;"></div>
            </div>
         </a>
         <?php }}} ?>

         <?php 	global $db;
					$dd = $db->query("SELECT * FROM ranks WHERE id = 12 ORDER BY id DESC");
					while($rank = $dd->fetch_array()){
            $ru = $db->query("SELECT * FROM users WHERE rank = '". $rank['id'] ."' ORDER BY rank DESC");
            while($us = $ru->fetch_array()){
                if($us['online'] == 1){
                    $status = '#63C862';
                }else{
                    $status = '#ED1C24';
            }
            if($us['cms_staffocult'] == 0){
                if($us['rank'] == 12) {
                    $position = '-200';                
                 }
            ?>
         <a place="<?php echo $us['username']; ?> " href="profile/<?php echo $us['username']; ?> ">
            <div id="boxteam">
               <div id="team3"></div>
               <div id="boxteam2">
               <?php echo $us['cms_role']; ?>
               </div>
               <div id='teamonline' style='background:<?php echo $status; ?>;'></div>
               <div id="teamavatar">
                  <img class="lazy" alt="<?php echo $us['username']; ?> " src="<?php echo AVATARIMAGE . $us['look']; ?>&head_direction=3&gesture=sml&direction=2&size=l" />
               </div>
               <div id="teamshadow">
                  <div id="teamshadowbox"></div>
               </div>
               <div id="teambackground" style="background:url(<?php echo PATH ?>/app/assets/img/staff_bg.png);background-position-y: -220px;"></div>
               <div id="teampseudo">
                  <h2>
                  <?php echo $us['username']; ?> 
                  <h2>
               </div>
               <div id="teamgrade">
                  <p><?php echo $us['cms_rank']; ?></p>
               </div>
               <div id="teambadge" style="background:url(<?php echo PATH ?>/app/assets/img/staff_badge.png?20022018);background-position-x:<?php echo $position; ?>px;"></div>
            </div>
         </a>
         <?php }}} ?>




         <div class="end"></div>
      </div>
   </div>
   <div id="team1">
      <div id="team2" style="background:#63C862">
         <h1>
         <strong>Seguridad y asistencia</strong>
         <h1>
      </div>
      <div id="team2n">Seguridad</div>
      <div id="team1n">
      <?php 	global $db;
					$dd = $db->query("SELECT * FROM ranks WHERE id = 13 ORDER BY id DESC");
					while($rank = $dd->fetch_array()){
            $ru = $db->query("SELECT * FROM users WHERE rank = '". $rank['id'] ."' AND user_rank = 11 ORDER BY rank DESC");
            while($us = $ru->fetch_array()){
                if($us['online'] == 1){
                    $status = '#63C862';
                }else{
                    $status = '#ED1C24';
            }
            if($us['cms_staffocult'] == 0){
                if($us['rank'] == 13) {
                    $position = '-120';                
                              }
            ?>
         <a place="<?php echo $us['username']; ?>" href="profile/<?php echo $us['username']; ?>">
            <div id="boxteam">
               <div id="team3"></div>
               <div id="boxteam2">
               <?php echo $us['cms_role']; ?> 
               </div>
               <div id='teamonline' style='background:<?php echo $status; ?>;'></div>
               <div id="teamavatar">
                  <img class="lazy" alt="<?php echo $us['username']; ?>" src="<?php echo AVATARIMAGE . $us['look']; ?>&head_direction=3&gesture=sml&direction=2&size=l" />
               </div>
               <div id="teamshadow">
                  <div id="teamshadowbox"></div>
               </div>
               <div id="teambackground" style="background:url(<?php echo PATH ?>/app/assets/img/staff_bg.png);background-position-y: -440px;"></div>
               <div id="teampseudo">
                  <h2>
                  <?php echo $us['username']; ?>
                  <h2>
               </div>
               <div id="teamgrade">
                  <p><?php echo $us['cms_rank']; ?></p>
               </div>
               <div id="teambadge" style="background:url(<?php echo PATH ?>/app/assets/img/staff_badge.png?20022018);background-position-x:<?php echo $position; ?>px;"></div>
            </div>
         </a>
         <?php }}} ?>

         <?php 	global $db;
					$dd = $db->query("SELECT * FROM ranks WHERE id = 11 ORDER BY id DESC");
					while($rank = $dd->fetch_array()){
            $ru = $db->query("SELECT * FROM users WHERE rank = '". $rank['id'] ."' ORDER BY rank DESC");
            while($us = $ru->fetch_array()){
                if($us['online'] == 1){
                    $status = '#63C862';
                }else{
                    $status = '#ED1C24';
            }
            if($us['cms_staffocult'] == 0){
                if($us['rank'] == 11) {
                    $position = '480';                
                 }
            ?>
         <a place="<?php echo $us['username']; ?>" href="profile/<?php echo $us['username']; ?>">
            <div id="boxteam">
               <div id="team3"></div>
               <div id="boxteam2">
               <?php echo $us['cms_role']; ?> 
               </div>
               <div id='teamonline' style='background:<?php echo $status; ?>;'></div>
               <div id="teamavatar">
                  <img class="lazy" alt="<?php echo $us['username']; ?>" src="<?php echo AVATARIMAGE . $us['look']; ?>&head_direction=3&gesture=sml&direction=2&size=l" />
               </div>
               <div id="teamshadow">
                  <div id="teamshadowbox"></div>
               </div>
               <div id="teambackground" style="background:url(<?php echo PATH ?>/app/assets/img/staff_bg.png);background-position-y: -440px;"></div>
               <div id="teampseudo">
                  <h2>
                  <?php echo $us['username']; ?>
                  <h2>
               </div>
               <div id="teamgrade">
                  <p><?php echo $us['cms_rank']; ?></p>
               </div>
               <div id="teambadge" style="background:url(<?php echo PATH ?>/app/assets/img/staff_badge.png?20022018);background-position-x:<?php echo $position; ?>px;"></div>
            </div>
         </a>
         <?php }}} ?>
         <div class="end"></div>
      </div>
      <div id="team2n">Asistencia</div>
      <div id="team1n">
      <?php 	global $db;
					$dd = $db->query("SELECT * FROM ranks WHERE id = 13 ORDER BY id DESC");
					while($rank = $dd->fetch_array()){
            $ru = $db->query("SELECT * FROM users WHERE rank = '". $rank['id'] ."' AND user_rank = 8 ORDER BY rank DESC");
            while($us = $ru->fetch_array()){
                if($us['online'] == 1){
                    $status = '#63C862';
                }else{
                    $status = '#ED1C24';
            }
            if($us['cms_staffocult'] == 0){
                if($us['rank'] == 13) {
                    $position = '-120';                
                              }
            ?>
         <a place="<?php echo $us['username']; ?>" href="profile/<?php echo $us['username']; ?>">
            <div id="boxteam">
               <div id="team3"></div>
               <div id="boxteam2">
               <?php echo $us['cms_role']; ?> 
               </div>
               <div id='teamonline' style='background:<?php echo $status; ?>;'></div>
               <div id="teamavatar">
                  <img class="lazy" alt="<?php echo $us['username']; ?>" src="<?php echo AVATARIMAGE . $us['look']; ?>&head_direction=3&gesture=sml&direction=2&size=l" />
               </div>
               <div id="teamshadow">
                  <div id="teamshadowbox"></div>
               </div>
               <div id="teambackground" style="background:url(<?php echo PATH ?>/app/assets/img/staff_bg.png);background-position-y: -660px;"></div>
               <div id="teampseudo">
                  <h2>
                  <?php echo $us['username']; ?>
                  <h2>
               </div>
               <div id="teamgrade">
                  <p><?php echo $us['cms_rank']; ?></p>
               </div>
               <div id="teambadge" style="background:url(<?php echo PATH ?>/app/assets/img/staff_badge.png?20022018);background-position-x:<?php echo $position; ?>px;"></div>
            </div>
         </a>
         <?php }}} ?>
         <?php 	global $db;
					$dd = $db->query("SELECT * FROM ranks WHERE id = 8 ORDER BY id DESC");
					while($rank = $dd->fetch_array()){
            $ru = $db->query("SELECT * FROM users WHERE rank = '". $rank['id'] ."' ORDER BY rank DESC");
            while($us = $ru->fetch_array()){
                if($us['online'] == 1){
                    $status = '#63C862';
                }else{
                    $status = '#ED1C24';
            }
            if($us['cms_staffocult'] == 0){
                if($us['rank'] == 8) {
                    $position = '240';                
                              }
            ?>
         <a place="<?php echo $us['username']; ?>" href="profile/<?php echo $us['username']; ?>">
            <div id="boxteam">
               <div id="team3"></div>
               <div id="boxteam2">
               <?php echo $us['cms_role']; ?> 
               </div>
               <div id='teamonline' style='background:<?php echo $status; ?>;'></div>
               <div id="teamavatar">
                  <img class="lazy" alt="<?php echo $us['username']; ?>" src="<?php echo AVATARIMAGE . $us['look']; ?>&head_direction=3&gesture=sml&direction=2&size=l" />
               </div>
               <div id="teamshadow">
                  <div id="teamshadowbox"></div>
               </div>
               <div id="teambackground" style="background:url(<?php echo PATH ?>/app/assets/img/staff_bg.png);background-position-y: -660px;"></div>
               <div id="teampseudo">
                  <h2>
                  <?php echo $us['username']; ?>
                  <h2>
               </div>
               <div id="teamgrade">
                  <p><?php echo $us['cms_rank']; ?></p>
               </div>
               <div id="teambadge" style="background:url(<?php echo PATH ?>/app/assets/img/staff_badge.png?20022018);background-position-x:<?php echo $position; ?>px;"></div>
            </div>
         </a>
         <?php }}} ?>
         <div class="end"></div>
      </div>
   </div>
   <div id="team1">
      <div id="team2" style="background:#6F9CF0">
         <h1>
         <strong>Comunidad y Creación</strong>
         <h1>
      </div>
      <div id="team2n">Puestos especiales</div>
      <div id="team1n">
      <?php 	global $db;
					$dd = $db->query("SELECT * FROM ranks WHERE id = 10 ORDER BY id DESC");
					while($rank = $dd->fetch_array()){
            $ru = $db->query("SELECT * FROM users WHERE rank = '". $rank['id'] ."' ORDER BY rank DESC");
            while($us = $ru->fetch_array()){
                if($us['online'] == 1){
                    $status = '#63C862';
                }else{
                    $status = '#ED1C24';
            }
            if($us['cms_staffocult'] == 0){
                if($us['rank'] == 10) {
                    $position = '440';                
                 }
            ?>
         <a place="<?php echo $us['username']; ?>" href="profile/<?php echo $us['username']; ?>">
            <div id="boxteam">
               <div id="team3"></div>
               <div id="boxteam2">
               <?php echo $us['cms_role']; ?> 
               </div>
               <div id='teamonline' style='background:<?php echo $status; ?>;'></div>
               <div id="teamavatar">
                  <img class="lazy" alt="<?php echo $us['username']; ?>" src="<?php echo AVATARIMAGE . $us['look']; ?>&head_direction=3&gesture=sml&direction=2&size=l" />
               </div>
               <div id="teamshadow">
                  <div id="teamshadowbox"></div>
               </div>
               <div id="teambackground" style="background:url(<?php echo PATH ?>/app/assets/img/staff_bg.png);background-position-y: -330px;"></div>
               <div id="teampseudo">
                  <h2>
                  <?php echo $us['username']; ?>
                  <h2>
               </div>
               <div id="teamgrade">
                  <p><?php echo $us['cms_rank']; ?></p>
               </div>
               <div id="teambadge" style="background:url(<?php echo PATH ?>/app/assets/img/staff_badge.png?20022018);background-position-x:<?php echo $position; ?>px;"></div>
            </div>
         </a>
         <?php }}} ?>
         <div class="end"></div>
      </div>
      <div id="team2n">Publicidad</div>
      <div id="team1n">
      <?php 	global $db;
					$dd = $db->query("SELECT * FROM ranks WHERE id = 7 || id = 5 ORDER BY id DESC");
					while($rank = $dd->fetch_array()){
            $ru = $db->query("SELECT * FROM users WHERE rank = '". $rank['id'] ."' ORDER BY rank DESC");
            while($us = $ru->fetch_array()){
                if($us['online'] == 1){
                    $status = '#63C862';
                }else{
                    $status = '#ED1C24';
            }
            if($us['cms_staffocult'] == 0){
                if($us['rank'] == 7) {
                    $position = '-240';                
                 }elseif($us['rank'] == 5) {
                    $position = '-240';                
                 }
            ?>
         <a place="<?php echo $us['username']; ?>" href="profile/<?php echo $us['username']; ?>">
            <div id="boxteam">
               <div id="team3"></div>
               <div id="boxteam2">
               <?php echo $us['cms_role']; ?> 
               </div>
               <div id='teamonline' style='background:<?php echo $status; ?>;'></div>
               <div id="teamavatar">
                  <img class="lazy" alt="<?php echo $us['username']; ?>" src="<?php echo AVATARIMAGE . $us['look']; ?>&head_direction=3&gesture=sml&direction=2&size=l" />
               </div>
               <div id="teamshadow">
                  <div id="teamshadowbox"></div>
               </div>
               <div id="teambackground" style="background:url(<?php echo PATH ?>/app/assets/img/staff_bg.png);background-position-y: -220px;"></div>
               <div id="teampseudo">
                  <h2>
                  <?php echo $us['username']; ?>
                  <h2>
               </div>
               <div id="teamgrade">
                  <p><?php echo $us['cms_rank']; ?></p>
               </div>
               <div id="teambadge" style="background:url(<?php echo PATH ?>/app/assets/img/staff_badge.png?20022018);background-position-x:<?php echo $position; ?>px;"></div>
            </div>
         </a>
         <?php }}} ?>
         <div class="end"></div>
      </div>
      <div id="team2n">Super Star</div>
      <div id="team1n">
      <?php 	global $db;
					$dd = $db->query("SELECT * FROM ranks WHERE id = 6 ORDER BY id DESC");
					while($rank = $dd->fetch_array()){
            $ru = $db->query("SELECT * FROM users WHERE rank = '". $rank['id'] ."' ORDER BY rank DESC");
            while($us = $ru->fetch_array()){
                if($us['online'] == 1){
                    $status = '#63C862';
                }else{
                    $status = '#ED1C24';
            }
            if($us['cms_staffocult'] == 0){
                if($us['rank'] == 6) {
                    $position = '360';                
                 }
            ?>
         <a place="<?php echo $us['username']; ?>" href="profile/<?php echo $us['username']; ?>">
            <div id="boxteam">
               <div id="team3"></div>
               <div id="boxteam2">
               <?php echo $us['cms_role']; ?>
               </div>
               <div id='teamonline' style='background:<?php echo $status; ?>;'></div>
               <div id="teamavatar">
                  <img class="lazy" alt="<?php echo $us['username']; ?>" src="<?php echo AVATARIMAGE . $us['look']; ?>&head_direction=3&gesture=sml&direction=2&size=l" />
               </div>
               <div id="teamshadow">
                  <div id="teamshadowbox"></div>
               </div>
               <div id="teambackground" style="background:url(<?php echo PATH ?>/app/assets/img/staff_bg.png);background-position-y: -110px;"></div>
               <div id="teampseudo">
                  <h2>
                  <?php echo $us['username']; ?>
                  <h2>
               </div>
               <div id="teamgrade">
                  <p><?php echo $us['cms_rank']; ?></p>
               </div>
               <div id="teambadge" style="background:url(<?php echo PATH ?>/app/assets/img/staff_badge.png?20022018);background-position-x:<?php echo $position; ?>px;"></div>
            </div>
         </a>
         <?php }}} ?>
         <div class="end"></div>
      </div>
      <div id="team2n">Casino</div>
      <div id="team1n">
      <?php 	global $db;
					$dd = $db->query("SELECT * FROM ranks WHERE id = 4 ORDER BY id DESC");
					while($rank = $dd->fetch_array()){
            $ru = $db->query("SELECT * FROM users WHERE rank = '". $rank['id'] ."' ORDER BY rank DESC");
            while($us = $ru->fetch_array()){
                if($us['online'] == 1){
                    $status = '#63C862';
                }else{
                    $status = '#ED1C24';
            }
            if($us['cms_staffocult'] == 0){
                if($us['rank'] == 4) {
                    $position = '80';                
                 }
            ?>
         <a place="<?php echo $us['username']; ?>" href="profile/<?php echo $us['username']; ?>">
            <div id="boxteam">
               <div id="team3"></div>
               <div id="boxteam2">
               <?php echo $us['cms_role']; ?> 
               </div>
               <div id='teamonline' style='background:<?php echo $status; ?>;'></div>
               <div id="teamavatar">
                  <img class="lazy" alt="<?php echo $us['username']; ?>" src="<?php echo AVATARIMAGE . $us['look']; ?>&head_direction=3&gesture=sml&direction=2&size=l" />
               </div>
               <div id="teamshadow">
                  <div id="teamshadowbox"></div>
               </div>
               <div id="teambackground" style="background:url(<?php echo PATH ?>/app/assets/img/staff_bg.png);background-position-y: -220px;"></div>
               <div id="teampseudo">
                  <h2>
                  <?php echo $us['username']; ?>
                  <h2>
               </div>
               <div id="teamgrade">
                  <p><?php echo $us['cms_rank']; ?> </p>
               </div>
               <div id="teambadge" style="background:url(<?php echo PATH ?>/app/assets/img/staff_badge.png?20022018);background-position-x:<?php echo $position; ?>px;"></div>
            </div>
         </a>
         <?php }}} ?>
         <div class="end"></div>
      </div>
   </div>
   <strong>
   <a style="color:rgba(100,100,100,0); font-size:1px;">habbo staff, habbostaff, cómo convertirse en personal en habbo, staff de habbo, habbo-staff, habbocity staff, habbo equipo, equipo de habbo, habbo team, team habbo, habbo page staff, normal habbo, pixeled staff, staff, staff pixeled, forbi, yezcms</a>
   </strong>
<?php
   //COLUMNA FOOTER
     $TplClass->AddTemplate("others", "footer");
   ?>