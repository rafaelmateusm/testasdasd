<?php
   ob_start();
   require_once '../../global.php';
   
   $Functions->Logged("true");
   $Functions->pin("true");
   
   //HOTEL CONFIG
   $result2 = $db->query("SELECT * FROM cms_settings WHERE id = 1 LIMIT 1");
   $yezz = $result2->fetch_array();
   //END HOTEL CONFIG
   
   $users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
   $user = $users->fetch_array();
   
      $TplClass->SetAll();
   
      $getid = $Functions->FilterText($_GET['id']);
   
   
   
      $rf = $db->query("SELECT * FROM cms_forum WHERE id = '".$getid."' LIMIT 1");
     $forum = $rf->fetch_array();
      
      $TplClass->SetParam('title', 'Editar tema');  
      $TplClass->SetParam('description', 'Editar tema');
   
        $TplClass->AddTemplate("header", "menu");
                
   ob_end_flush();
   ?>
<?php if($user['username'] == $forum['username'] || $user['rank'] > 10){ ?>
<div id="appcontent">
<div id="webcenter">
   <div id="forum67">Editar tema</div>
   <input type="text" id="topictitl" placeholder="Título del tema" class="indexinput" style="width:calc(100% - 25px);background:white;color:black;" value ="<?php echo $forum['title']; ?>"/>
   <div id="indexformsepare"></div>
   <select id="topiccategory" class="indexinput" style="width:100%;height:80px;background:white;">
      <?php     if($forum['category'] == "c1"){ $selectedc1 = 'selected'; }elseif($forum['category'] == "c2"){ $selectedc2 = 'selected'; }
         elseif($forum['category'] == "c3"){ $selectedc3 = 'selected'; }elseif($forum['category'] == "c4"){ $selectedc4 = 'selected'; }
         elseif($forum['category'] == "c5"){ $selectedc5 = 'selected'; }elseif($forum['category'] == "c6"){ $selectedc6 = 'selected'; }
         elseif($forum['category'] == "c7"){ $selectedc7 = 'selected'; }elseif($forum['category'] == "c8"){ $selectedc8 = 'selected'; }?>
      <?php if($user['rank'] > 13){ ?>
      <option <?php echo $selectedc1; ?> value="c1">Anuncios oficiales</option>
      <?php } ?>
      <option <?php echo $selectedc2; ?> value="c2">Discusión General</option>
      <option <?php echo $selectedc3; ?> value="c3">Ayuda y Tutoriales</option>
      <option <?php echo $selectedc4; ?> value="c4">Ideas y sugerencias</option>
      <option <?php echo $selectedc5; ?> value="c5">Economía y Casino</option>
      <option <?php echo $selectedc6; ?> value="c6">Juegos y eventos</option>
      <option <?php echo $selectedc7; ?> value="c7">Gráficos y pixel Art</option>
      <option <?php echo $selectedc8; ?> value="c8">Parejas y relaciones</option>
   </select>
   <div id="lecture42">
      <div id="lecture43"></div>
      <div id="lecture44"></div>
   </div>
   <div id="indexformsepare"></div>
   <div style="position:relative;height:12px;"></div>
   <button id="articlescombbcode" type="button" onclick="balise('bold');"><b>B</b></button>
   <button id="articlescombbcode" type="button" onclick="balise('underline')"><u>U</u></button>
   <button id="articlescombbcode" type="button" onclick="balise('italic')"><i>I</i></button>
   <button id="articlescombbcode" type="button" onclick="balise('createLink');">Link</button>
   <button id="articlescombbcode" type="button" onclick="balise('insertImage');">Imagen</button>
   <button id="articlescombbcode" style="background:#ED1C24;" type="button" onclick="balise('redcolor');">
   Rojo
   </button>
   <button id="articlescombbcode" style="background:#22B14C;" type="button" onclick="balise('vertcolor');">
   Verde
   </button>
   <button id="articlescombbcode" style="background:#4286CA;" type="button" onclick="balise('bleucolor');">
   Azul
   </button>
   <div style="position:relative;height:48px;"></div>
   <div id="editeur" style="width:calc(100% - 20px);left:0px;height:auto;min-height:150px;background:white;font-size:120%;color:black;" contentEditable type="text"><?php echo $Functions->FilterText2($forum['content']); ?></div>
   <div id="indexformsepare"></div>
   <button id="indexsubmit" style="width:100%;background:rgb(99,200,98);margin-bottom:30px;" onclick="addnewusjet('edit','<?php echo $forum['id']; ?>')">Publicar mi tema
   </button>
</div>
<?php }else{ ?>
<div id="appcontent">
<div id="webcenter">
   <div id="forum60">
      <center>
         <div id="forum55"></div>
         <br>No puedes editar el tema.
      </center>
   </div>
</div>
<?php } ?>
<strong>
<a style="color:rgba(100,100,100,0); font-size:1px;">habboforum, forum, habbo, habbo foro, discusión, discusión habbo, forum habbo, ayuda habbo, help habbo, habbo help, hacerse rico en habbo, riqueza habbo</a>
</strong>
<?php
   //COLUMNA FOOTER
     $TplClass->AddTemplate("others", "footer");
   ?>