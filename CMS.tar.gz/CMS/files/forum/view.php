<?php
   ob_start();
   require_once '../../global.php';
   
      $Functions->Logged("allow");
      $Functions->pin("true");
   
   //HOTEL CONFIG
   $result2 = $db->query("SELECT * FROM cms_settings WHERE id = 1 LIMIT 1");
   $yezz = $result2->fetch_array();
   //END HOTEL CONFIG
   
   $users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
   $user = $users->fetch_array();
   
      $TplClass->SetAll();
   
      
      $cadena = $Functions->FilterText($_GET['link']);
      $resultado = explode('-',$cadena);
      $getid = $resultado[0];
     
     if(empty($getid)){
     $rf = $db->query("SELECT * FROM cms_forum ORDER BY id DESC LIMIT 1");
     $forum = $rf->fetch_array();
     $getid = $forum['id'];
     }else
     $rf = $db->query("SELECT * FROM cms_forum WHERE id = '{$getid}' LIMIT 1");
     $forum = $rf->fetch_array();
     $db->query("UPDATE cms_forum SET views = views + '1' WHERE id = '".$forum['id']."'");
   
     $rauthor = $db->query("SELECT * FROM users WHERE username = '".$forum['username']."'");
   $userinfo = $rauthor->fetch_array();
   
   
   $views = $db->query("SELECT * FROM cms_views WHERE posted_in = '".$forum['id']."'");
   
   if($user['id'] > 0){
   $viewss = $db->query("SELECT * FROM cms_views WHERE username = '".$user['username']."' AND posted_in = '".$forum['id']."'");
   if($viewss->num_rows > 0){
      $db->query("UPDATE cms_views SET type = '1' WHERE posted_in = '".$forum['id']."'");
   }else{
   $db->query("INSERT INTO cms_views (username, posted_in, type, time) VALUES ('".$user['username']."', '".$forum['id']."', '1', '".time()."')");
      }
    }
   
   
     if($forum['category'] == 'c1'){
      $c = 1;
      $t = 'Anuncios oficiales';
      $link = 'official-advertisements';
      $color = 'rgb(249,208,70)';
   
     }elseif($forum['category'] == 'c2'){
      $c = 2;
       $t = 'Discusión general';
       $link = 'general-discussion';
       $color = '';
   
      }elseif($forum['category'] == 'c3'){
        $c = 3;
       $t = 'Ayuda y Tutoriales';
       $link = 'help';
       $color = 'rgb(254,166,75)';
   
      }elseif($forum['category'] == 'c4'){
        $c = 4;
       $t = 'Ideas y sugerencias';
       $link = 'ideas-and-suggestions';
       $color = 'rgb(111,156,240)';
   
      }elseif($forum['category'] == 'c5'){
        $c = 5;
       $t = 'Economía y Casino';
       $link = 'economy-casino';
       $color = 'rgb(250,214,88)';
   
      }elseif($forum['category'] == 'c6'){
        $c = 6;
       $t = 'Juegos y eventos';
       $link = 'games-events';
       $color = 'rgb(161,161,161)';
   
      }elseif($forum['category'] == 'c7'){
        $c = 7;
       $t = 'Gráficos y pixel Art';
       $link = 'graphic-pixel-art';
       $color = 'rgb(152,171,175)';
   
      }elseif($forum['category'] == 'c8'){
        $c = 8;
       $t = 'Parejas y relaciones';
       $link = 'couples-relations';
       $color = 'rgb(254,137,172)';
   
      }
   
   
   
      $TplClass->SetParam('title', $Functions->FilterText($forum['title']).' - '.$yezz['hotelname']);  
      $TplClass->SetParam('description', $Functions->FilterText($forum['title']).' - '.$yezz['hotelname']);
   
        $TplClass->AddTemplate("header", "menu");
                
   ob_end_flush();
   ?>
<div id="appcontent">
<style>
   body {
   background: rgb(238, 238, 238)
   }
</style>
<div id="webcenter">
   <a place="<?php echo $yezz['hotelname']; ?>: <?php echo $t; ?>" href="<?php echo PATH ?>/forum/category/<?php echo $c ?>/1/<?php echo $link ?>">
      <div id="forum1nx" style="background:<?php echo $color; ?>">
         <div id="forum1nc"></div>
      </div>
   </a>
   <div style="background:<?php echo $color; ?>" id="forum1">
      <div id="forum2">
         <div id="forum21" style="background:url(<?php echo AVATARIMAGE . $userinfo['look']; ?>&action=std&gesture=std&direction=2&head_direction=2&size=n&headonly=1&img_format=png);"></div>
      </div>
      <div id="forum4">
         <h1><?php echo $Functions->FilterText($forum['title']); ?></h1>
      </div>
      <div title="Reportar" onclick="OpenSupport('forum','<?php echo PATH ?>/app/load/HelpPage.php?page=forum&threadid=<?php echo $forum['id']; ?>')" id="forum22">
         <div id="forum23"></div>
      </div>
      <div style="position:absolute;right:0px;" id="ar_reaction">
         <?php $rreacts = $db->query("SELECT * FROM cms_likes_publi WHERE publi_id = '".$forum['id']."' AND page = '2' AND username = '".$user['username']."'"); 
            $inforeac = $rreacts->fetch_array();
            if($inforeac['type'] == 1){
              $position = '45px 0px';
            }elseif($inforeac['type'] == 2){
              $position = '225px 0px';
            }elseif($inforeac['type'] == 3){
              $position = '90px 0px';
            }elseif($inforeac['type'] == 4){
              $position = '180px 0px';
            }elseif($inforeac['type'] == 5){
              $position = '135px 1px';
            }else{
            $position = '135px 1px';
            }
            ?> 
         <div id="lecture32" style="background-position: <?php echo $position; ?>;"></div>
         <div id="lecture33">
            <x id="nbreact">
               <?php $rreact = $db->query("SELECT * FROM cms_likes_publi WHERE publi_id = '".$forum['id']."' AND page = '2'"); ?> 
               <?php echo $rreact->num_rows; ?> 
            </x>
            reacciones
         </div>
         <div id="js_reaction">
            <div onclick="React('<?php echo $forum['id']; ?>','1','45px 0px','react1','2');" id="articlesreaction" style="background:url(<?php echo PATH ?>/app/assets/img/reactions_sprite.png);background-position: 45px 0px;">
               <div class="react1" id="articlesreactionnb" style="background:rgb(255,201,14);">
                  <?php $rreact1 = $db->query("SELECT * FROM cms_likes_publi WHERE publi_id = '".$forum['id']."' AND page = '2' AND type = '1'"); ?> 
                  <?php echo $rreact1->num_rows; ?>  
               </div>
            </div>
            <div onclick="React('<?php echo $forum['id']; ?>','2','225px 0px','react2','2');" id="articlesreaction" style="background:url(<?php echo PATH ?>/app/assets/img/reactions_sprite.png);background-position: 225px 0px;">
               <div class="react2" id="articlesreactionnb" style="background:white;color:black;">
                  <?php $rreact2 = $db->query("SELECT * FROM cms_likes_publi WHERE publi_id = '".$forum['id']."' AND page = '2' AND type = '2'"); ?> 
                  <?php echo $rreact2->num_rows; ?>  
               </div>
            </div>
            <div onclick="React('<?php echo $forum['id']; ?>','3','90px 0px','react3','2');" id="articlesreaction" style="background:url(<?php echo PATH ?>/app/assets/img/reactions_sprite.png);background-position: 90px 0px;">
               <div class="react3" id="articlesreactionnb" style="background:rgb(237,28,36);">
                  <?php $rreact3 = $db->query("SELECT * FROM cms_likes_publi WHERE publi_id = '".$forum['id']."' AND page = '2' AND type = '3'"); ?> 
                  <?php echo $rreact3->num_rows; ?>  
               </div>
            </div>
            <div onclick="React('<?php echo $forum['id']; ?>','4','180px 0px','react4','2');" id="articlesreaction" style="background:url(<?php echo PATH ?>/app/assets/img/reactions_sprite.png);background-position: 180px 0px;">
               <div class="react4" id="articlesreactionnb" style="background:white;color:black;">
                  <?php $rreact4 = $db->query("SELECT * FROM cms_likes_publi WHERE publi_id = '".$forum['id']."' AND page = '2' AND type = '4'"); ?> 
                  <?php echo $rreact4->num_rows; ?>  
               </div>
            </div>
            <div onclick="React('<?php echo $forum['id']; ?>','5','135px 1px','react5','2');" id="articlesreaction" style="background:url(<?php echo PATH ?>/app/assets/img/reactions_sprite.png);background-position: 135px 0px;">
               <div class="react5" id="articlesreactionnb" style="background:rgb(0,162,232);">
                  <?php $rreact5 = $db->query("SELECT * FROM cms_likes_publi WHERE publi_id = '".$forum['id']."' AND page = '2' AND type = '5'"); ?> 
                  <?php echo $rreact5->num_rows; ?>  
               </div>
            </div>
         </div>
      </div>
   </div>
   <div id="forum24">
      <div id="forum25">Iniciado por <?php echo $userinfo['username']; ?> <?php echo $Functions->GetLast2($forum['time']); ?>.</div>
      <div id="forum26"><?php echo number_format($views->num_rows);?> visitas</div>
   </div>
   <?php if($user['username'] == $forum['username'] || $user['rank'] > 10){ ?>
   <div id="forum56">
      <a place="Editar tema" href="<?php echo PATH ?>/forum/new-<?php echo $forum['id']; ?>">
         <div id="forum57">Editar</div>
      </a>
      <div onclick="ForumAction('<?php echo $forum['id']; ?>','delete')" id="forum57" class="forumt4de">
         Borrar
      </div>

       <div onclick="ForumAction('<?php echo $forum['id']; ?>','fijo')" id="forum57" class="forumt4ep">
       <?php if($forum['fijo'] == 0){ ?>
         Fijar
         <?php }else{ ?>
          Fijo
         <?php } ?>
      </div>

      <div onclick="ForumAction('<?php echo $forum['id']; ?>','close')" style="width:150px;" id="forum58">
         <div class="forumt4cl">
         <?php if($forum['cerrado'] == 0){ ?>
         Cerrar el tema
         <?php }else{ ?>
          Abrir el tema
         <?php } ?>
         </div>
         <div id="forum59"></div>
      </div>
   </div>
   <?php } ?>
   <div id="forumposts">
      <div class="gjshd<?php echo $forum['id']; ?>" id="forum27">
         <div id="forum28">
            <div id="forum29" style="background:url(<?php echo PATH ?>/app/assets/img/staff_bg.png);background-position-y: -110px;">
               <div id="teamshadow">
                  <div id="teamshadowbox"></div>
               </div>
               <a place="<?php echo $userinfo['username']; ?>" href="<?php echo PATH ?>/profile/<?php echo $userinfo['username']; ?>">
                  <div id="forum30">
                     <img draggable="false" oncontextmenu="return false" class="lazy" alt="<?php echo $userinfo['username']; ?>" src="<?php echo AVATARIMAGE . $userinfo['look']; ?>&action=std&gesture=std&direction=2&head_direction=2&size=l&img_format=png" />
                  </div>
               </a>
               <div id="forum31">
                  <h2>
                     Por <?php echo $userinfo['username']; ?>
                  </h2>
               </div>
               <div id="forum32"></div>
               <div id="forum33"><?php echo $Functions->GetLast($forum['time']); ?></div>
            </div>
            <div id="forum34">
               <div id="forum35"></div>
               <div id="forum35"></div>
               <div id="forum35"></div>
               <div id="forum35"></div>
               <div style="position:absolute;">
                  <?php 	global $db;
                     $badge = $db->query("SELECT * FROM user_badges WHERE user_id = '".$userinfo['id'] ."' AND badge_slot > '0' LIMIT 5");
                     if($badge->num_rows > 0){
                      while($badgess = $badge->fetch_array()){
                       $badges2 = $db->query("SELECT * FROM client_external_badge_texts WHERE badge_code = '".$badgess['badge_id']."'");
                       $badge2 = $badges2->fetch_array();
                     ?>
                  <div title="<?php echo $badge2['badge_title']; ?>" id="forum36">
                     <img class="lazy" draggable="false" oncontextmenu="return false" src="<?php echo BADGEURL . $badgess['badge_id']; ?>.gif" alt="<?php echo $badgess['badge_id']; ?>" />
                  </div>
                  <?php }} ?>
               </div>
            </div>
         </div>
         <div id="forum37">
            <div class="forummess<?php echo $forum['id']; ?>" id="motto">
               <p><?php echo $Functions->FilterTextF($forum['content']); ?></p>
               <div id="forum38"></div>
            </div>
         </div>
      </div>
      <div id="profil45n">
      </div>
      <?php global $db;
         $comentarios2 = $db->query("SELECT * FROM cms_comments_forum WHERE posted_in = '".$forum['id']."' ORDER BY id ASC");
         	while($coment = $comentarios2->fetch_array()){
         		$userinfo = $db->query("SELECT * FROM users WHERE username = '".$coment['username']."'");
         		while($userrinf = $userinfo->fetch_array()){
         
                     ?>
      <div class="gjshd<?php echo $coment['id']; ?>" id="forum27">
         <div id="forum28">
            <div id="forum29" style="background:url(<?php echo PATH ?>/app/assets/img/staff_bg.png);background-position-y: -220px;">
               <div id="teamshadow">
                  <div id="teamshadowbox"></div>
               </div>
               <a place="<?php echo $userrinf['username']; ?>" href="<?php echo PATH ?>/profile/<?php echo $userrinf['username']; ?>">
                  <div id="forum30">
                     <img draggable="false" oncontextmenu="return false" class="lazy" alt="<?php echo $userrinf['username']; ?>" src="<?php echo AVATARIMAGE . $userrinf['look']; ?>&action=std&gesture=std&direction=2&head_direction=2&size=l&img_format=png" />
                  </div>
               </a>
               <div id="forum31">
                  <h2>
                     Por <?php echo $userrinf['username']; ?>
                  </h2>
               </div>
               <div id="forum32"></div>
               <div id="forum33"><?php echo $Functions->GetLast($coment['time']); ?></div>
            </div>
            <div id="forum34">
               <div id="forum35"></div>
               <div id="forum35"></div>
               <div id="forum35"></div>
               <div id="forum35"></div>
               <div style="position:absolute;">
                  <?php 	global $db;
                     $badge = $db->query("SELECT * FROM user_badges WHERE user_id = '".$userrinf['id'] ."' AND badge_slot > '0' LIMIT 5");
                     if($badge->num_rows > 0){
                      while($badgess = $badge->fetch_array()){
                       $badges2 = $db->query("SELECT * FROM client_external_badge_texts WHERE badge_code = '".$badgess['badge_id']."'");
                       $badge2 = $badges2->fetch_array();
                     ?>
                  <div title="<?php echo $badge2['badge_title']; ?>" id="forum36">
                     <img class="lazy" draggable="false" oncontextmenu="return false" src="<?php echo BADGEURL . $badgess['badge_id']; ?>.gif" alt="<?php echo $badgess['badge_id']; ?>" />
                  </div>
                  <?php }} ?>
               </div>
            </div>
         </div>
         <div id="forum37">
            <div class="forummess<?php echo $coment['id']; ?>" id="motto">
               <p><?php echo $Functions->FilterTextF($coment['commentary']); ?>
                  <br><br>
               <div id="forum66">
                  <?php if($coment['edit'] == 1){ ?>
                  <?php if($coment['user_edit'] == $userrinf['username']){ ?>
                  Editado <?php echo $Functions->GetLast2($coment['edit_time']); ?>
                  <?php }else{ ?>
                  Editado por <?php echo $coment['user_edit']; ?> <?php echo $Functions->GetLast2($coment['edit_time']); ?>
                  <?php }}else{} ?>
               </div>
               <br> </p>
               <div id="forum38"></div>
            </div>
         </div>
         <div id="forum61"></div>
         <?php if($user['username'] == $coment['username'] || $user['rank'] > 10){ ?>
         <div onclick="ForumEditMsg('<?php echo $coment['id']; ?>')" id="forum62">Editar mensaje</div>
         <div onclick="ForumAction('<?php echo $coment['id']; ?>','deletepostid')" class="fghjk61131" id="forum63">Borrar</div>
         <?php } ?>
      </div>
      <?php }} ?>
   </div>
   <div style="top:-15px;" id="forum16">
      <a place="<?php echo $Functions->FilterText($forum['title']); ?> - <?php echo $yezz['hotelname']; ?>" href="<?php echo PATH ?>/forum/<?php echo $forum['id']; ?>-<?php echo $forum['link']; ?>/1">
         <div id="forum17"></div>
      </a>
      <a place="<?php echo $Functions->FilterText($forum['title']); ?> - <?php echo $yezz['hotelname']; ?>" href="<?php echo PATH ?>/forum/<?php echo $forum['id']; ?>-<?php echo $forum['link']; ?>/1">
         <div style="border:5px solid rgb(127,127,127)" id="forum18">
            1 
         </div>
      </a>
      <a place="<?php echo $Functions->FilterText($forum['title']); ?> - <?php echo $yezz['hotelname']; ?>" href="<?php echo PATH ?>/forum/<?php echo $forum['id']; ?>-<?php echo $forum['link']; ?>/1">
         <div id="forum19"></div>
      </a>
      <div class="end"></div>
   </div>

<?php if($forum['cerrado'] == 1){	?>
  <div id="forum53" style="background:;">
<center>
<div id="forum55"></div>
</center>
</div>
<?php }elseif($user['id'] > 0){	?>
   <div style="background:;" id="lecture42">
      <div id="lecture43"></div>
      <div id="lecture44"></div>
   </div>
   <div id="indexformsepare"></div>
   <button id="articlescombbcode" type="button" onclick="balise('bold');"><b>B</b></button>
   <button id="articlescombbcode" type="button" onclick="balise('underline')"><u>U</u></button>
   <button id="articlescombbcode" type="button" onclick="balise('italic')"><i>I</i></button>
   <button id="articlescombbcode" type="button" onclick="balise('createLink');">Link</button>
   <button id="articlescombbcode" type="button" onclick="balise('insertImage');">Imagen</button>
   <button id="articlescombbcode" style="background:#ED1C24;" type="button" onclick="balise('redcolor');">Rojo
   </button>
   <button id="articlescombbcode" style="background:#22B14C;" type="button" onclick="balise('vertcolor');">Verde
   </button>
   <button id="articlescombbcode" style="background:#4286CA;" type="button" onclick="balise('bleucolor');">Azul
   </button>
   <div style="position:relative;height:48px;"></div>
   <div id="editeur" style="width:calc(100% - 20px);left:0px;height:auto;min-height:120px;background:white;font-size:120%;" contenteditable="true">escribe algo...</div>
   <div id="indexformsepare"></div>
   <div id="forum39">
      <div id="forum40" style="background:url(<?php echo AVATARIMAGE . $user['look']; ?>&action=std&gesture=std&direction=2&head_direction=2&size=l&headonly=1&img_format=png);"></div>
      <div id="forum41">Responder como <?php echo $user['username']; ?></div>
   </div>
   <button id="forum42" onclick="ForumPostAdd('<?php echo $forum['id']; ?>','<?php echo AVATARIMAGE . $user['look']; ?>&action=std&gesture=std&direction=2&head_direction=2&size=l&img_format=png','<?php echo $user['username']; ?>','<?php echo PATH ?>/app/assets/img/staff_bg.png','forum/<?php echo $forum['id']; ?>-<?php echo $forum['link']; ?>')" type="submit">Enviar mensaje
   </button>

<?php } ?>
   
   <div class="end"></div>
</div>
<div id="forum64">
   <div id="forum65">Cargando...</div>
   <div onclick="ForumEditMsgClose()" id="fermeture"></div>
   <div id="loadeditmsg"></div>
</div>
<strong>
<a style="color:rgba(100,100,100,0); font-size:1px;">habboforum, forum, habbo, habbo foro, discusión, discusión habbo, forum habbo, ayuda habbo, help habbo, habbo help, hacerse rico en habbo, riqueza habbo</a>
</strong>
<?php
   //COLUMNA FOOTER
     $TplClass->AddTemplate("others", "footer");
   ?>