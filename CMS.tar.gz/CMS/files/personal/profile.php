<?php
   ob_start();
   require_once '../../global.php';
   
      $Functions->Logged("allow");
      $Functions->pin("true");
   
   //HOTEL CONFIG
   $result2 = $db->query("SELECT * FROM cms_settings WHERE id = 1 LIMIT 1");
   $yezz = $result2->fetch_array();
   //END HOTEL CONFIG
   
   $users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
   $user = $users->fetch_array();
   
   $TplClass->SetAll();
      
   
   //FUNCIONES DEL PERFIL
   $MYID = $Functions->GetID();
   $getname = $Functions->FilterText($_GET['user']);
   $do = $Functions->FilterText($_GET['do']);
   $key = $Functions->FilterText($_GET['key']);
   if(empty($getname)){
     $perfil = $db->query("SELECT * FROM users ORDER BY id DESC LIMIT 1");
     $userhome = $perfil->fetch_array();
     $getid = $Functions->FilterText($userhome['id']);
   }else{
     $perfil = $db->query("SELECT * FROM users WHERE username = '{$getname}' LIMIT 1");
     $userhome = $perfil->fetch_array();
   }
   
   
   $rstats = $db->query("SELECT * FROM user_stats WHERE id = '".$userhome['id']."'");
   $stats = $rstats->fetch_array();
   
   $horas = floor($stats['OnlineTime'] / 3600);
   $minutos = floor(($stats['OnlineTime'] - ($horas * 3600)) / 60);
   $segundos = $stats['OnlineTime'] - ($horas * 3600) - ($minutos * 60);
   $OnlineTime = $horas;
   
   
   
          $dd = $db->query("SELECT * FROM ranks WHERE id = '".$userhome['rank']."' ORDER BY id DESC");
          $rank = $dd->fetch_array();
   
          if($userhome['online'] == "1"){
            if($userhome['gender'] == "M"){
            $status = "Conectado";
          }elseif($userhome['gender'] == "F"){
            $status = "Conectada";
          }
            }else{
            $status = $Functions->GetLast($userhome['last_online']);
            }
   
     //END FUNCIONES
   
   $TplClass->SetParam('title', ''.$userhome['username'].'');
   $TplClass->SetParam('description', 'Perfil de '. $userhome['username']);
   
   $TplClass->AddTemplate("header", "menu");
    
   
   
   ob_end_flush();
   ?>
<div id="appcontent">
<div id="webcenter">
   <div id="profil54">
      <div id="profil55">
         <?php 	global $db;
            $badge = $db->query("SELECT * FROM user_badges WHERE user_id = '".$userhome['id'] ."' AND badge_slot > '0' LIMIT 5");
             while($badgess = $badge->fetch_array()){
            
            ?>
         <div id="profil56">
            <img class="" draggable="false" oncontextmenu="return false" src="<?php echo BADGEURL . $badgess['badge_id']; ?>.gif" alt="<?php echo $badgess['badge_id']; ?>" style="">
         </div>
         <?php } ?>
      </div>
      <div id="profil57">
         <img class="" draggable="false" oncontextmenu="return false" alt="<?php echo $Functions->FilterText($userhome['username']);?>" src="<?php echo AVATARIMAGE . $userhome['look']; ?>&size=l" style="">
      </div>
      <div id="profil58">
         <h1><?php echo $Functions->FilterText($userhome['username']);?></h1>
      </div>
      <div id="profil59">
         <div id="motto">
            <h1><?php echo $Functions->FilterText($userhome['motto']); ?></h1>
         </div>
      </div>
      <div id="profil60"></div>
      <div id="profil61">
         <h2><?php echo $status; ?></h2>
      </div>
      <div id="profil62"><?php echo number_format($stats['AchievementScore']);?> </div>
      <div id="profil63">
         <?php if($user['id'] > 0){ ?>
         <div id="profil76" style='left:-35px;'>
            <?php 	global $db;
               $result = $db->query("SELECT * FROM messenger_friendships WHERE user_one_id = '".$user['id']."' AND user_two_id = '".$userhome['id']."' OR user_one_id = '".$userhome['id']."' AND user_two_id = '".$user['id']."'");
                              if($result->num_rows > 0){
                              while($data = $result->fetch_array()){
                             
                                $rstories = $db->query("SELECT * FROM cms_stories WHERE user_id = '".$userhome['id']."' ORDER BY time DESC LIMIT 1");
                                if($rstories->num_rows > 0){
                                while($stories = $rstories->fetch_array()){
                              
                                 $rstoriesv = $db->query("SELECT * FROM cms_stories_views WHERE user_id = '".$user['id']."' AND photo_id = '".$stories['id']."'");
                                if($rstoriesv->num_rows > 0){
                                  $checkview = 'opacity: 0.4;';
                                 }else{
                                  $checkview = '';
                                 }
               
                                ?>
            <div id="profil82">
               <div class="hsQJwn<?php echo $userhome['id']; ?>" style="<?php echo $checkview; ?>border-radius:100%;overflow:hidden;cursor:pointer;display:flex;justify-content:center;align-items:center;">
                  <div onclick="hsgSQGyhd444(<?php echo $userhome['id']; ?>)" id="stories_box_image">
                     <img class="lazy" src="<?php echo PATH ?>/newfoto/camera/<?php echo $stories['photo']; ?>.png" style="">
                  </div>
               </div>
            </div>
            <?php }}else{} } } ?>
            <?php 	global $db;
               $rstories = $db->query("SELECT * FROM cms_stories WHERE user_id = '".$userhome['id']."' ORDER BY time DESC LIMIT 1");
               if($rstories->num_rows > 0){
               while($stories = $rstories->fetch_array()){
               
                $rstoriesv = $db->query("SELECT * FROM cms_stories_views WHERE user_id = '".$user['id']."' AND photo_id = '".$stories['id']."'");
               if($rstoriesv->num_rows > 0){
                 $checkview = 'opacity: 0.4;';
                }else{
                 $checkview = '';
                }
               
                if($userhome['id'] == $user['id']){
               ?>
            <div id="profil82">
               <div class="hsQJwn<?php echo $userhome['id']; ?>" style="<?php echo $checkview; ?>border-radius:100%;overflow:hidden;cursor:pointer;display:flex;justify-content:center;align-items:center;">
                  <div onclick="hsgSQGyhd444(<?php echo $userhome['id']; ?>)" id="stories_box_image">
                     <img class="lazy" src="<?php echo PATH ?>/newfoto/camera/<?php echo $stories['photo']; ?>.png" style="">
                  </div>
               </div>
            </div>
            <?php }elseif($userhome['public_stories'] == 1 || $user['rank']>10){ ?>
            <div id="profil82">
               <div class="hsQJwn<?php echo $userhome['id']; ?>" style="<?php echo $checkview; ?>border-radius:100%;overflow:hidden;cursor:pointer;display:flex;justify-content:center;align-items:center;">
                  <div onclick="hsgSQGyhd444(<?php echo $userhome['id']; ?>)" id="stories_box_image">
                     <img class="lazy" src="<?php echo PATH ?>/newfoto/camera/<?php echo $stories['photo']; ?>.png" style="">
                  </div>
               </div>
            </div>
            <?php }}} ?>
         </div>
         <?php }else{} ?>
      </div>
      <div id="profil66"></div>
      <div id="profil67">
         <?php 	global $db;
            $result = $db->query("SELECT * FROM user_relationships WHERE user_id = '".$userhome['id']."' && type = '1' ORDER BY rand() DESC LIMIT 1");
            if($result->num_rows > 0){
            	while($data = $result->fetch_array()){
            
            	if($data['user_id'] == $userhome['id'])
            	{
            		$friendv = $data['target'];
            	}
            	else
            	if($data['target'] == $userhome['id'])
            	{
            		$friendv = $data['user_id'];
            	}
            
            	$result2 = $db->query("SELECT * FROM users WHERE id = '".$friendv."' ");
            if($result2->num_rows > 0){
            	while($userinfo = $result2->fetch_array()){
            
                        
            
            	?>
         <?php echo $userinfo['username']; ?> 
         <?php }}}}else{ if($userhome['gender'] == 'M'){$gender = 'Soltero';}else{$gender = 'Soltera';} echo $gender; } ?>
         <?php 	global $db;	$result = $db->query("SELECT * FROM user_relationships WHERE user_id = '".$userhome['id']."' && type = '1' ORDER by id DESC"); $info = $result->num_rows;
            $test = $info - 1;
            if($info <= 1){
            $info = "";
            }else{
            $info = ", y otros ".$test."";
            }
            ?>
         <?php echo $info; ?>
      </div>
   </div>
   <div id="profil64">
      <div id="profil65" style="background:rgb(249,208,70);">
         <div id="profil68">
            <div id="profil71" style="color:rgb(155,121,4);"><?php echo number_format($userhome['credits']); ?></div>
         </div>
      </div>
      <div id="profil65" style="background:rgb(130,185,230);">
         <div id="profil69">
            <div id="profil71" style="color:rgb(33,105,165);"><?php echo number_format($userhome['vip_points']); ?></div>
         </div>
      </div>
      <div id="profil65" style="background:rgb(81,81,81);">
         <div id="profil70">
            <div id="profil71" style="font-size:120%;color:white;top:85px"><?php if($userhome['rank'] == 2){ ?>Es VIP<?php }elseif($userhome['rank'] > 2){	?><?php echo $rank['name']; ?><?php }else{	?>No es VIP<?php }	?></div>
         </div>
      </div>
   </div>
   <div class="end"></div>
   <div id="profil72">
      <div id="profil73"></div>
      <div id="profil74">
         <h1><?php if($userhome['username'] == $user['username']){ ?>Mis salas<?php }else{	?>Salas de <?php echo $userhome['username']; ?><?php }	?></h1>
      </div>
      <div id="profil75">
         <?php 	global $db;
            $result = $db->query("SELECT * FROM rooms WHERE owner = '".$userhome['id']."' ORDER BY id DESC LIMIT 4");
            	while($data = $result->fetch_array()){?>
         <div id="profil76">
            <div id="profil77"></div>
            <div id="profil78">
               <center>
                  <p><strong><?php echo $Functions->FilterText($data['caption']); ?></strong></p>
               </center>
            </div>
         </div>
         <?php  } ?>
      </div>
      <div onclick="moreprofil('room','<?php echo $userhome['id']; ?>')" id="profil79">
         Ver todas las salas
      </div>
   </div>
   <div id="profil80">
      <div id="profil81"></div>
      <div id="profil74">
         <h1><?php if($userhome['username'] == $user['username']){ ?>Mis grupos<?php }else{	?>Grupos de <?php echo $userhome['username']; ?><?php }	?></h1>
      </div>
      <div id="profil75">
         <?php 	global $db;
            $result = $db->query("SELECT * FROM group_memberships WHERE user_id = '".$userhome['id']."' ORDER BY id DESC LIMIT 4");
            	while($data = $result->fetch_array()){
                        $resultgroup = $db->query("SELECT * FROM groups WHERE id = '".$data['group_id']."'");
            	while($groupinfo = $resultgroup->fetch_array()){
                        ?>
         <div id="profil76">
            <div id="profil82">
               <img class="" draggable="false" oncontextmenu="return false" alt="<?php echo $Functions->FilterText($groupinfo['name']); ?>" src="<?php echo BADGEGROUPURL . $groupinfo['badge']; ?>.gif" style="">
            </div>
            <div id="profil78">
               <center>
                  <p><strong><?php echo $Functions->FilterText($groupinfo['name']); ?></strong></p>
               </center>
            </div>
         </div>
         <?php  }} ?>
      </div>
      <div onclick="moreprofil('group','<?php echo $userhome['id']; ?>')" id="profil79">
         Ver todos los grupos
      </div>
   </div>
   <div class="end"></div>
   <div id="profil84">
      <h5>TEMAS FORO</h5>
   </div>
   <div id="profil85">
      <?php global $db;
         $busc = $db->query("SELECT * FROM cms_forum WHERE username = '".$userhome['username']."' ORDER BY timec DESC LIMIT 6");
         	while($forum = $busc->fetch_array()){
         		$buscuser = $db->query("SELECT * FROM users WHERE username = '".$forum['username']."'");
         		$userinfo = $buscuser->fetch_array();?>
      <a place="<?php echo $Functions->FilterText($forum['title']); ?> - <?php echo $yezz['hotelname']; ?>" href="/forum/<?php echo $forum['id']; ?>-<?php echo $forum['link']; ?>">
         <div style="background:rgb(176,176,176);" id="forum8">
            <div id="forum9">
               <img class="lazy" alt="<?php echo $userhome['username']; ?>" draggable="false" oncontextmenu="return false" src="<?php echo AVATARIMAGE . $userhome['look']; ?>" />
            </div>
            <div style="color:rgb(110,110,110);" id="forum10">
               <h1 id="forum10n"> <?php echo $Functions->FilterText($forum['title']); ?></h1>
               <p id="forumhx1">
                  <x style="font-size:70%;">Última actividad <?php echo $Functions->GetLast2($forum['timec']); ?> </x>
               </p>
            </div>
         </div>
      </a>
      <?php } ?>
   </div>
   <div class="end"></div>
   <div id="profilpend">
      <p>Mimbro de la familia <?php echo $yezz['hotelname']; ?> desde el <?php setlocale(LC_TIME,"spanish"); echo utf8_encode(strftime("%d-%m-%Y", $userhome['account_created'])); ?></p>
      <div id="profil86"></div>
   </div>
</div>
<div id="profil87"></div>
<div id="strload">
   <div id="strload2">Un instante...</div>
</div>
<strong>
<a style="color:rgba(100,100,100,0); font-size:1px;">habbo perfil, perfil habbo, habbo homepage, homepage habbo, habbo avatar, mi avatar habbo, avatar, habbo, HLatino</a>
</strong>
<div id="rydHSG45s"></div>
<div id="strload">
   <div id="strload2">
      <div id="strload3"></div>
      <br><?php echo $yezz['hotelname']; ?> Stories
   </div>
</div>
<?php
   //COLUMNA FOOTER
     $TplClass->AddTemplate("others", "footer");
   ?>