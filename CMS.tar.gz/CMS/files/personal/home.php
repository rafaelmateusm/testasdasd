<?php
   ob_start();
   require_once '../../global.php';
   
      $TplClass->SetParam('description', 'Aquí está mi perfil');
      $Functions->Logged("true");
      $Functions->pin("true");
   
   //HOTEL CONFIG
   $result2 = $db->query("SELECT * FROM cms_settings WHERE id = 1 LIMIT 1");
   $yezz = $result2->fetch_array();
   //END HOTEL CONFIG
   

   $users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
   $user = $users->fetch_array();
   
   $TplClass->SetParam('title', $yezz['hotelname'] .': '. $user['username']);

   $TplClass->SetAll();
      
   
   $TplClass->AddTemplate("header", "menu");
    
   $dd = $db->query("SELECT * FROM ranks WHERE id = '".$user['rank']."' ORDER BY id DESC");
            $rank = $dd->fetch_array();
   
   ob_end_flush();
   ?>
<div id="appcontent">
<div class='stories'>
   <div id="webcenter">
      <div onclick="FlecheStories()" style="" id="profil20"></div>
      <div id="profil21"><?php echo $yezz['hotelname']; ?> Stories</div>
      <div id="profil22"></div>
      <div id="stories">
         <div style="width:<?php $resulta = $db->query("SELECT * FROM messenger_friendships WHERE user_one_id = '".$user['id']."' OR user_two_id = '".$user['id']."'"); $suma = $resulta->num_rows + 3; echo ($suma * 100);  ?>px;" id="profil23">
            <div style="position:absolute;height:60px;width:2px;background:rgb(100,100,100);left:103px;top:25px;"></div>
            <div onclick="shQH4xs()" id="stories_box">
               <div id="stories_box_rond" style="background:white;overflow:visible;">
                  <div style="position:relative;height:65px;top:-10px;width:70px;left:3px;overflow:hidden;">
                     <img class="lazy" src="<?php echo AVATARIMAGE . $user['look']; ?>" />
                  </div>
                  <div id="profil24">
                     <div id="profil25"></div>
                  </div>
               </div>
               <div id="stories_pseudo">
                  <center>Añadir historia</center>
               </div>
            </div>
            <div id="stories_box">
               <div onclick="hsgSQGyhd444('<?php echo $user['id']; ?>')" id="stories_box_rond" style="background:rgb(112,174,226);">
                  <div id="stories_box_image">
                     <img id="stories_box_image2" src="<?php echo AVATARIMAGE . $user['look']; ?>&action=std&gesture=std&direction=2&head_direction=3&size=l&headonly=1&img_format=png" />
                  </div>
               </div>
               <div id="stories_pseudo">
                  <center>Mi historia</center>
               </div>
            </div>
            <?php 	global $db;





               $result = $db->query("SELECT GROUP_CONCAT(cms_stories.user_id), messenger_friendships.* 
               FROM messenger_friendships INNER JOIN cms_stories 
               on messenger_friendships.user_one_id = cms_stories.user_id AND messenger_friendships.user_two_id = '".$user['id']."' OR messenger_friendships.user_two_id = cms_stories.user_id AND messenger_friendships.user_one_id = '".$user['id']."'
               WHERE messenger_friendships.user_one_id = '".$user['id']."' OR messenger_friendships.user_two_id = '".$user['id']."'
               GROUP BY cms_stories.user_id ORDER BY cms_stories.time DESC");
               while($data = $result->fetch_array()){
               
                 if($data['user_one_id'] == $user['id']){$friendv = $data['user_two_id'];}
                 elseif($data['user_two_id'] == $user['id']){$friendv = $data['user_one_id'];
                 }
                 $result2 = $db->query("SELECT * FROM users WHERE id = '".$friendv."'");
                 $userinfo = $result2->fetch_array();
               
                 $rstories = $db->query("SELECT * FROM cms_stories WHERE user_id = '".$friendv."' ORDER BY time DESC LIMIT 1");
                while($stories = $rstories->fetch_array()){
               
                  $rstoriesv = $db->query("SELECT * FROM cms_stories_views WHERE user_id = '".$user['id']."' AND photo_id = '".$stories['id']."' LIMIT 1");
                 if($rstoriesv->num_rows > 0){
                   $checkview = 'opacity: 0.4;';
                  }else{
                   $checkview = '';
                  }
                 ?>
            <div id="stories_box">
               <div id="stories_box_rond" class="hsQJwn<?php echo $friendv; ?>" style="<?php echo $checkview; ?>">
                  <div onclick="hsgSQGyhd444(<?php echo $friendv; ?>)" id="stories_box_image">
                     <img class="lazy" src="<?php echo PATH ?>/newfoto/camera/<?php echo $stories['photo']; ?>.png">
                  </div>
               </div>
               <div id="stories_pseudo">
                  <center><?php echo $userinfo['username']; ?></center>
               </div>
               <div id="stories5">
                  <div id="stories6">
                     <img class="lazy" src="<?php echo AVATARIMAGE . $userinfo['look']; ?>&action=std&gesture=std&direction=2&head_direction=3&size=s&headonly=1&img_format=png">
                  </div>
               </div>
            </div>
            <?php }} 





$r = $db->query("SELECT * FROM messenger_friendships WHERE user_one_id = '".$user['id']."' OR user_two_id = '".$user['id']."'");
while($friend = $r->fetch_array()){

  if($friend['user_one_id'] == $user['id']){$friendo = $friend['user_two_id'];}
  elseif($friend['user_two_id'] == $user['id']){$friendo = $friend['user_one_id'];
  }
  $ru = $db->query("SELECT * FROM users WHERE id = '".$friendo."'");
  $ui = $ru->fetch_array();

  $storie = $db->query("SELECT * FROM cms_stories WHERE user_id = '".$friendo."'");
  if($storie->num_rows == 0){

  ?>
<div title="Sin historia" style="opacity:0.7;" id="stories_box">
               <div id="stories_box_rond" style="background:white;"><img class="lazy" style="position:relative;top:30px;" src="<?php echo AVATARIMAGE . $ui['look']; ?>&action=std&gesture=std&direction=2&head_direction=3&size=l&headonly=1&img_format=png" /> </div>
               <div id="stories_pseudo">
                  <center><?php echo $ui['username']; ?></center>
               </div>
            </div>
            <?php }} ?>

         </div>
      </div>
   </div>
</div>

<div class="monhabbo">
   <div id="profil26">Mi <?php echo $yezz['hotelname']; ?></div>
   <div id="profil27" style="background:url(<?php echo $Functions->FilterText($user['user_fondo']);?>);">
      <div id="profil28"></div>
      <div id="profil29">
         <img draggable="false" oncontextmenu="return false" id="contourblanc" width="160" src="<?php echo AVATARIMAGE . $user['look']; ?>&action=std,crr=667&gesture=sml&direction=2&head_direction=3&size=l&img_format=png" />
      </div>
      <div id="profil30">Hey,
         <?php echo $user['username']; ?>
      </div>
      <div id="profil31">
         <p id="motto"><?php echo $Functions->FilterText($user['motto']);?></p>
      </div>
   </div>
   <a place="<?php echo $yezz['hotelname']; ?>: Hotel" href="hotel">
      <div id="monhabbohotel">
         <div id="profil32"></div>
         <div id="profil33">
            <center>
               <x style="background:rgb(39,190,107);">Entrar en el hotel</x>
            </center>
         </div>
      </div>
   </a>
   <div id="profil34" style="background:rgb(244,210,76);">
      <div id="profil35" style="background:rgb(241,200,33);">
         <div id="profil36" style="background:url(app/assets/img/pageme.png) -760px -91px;"></div>
      </div>
      <div id="profil37">
         <?php echo number_format($user['credits']);?> 
      </div>
   </div>
   <div id="profil34" style="background:#ea9ad7;">
      <div id="profil35" style="background:#dc66c1;">
         <div id="profil36" style="background:url(app/assets/img/pageme.png) -810px -91px;top:16px;"></div>
      </div>
      <div id="profil37" style="color:#822274;">
         <?php echo number_format($user['activity_points']);?> 
      </div>
   </div>
   <div id="profil34" style="background:rgb(112,174,226);">
      <div id="profil35" style="background:rgb(70,152,219);">
         <div id="profil36" style="background:url(app/assets/img/pageme.png) -760px -142px;"></div>
      </div>
      <div id="profil37" style="color:rgb(33,104,163);">
         <?php echo number_format($user['vip_points']);?>  
      </div>
   </div>
   <div id="profil34" style="background:rgb(68,68,68);margin-right:0px;">
      <div id="profil35" style="background:rgb(41,41,41);">
         <div id="profil36" style="background:url(app/assets/img/pageme.png) -811px -142px;"></div>
      </div>
      <div id="profil37" style="color:white;width:60%;">
         <?php if($user['rank'] == 2){?>
         <p>Eres VIP</p>
         <?php }elseif($user['rank'] > 2){	?>
         <p style="text-overflow: ellipsis;white-space: nowrap;overflow: hidden;"><?php echo $rank['name']; ?></p>
         <?php }else{	?>
         <p>No eres VIP</p>
         <?php }	?>
      </div>
   </div>
</div>
<div class="articles">
   <div onclick="NewsRight();" id="articlesright">
      <div id="profil38"></div>
   </div>
   <div onclick="NewsLeft();" id="articlesleft">
      <div id="profil38" style="background:url(<?php echo PATH ?>/app/assets/img/pageme.png) -932px -12px;left:20px;"></div>
   </div>
   <div id="profil39">
      <div id="articlesui">
         <?php 	global $db;
            $result = $db->query("SELECT * FROM cms_slider ORDER BY id DESC LIMIT 7");
            if($result->num_rows > 0){
              while($data = $result->fetch_array()){
                  
                  $buscuser = $db->query("SELECT * FROM users WHERE username = '".$data['author']."'");
               		$userinfo = $buscuser->fetch_array();?>
         <a place="<?php echo $data['title']; ?> - <?php echo $yezz['hotelname']; ?>" style="color:black;" href="<?php echo PATH ?>/news/<?php echo $data['id']; ?>-<?php echo $data['link']; ?>">
            <div id="articlesbox">
               <div id="fnews1">
                  <img id="fnews2" class="lazy" alt="<?php echo $data['title']; ?>" src="<?php echo $data['image']; ?>" />
               </div>
               <div id="articlespac"></div>
               <div id="articlestitre">
                  <div id="articlestitre_text">
                     <center>
                        <?php echo $data['title']; ?> 
                     </center>
                  </div>
               </div>
               <div id="articlesavatar">
                  <img class="lazy" draggable="false" oncontextmenu="return false" src="<?php echo AVATARIMAGE . $userinfo['look']; ?>&action=std&gesture=std&direction=2&head_direction=2&size=n&headonly=1&img_format=png" />
               </div>
               <div id="articlespseudo">
                  <?php echo $userinfo['username']; ?>
               </div>
               <div id="articleddatet"><?php echo $Functions->GetLastFace($data['time']); ?></div>
               <div id="articleddatei"></div>
            </div>
         </a>
         <?php } } ?>
      </div>
   </div>
</div>
<div id="profil40">
   <div id="profil88">
      <?php 	global $db;
         $result = $db->query("SELECT * FROM cms_eventos ORDER BY id DESC LIMIT 1");
		  if($result->num_rows > 0){
         while($data = $result->fetch_array()){
         
             $resultuser = $db->query("SELECT * FROM users WHERE id = '".$data['user_id']."'");
             $userinfoc = $resultuser->fetch_array();
             ?>
      <div id="profil89">
         <div id="profil90">
            <img class="lazy" style="position:relative;left:-3%;" draggable="false" oncontextmenu="return false" src="<?php echo AVATARIMAGE . $userinfoc['look']; ?>&action=std&gesture=sml&direction=2&head_direction=3&size=l&img_format=png" />
         </div>
         <div id="profil91">
            <div id="profil92"></div>
            Información de <?php echo $userinfoc['username']; ?>
         </div>
         <div id="profil93"><?php echo $data['desc']; ?>
         </div>
      </div>
      <?php }}else{ ?>
	  
	   <div id="profil89">
         <div id="profil90">
            <img class="lazy" style="position:relative;left:-3%;" draggable="false" oncontextmenu="return false" src="<?php echo PATH ?>/app/assets/img/frank.png" />
         </div>
         <div id="profil91">
            <div id="profil92"></div>
            Información de Frank
         </div>
         <div id="profil93">Si necesita ayuda, no dude en hacer clic en el botón del Centro de ayuda justo debajo
         </div>
      </div>
	  
	   <?php } ?>
      <div onclick="OpenSupport('normal','<?php echo PATH ?>/app/load/HelpForum.php')" id="profil94">
         <div id="profil95">Centro de ayuda</div>
         <div id="profil96"></div>
      </div>
      <div id="profil97n">
         <a target="blank" href="https://www.youtube.com/FlavioRoller1">
            <div id="profil97">
               <div id="profil98">
                  <img class="lazy" draggable="false" oncontextmenu="return false" src="<?php echo PATH ?>/app/assets/img/banners/Flavio.png" />
               </div>
               <div id="profil99">Flavio Roller</div>
               <div id="profil100">Visita mi canal y se parte de esta gran familia.</div>
               <div id="profil101">
                  <div id="profi102"></div>
               </div>
            </div>
         </a>
         <a target="blank" href="https://www.hlatino.net/">
            <div id="profil97">
               <div id="profil98">
                  <img class="lazy" draggable="false" oncontextmenu="return false" src="<?php echo PATH ?>/app/assets/img/banners/hlatino.png" />
               </div>
               <div id="profil99">HLatino</div>
               <div id="profil100">Salas Mpu, Swf, Cms, Tutoriales y mas.</div>
               <div id="profil101">
                  <div id="profil102"></div>
               </div>
            </div>
         </a>
      </div>
   </div>
   <div id="profil88">
      <div id="profil103">
         <div id="profil104"></div>
         <div id="profil105">Grupos populares</div>
      </div>
      <?php 	global $db;
         $results = $db->query("SELECT GROUP_CONCAT(group_id) group_id FROM group_memberships GROUP BY group_id HAVING COUNT(group_id)>1 ORDER BY COUNT(group_id) DESC LIMIT 2");
         while($groupinfo = $results->fetch_array()){
          $sql2 = $db->query("SELECT * FROM group_memberships WHERE group_id = '".$groupinfo['group_id']."'");
		  
		  $sql = $db->query("SELECT * FROM groups WHERE id = '".$groupinfo['group_id']."'");
		  while($group = $sql->fetch_array()){
         ?>
      <div id="profil106">
         <div id="profil107">
            <img draggable="false" oncontextmenu="return false" class="lazy" src="<?php echo BADGEGROUPURL . $group['badge']; ?>.gif" />
         </div>
         <div id="profil108"><?php echo $Functions->FilterText($group['name']); ?></div>
         <div id="profil109">...</div>
         <div id="profil110"><?php echo number_format($sql2->num_rows); ?></div>
      </div>
      <?php }} ?>
      <a place="<?php echo $yezz['hotelname']; ?>: Las salas más prestigiosas" href="<?php echo PATH ?>/prestige/rooms">
         <div id="profil111">
            <div id="profil112">Ver grupos</div>
         </div>
      </a>
   </div>
   <div style="overflow:hidden;" id="profil88">
      <div id="profil113">
         <div id="profil114"></div>
         <div id="profil105">Últimos temas del foro</div>
      </div>
      <?php global $db;
         $busc = $db->query("SELECT * FROM cms_forum WHERE category >= 'c1' AND category <= 'c6' ORDER BY id DESC LIMIT 6");
         	while($forum = $busc->fetch_array()){
         		$buscuser = $db->query("SELECT * FROM users WHERE username = '".$forum['username']."'");
         		$userinfo = $buscuser->fetch_array();?>
      <a place="<?php echo $Functions->FilterText($forum['title']); ?> - <?php echo $yezz['hotelname']; ?>" style="color:black;" href="<?php echo PATH ?>/forum/<?php echo $forum['id']; ?>-<?php echo $forum['link']; ?>">
         <div id="profil115">
            <div id="profil116">
               <img class="lazy" draggable="false" oncontextmenu="return false" src="<?php echo AVATARIMAGE . $userinfo['look']; ?>&amp;direction=3&amp;head_direction=3&amp;gesture=sml&headonly=1" />
            </div>
            <div id="profil117" style="width:75%;">
               <?php echo $Functions->FilterText($forum['title']); ?>
            </div>
            <div id="profil118"><?php echo $Functions->GetLast($forum['time']); ?></div>
         </div>
      </a>
      <?php } ?>
   </div>
</div>
<div id="profil45">
   <div id="profil45n">
   </div>
   <div id="profil46">
      <div id="profil48">
         <div id="profil49"></div>
      </div>
      <div id="profil50">
         <center>
            <iframe class="lazy" scrolling="no" style="border:0;width:450px;height:422px;" src="app/social/facebook.php"></iframe>
         </center>
      </div>
   </div>
   <div style="position:absolute;width:calc(50% - 10px);right:0px;top:135px;">
      <div id="profil48" style="background:rgb(40,169,224);">
         <div id="profil49" style="width:100px;background:url(<?php echo PATH ?>/app/assets/img/pageme.png) -819px 0px;"></div>
      </div>
      <div id="profil50">
         <iframe style="border:0;width:100%;height:100%;" class="lazy" src="app/social/twitter.php"></iframe>
      </div>
   </div>
</div>
<div id="rydHSG45s"></div>
<div id="strload">
   <div id="strload2">
      <div id="strload3"></div>
      <br><?php echo $yezz['hotelname']; ?> Stories
   </div>
</div>
<?php
   //COLUMNA FOOTER
     $TplClass->AddTemplate("others", "footer");
   ?>