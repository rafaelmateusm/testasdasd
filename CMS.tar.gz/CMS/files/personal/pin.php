<?php
   ob_start();
   require_once '../../global.php';
   $Functions->Logged("true");
   $TplClass->SetAll();
   
   $result = $db->query("SELECT * FROM cms_settings WHERE id = 1 LIMIT 1");
   $data = $result->fetch_array();

   $users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
   $user = $users->fetch_array();

   $TplClass->SetParam('title', $data['hotelname'].': PIN de Seguridad');
   $TplClass->SetParam('description', $data['hotelname'].': PIN de Seguridad');
   $TplClass->AddTemplate("header", "menu");
   
   ob_end_flush();
   ?>
<div id="appcontent">
<div id="pin1"></div>
<div id="pin2">
   <div id="pin3">
      <div id="pin4"></div>
      <div id="pin5">
         La cuenta está bloqueada<br>
         <div id="pinmsg">Tienes <u><?php echo $user['pin_intentos']; ?></u> intentos para desbloquearlo</div>
      </div>
   </div>
   <div id="pin6" onclick="LockPin();">Desbloquear ahora</div>
   <div id="pin7" style="display:none;">
      <div id="settings49">
         <div onclick="CliquePin('a');" id="a" class="pin">..</div>
         <div onclick="CliquePin('b');" id="b" class="pin">..</div>
         <div onclick="CliquePin('c');" id="c" class="pin">..</div>
         <div onclick="CliquePin('d');" id="d" class="pin">..</div>
         <div onclick="CliquePin('e');" id="e" class="pin">..</div>
         <div onclick="CliquePin('f');" id="f" class="pin">..</div>
         <div onclick="CliquePin('g');" id="g" class="pin">..</div>
         <div onclick="CliquePin('h');" id="h" class="pin">..</div>
         <div onclick="CliquePin('i');" id="i" class="pin">..</div>
         <div onclick="CliquePin('j');" id="j" class="pin">..</div>
         <div onclick="CliquePin('x');" class="pinreset">BORRAR</div>
      </div>
      <div id="pin8">
         <input type="text" id="currentpin" placeholder="Ingrese su PIN" class="indexinput" readonly="readonly" style="width:calc(100% - 25px);" />
         <div <?php if($user['pin_intentos'] == 0){}else{ ?>onclick="PostSecurePin();"<?php } ?> id="pin9">CONFIRMAR</div>
         <div onclick="LostPin('one')" id="pin10">Olvidé mi código</div>
      </div>
   </div>
   <div id="pin11">
      <center>
         <div id="pin12">¿Desea recibir su código por correo electrónico?</div>
      </center>
      <div onclick="LostPin('close')" id="pin13">No</div>
      <div onclick="LostPin('two')" id="pin13" style="background:rgb(34,177,76);left:303px;">Sí</div>
   </div>
</div>
<?php
   //COLUMNA FOOTER
     $TplClass->AddTemplate("others", "footer");
   ?>