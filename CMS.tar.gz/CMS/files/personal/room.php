<?php
    ob_start();
	require_once '../../global.php';
	$Functions->Logged("true");
	$TplClass->SetAll();
	
    $result = $db->query("SELECT * FROM cms_settings WHERE id = 1 LIMIT 1");
	$data = $result->fetch_array();
	
	$description = 'Estas jugando en '.$data['hotelname'];
	
	$getroom = $Functions->FilterText($_GET['room']);
	
	$resultroom = $db->query("SELECT * FROM rooms WHERE id = '".$getroom."'");
	$roominfo = $resultroom->fetch_array();

	$resultuser = $db->query("SELECT * FROM users WHERE id = '".$roominfo['owner']."'");
	$userinfo = $resultuser->fetch_array();

	$TplClass->SetParam('title', $roominfo['caption']);
	$TplClass->AddTemplate("header", "menu");

	ob_end_flush();
?>
<div id="appcontent">
<style>
        body {
            background: rgb(230, 230, 230);
        }
    </style>
<div id="webcenter">
<div id="room1">Estas siendo redireccionado a la sala <u><?php echo $Functions->FilterText($roominfo['caption']); ?></u> de <u><?php echo $userinfo['username'];?></u></div><meta http-equiv="Refresh" content="3;url=<?php echo PATH; ?>/hotel/<?php echo $Functions->FilterText($_GET['room']); ?>"> </div>
</div>
</div>

<?php
//COLUMNA FOOTER
  $TplClass->AddTemplate("others", "footer");
?>