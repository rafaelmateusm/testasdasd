<?php
   ob_start();
   
   require_once '../../global.php';
   $Functions->Logged("false");
   
   //HOTEL CONFIG
   $result2 = $db->query("SELECT * FROM cms_settings WHERE id = 1 LIMIT 1");
   $yezz = $result2->fetch_array();
   //END HOTEL CONFIG
   
   //IP BAN
        $ip = $Functions->getRealIP();
        $checkban = $db->query("SELECT * FROM bans WHERE value = '".$ip."' LIMIT 1");
   	while($mant = $checkban->fetch_array()){
      $_SESSION['LOGIN_ERROR'] = "Tu IP ha sido baneada";
       header("LOCATION: ". PATH ."/index");
   }
   //END IP BAN

   $checkipusers = $db->query("SELECT * FROM users WHERE ip_reg = '".$ip."'");
   
     $TplClass->SetParam('username', '');
     $TplClass->SetParam('password', '');
     $users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
   
   if( $_SESSION['LOGIN_ERROR'] ){
   	$TplClass->SetParam('error', '<div class="error e_top bounceInLeft animated">'.$_SESSION['LOGIN_ERROR'].'</div>');
   	$TplClass->SetParam('username', $_SESSION['LOGIN_USERNAME']);
   	$TplClass->SetParam('password', $_SESSION['LOGIN_PASSWORD']);
   	unset($_SESSION['LOGIN_ERROR'], $_SESSION['LOGIN_USERNAME'], $_SESSION['LOGIN_PASSWORD'], $_SESSION['LOGIN_ERRORIP']);
   }
   
   if( $_SESSION['ERROR_RETURN'] ){
   	$TplClass->SetParam('error', '<div class="error e_top bounceInLeft animated">'.$_SESSION['ERROR_RETURN'].'</div>');
   	unset($_SESSION['ERROR_RETURN']);
   }
   
   if( $_SESSION['GOOD_RETURN'] ){
   	$TplClass->SetParam('error', '<div class="error tctm success">'.$_SESSION['GOOD_RETURN'].'</div>');
   	unset($_SESSION['GOOD_RETURN']);
   }
      
   
   ?>
<!DOCTYPE html>
<html lang="es">
   <head>
      <link rel="shortcut icon" href="<?php echo PATH; ?>/app/assets/img/favicon.ico" type="image/vnd.microsoft.icon" />
      <base href="<?php echo PATH ?>/" />
      <meta http-equiv="content-type" content="text/html; charset=utf-8" />
      <meta name="robots" content="index,follow,all" />
      <meta name="viewport" content="width=device-width,initial-scale=0.4">
      <meta name="theme-color" content="#00a2e8" />
      <meta name="keywords" content="<?php echo $yezz['hotelname']; ?>, pixeled, forbi, habbo, habbo hoteles, habbo plux, habboplux, hplux, plux, yezzcms, yeezycms, yezz, yeezy, forb, forbi, créditos grátis, retro, habbo creditos, habbo creditos gratis, hc gratis, hc, diseños, salas, habbo-plux, plux, facebook, twitter, el mejor holo, holo, habbo holo, creditos infinos, hc infinito, el mejor holo, furnis, nuevos furnis, habbo custom, nombre de color, prefijo, tag, hotel, habbo hotel, amigos, nuevos amigos, juego online, online.">
      <meta name="Geography" content="España">
      <meta name="country" content="España">
      <meta name="Language" content="Español">
      <meta name="identifier-url" content="<?php echo PATH ?>/" />
      <meta name="Copyright" content="<?php echo $yezz['hotelname']; ?>" />
      <meta name="Copyright" content="Forbi (Edit)">
      <meta name="language" content="es_ES">
      <meta name="hreflang" content="es_ES">
      <meta name="category" content="Website">
      <meta name="author" content="Forbi (Edit)">
      <meta property="og:site_name" content="<?php echo $yezz['hotelname']; ?>" />
      <meta property="og:image" content="<?php echo PATH ?>/app/assets/img/miniatura.png" />
      <meta property="og:locale" content="es_ES">
      <meta property="og:url" content="<?php echo PATH ?>/<?php echo $url; ?>" />
      <meta property="og:type" content="website">
      <meta property="og:description" content="<?php echo $yezz['hotelname']; ?> es un juego gratuito que te permite crear tu propio personaje y acceder a un mundo donde puedes hacer miles de reuniones. Nuestro equipo de animadores ofrece animaciones todos los días. ¿Te convertirás en el jugador más popular en el hotel?" />
      <meta property="og:title" content="<?php echo $yezz['hotelname']; ?> Hotel" />
      <meta name="twitter:title" content="<?php echo $yezz['hotelname']; ?> Hotel">
      <meta name="twitter:description" content="<?php echo $yezz['hotelname']; ?> es un juego gratuito que te permite crear tu propio personaje y acceder a un mundo donde puedes hacer miles de reuniones. Nuestro equipo de animadores ofrece animaciones todos los días. ¿Te convertirás en el jugador más popular en el hotel?">
      <meta name="twitter:site" content="@PixeledES">
      <meta name="twitter:image:src" content="<?php echo PATH ?>/app/assets/img/miniatura.png" />
      <meta name="twitter:domain" content="<?php echo PATH ?>/" />
      <meta name="description" content="<?php echo $yezz['hotelname']; ?> es un juego gratuito que te permite crear tu propio personaje y acceder a un mundo donde puedes hacer miles de reuniones. Nuestro equipo de animadores ofrece animaciones todos los días. ¿Te convertirás en el jugador más popular en el hotel?" />
      <link rel="dns-prefetch" href="<?php echo PATH ?>" />
      <link rel="stylesheet" href="app/assets/css/power.css" type="text/css" media="all" />
      <title><?php echo $yezz['hotelname']; ?>: Haz nuevos amigos, crea tus salas y diviértete al máximo.</title>
   </head>
   <div id="loader">
      <div id="loader-spin"></div>
   </div>
   <div style="position: absolute;bottom: 0; left: 0; right: 0">
      <strong>
      <a style="color:rgba(100,100,100,0); font-size:1px;">habbo, habbo hoteles, habbo plux, habboplux, hplux, plux, yezzcms, yeezycms, yezz, yeezy, forb, forbi, créditos grátis, retro, habbo creditos, habbo creditos gratis, hc gratis, hc, diseños, salas, habbo-plux, plux, facebook, twitter, el mejor holo, holo, habbo holo, creditos infinos, hc infinito, el mejor holo, furnis, nuevos furnis, habbo custom, nombre de color, prefijo, tag, hotel, habbo hotel, amigos, nuevos amigos, juego online, online, pixeled, juegos gratis, juego gratis, créditos gratis, diamantes grátis, todo gratis, habbo grati, habbo holo, yezzcms.</a>
      </strong>
   </div>
   <body>
      <div id="HotelManager"></div>
      <div id="appcontent">
      
      <style>
        body {
            background: #00a2e8;
            margin-bottom: 0px;
            background:url(/app/assets/img/pixeled.png);
        }
    </style>
      <div id="index22">
         <div id="webcenter">
            <div id="index23"><div class="com20283" id="lecture40" style="left:85px;top:-13px;width:170%">
<div id="habboforumbulle" style="left:73px;top:34px;"></div>
<div id="lecture41">
<div id="articlescomtext">
<b><?php echo $Functions->GetOns() ?></b><strong> usuarios jugando</strong></div>
</div>
</div></div>
            <div id="indexdescription">
               <h1><strong>Un lugar sorprendente con gente genial, únete a la diversión.</strong></h1>
            </div>
            <div id="index24">
               <div id="index25"></div>
               <div id="index26">
                  <h2 style="font-size:135%;">Una comunidad soldada</h2>
                  <p>Únete a nosotros y se parte de nuestra comunidad entrañable y alegre. 
                     Usted será bienvenido por todo el equipo y por los usuarios de nuestro hotel.</strong>
               </div>
            </div>
            <div id="index27">
               <div id="index28">
                  <div id="indexfigure"><img draggable="false" oncontextmenu="return false" src="/app/assets/img/index/hey.png"></img></div>
                  <div id="indexusername">
                     <x>HEY</x>
                     , CONECTAR
                  </div>
               </div>
               <form id="FormConnexion" style="position:absolute;right:0px;height:245px" action="app/actions/Connection.php" method="post">
                  <style>
                     #indexcaptcha {
                     display: none
                     }
                  </style>
                  <input type="text" id="identifiant" name="username" onkeyup="loadlook()" autofocus=""  placeholder="Nombre de Usuario" class="indexinput" />
                  <div id="indexformsepare"></div>
                  <input type="password" id="password" name="password" placeholder="Contraseña"  class="indexinput" />
                  <div id="indexformsepare"></div>
                  <button id="indexsubmit" type="submit">
                     <p><strong>Conectarme</strong></p>
                  </button>
                  <div onclick="OpenMdpPerdu()" style="position:relative;color:white;top:7px;cursor:pointer;">
                     <p><u>¿Contraseña olvidada?</u>
                     </p>
                  </div>
               </form>
               <div id="index29">
                  <div id="buttonreseaux">
                        <div id="buttonreseaux2">Inicia sesión con redes sociales</div>
                  </div>
                  <div id="index30">
                     <p><strong>¿Usted no está registrado todavía? </strong></p>
                  </div>
                  <div id="index31"></div>
                  <?php if($checkipusers->num_rows > 2){ ?>
                    <div id="indexminscrire">
                        <h3>Registrarme</h3>
                     </div>
                     <?php }else{ ?>
                  <a href="<?php echo PATH ?>/register">
                     <div id="indexminscrire">
                        <h3>Registrarme</h3>
                     </div>
                  </a>
                  <?php } ?>>
               </div>
            </div>
         </div>
      </div>
      <div class="end"></div>
      <div id="index32">
         <div id="webcenter">
            <div id="index33">
               <h1>Últimas noticias del hotel</h1>
            </div>
            <div id="index34">
               <?php 	global $db;
                  $result = $db->query("SELECT * FROM cms_slider ORDER BY id DESC LIMIT 6");
                  if($result->num_rows > 0){
                    while($data = $result->fetch_array()){?>
               <a place="<?php echo $data['title']; ?> - <?php echo $yezz['hotelname']; ?>" style="color:black;" href="<?php echo PATH ?>/news/<?php echo $data['id']; ?>-<?php echo $data['link']; ?>">
                  <div id="articlesbox" style="height:235px;width:calc(33.33% - 20px);margin-bottom:15px;">
                     <div id="indexlire">Leer más</div>
                     <div id="fnews1">
                        <img alt="<?php echo $data['title']; ?>" id="fnews2" src="<?php echo $data['image']; ?>" />
                     </div>
                     <div id="articlespac"></div>
                     <div id="indexartitre" style="width:90%;text-overflow: ellipsis;white-space: nowrap;overflow: hidden;">
                        <?php echo $data['title']; ?>
                     </div>
                     <div id="indexshadow"></div>
                  </div>
               </a>
               <?php } } ?>
            </div>
         </div>
      </div>
      <div class="end"></div>
      <noscript>
         <div id="indexscript1">
            <div id="webcenter">
               <div id="indexscript2"></div>
               <div id="indexscript3"><?php echo $yezz['hotelname']; ?> funciona mejor con JavaScript</div>
            </div>
         </div>
      </noscript>
      <div id="index35">
         <div id="indexetoiles2"></div>
         <div id="indexetoiles"></div>
         <div id="index36">
            <div id="index37">
               <div id="index38">
                  <h2>Los mejores jugadores</h2>
               </div>
               <div id="indexsocle"></div>
               <?php
                              //Top, puntos
                                $resultpuntos = $db->query("SELECT * FROM users WHERE rank < 4 ORDER BY puntos_eventos DESC LIMIT 1");
                                $puntos = $resultpuntos->fetch_array();
                                $resultpuntos2 = $db->query("SELECT * FROM users WHERE puntos_eventos < '".$puntos['puntos_eventos']."' AND rank < 4 ORDER BY puntos_eventos DESC LIMIT 1");
                                $puntos2 = $resultpuntos2->fetch_array();
                                $resultpuntos3 = $db->query("SELECT * FROM users WHERE puntos_eventos < '".$puntos2['puntos_eventos']."' AND rank < 4 ORDER BY puntos_eventos DESC LIMIT 1");
                                $puntos3 = $resultpuntos3->fetch_array();
                  						//END Top, puntos 
                  						?>
               <a place="<?php echo $yezz['hotelname']; ?>: <?php echo $puntos['username']; ?>" href="<?php echo PATH ?>/profile/<?php echo $puntos['username']; ?>">
                  <div title="<?php echo $puntos['username']; ?> : <?php echo $puntos['puntos_eventos']; ?> puntos" id="socleusertwo" style="background:url(<?php echo AVATARIMAGE . $puntos['look']; ?>&action=sit&size=l);"></div>
               </a>
               <a place="<?php echo $yezz['hotelname']; ?>: <?php echo $puntos2['username']; ?>" href="<?php echo PATH ?>/profile/<?php echo $puntos2['username']; ?>">
                  <div title="<?php echo $puntos2['username']; ?> : <?php echo $puntos2['puntos_eventos']; ?> puntos" id="socleuserone" style="background:url(<?php echo AVATARIMAGE . $puntos2['look']; ?>&action=sit&size=l);"></div>
               </a>
               <a place="<?php echo $yezz['hotelname']; ?>: <?php echo $puntos3['username']; ?>" href="<?php echo PATH ?>/profile/<?php echo $puntos3['username']; ?>">
                  <div title="<?php echo $puntos3['username']; ?> : <?php echo $puntos3['puntos_eventos']; ?> puntos" id="socleuserthr" style="background:url(<?php echo AVATARIMAGE . $puntos3['look']; ?>&action=sit&size=l);"></div>
               </a>
            </div>
            <div id="index39">
               <div id="index40">
                  <h2>Últimos temas del foro</h2>
               </div>
               <div id="index50">
                  <?php global $db;
                     $busc = $db->query("SELECT * FROM cms_forum ORDER BY id DESC LIMIT 4");
                     	while($forum = $busc->fetch_array()){
                     		$buscuser = $db->query("SELECT * FROM users WHERE username = '".$forum['username']."'");
                     		$userinfo = $buscuser->fetch_array();?>
                  <a place="<?php echo $Functions->FilterText($forum['title']); ?> - <?php echo $yezz['hotelname']; ?>" style="color:black;" href="<?php echo PATH ?>/forum/<?php echo $forum['id']; ?>-<?php echo $forum['link']; ?>">
                     <div id="opac" class="index51">
                        <div id="index52">
                           <div id="habboforumavatar" style="height:120px;top:-10px;left:-4px;"><img id="habboforumwhite" width="90" draggable="false" oncontextmenu="return false" src="<?php echo AVATARIMAGE . $userinfo['look']; ?>&headonly=1&direction=2&head_direction=2&action=&gesture=&size=m" /></div>
                           <div id="index53"><u><?php echo $userinfo['username']; ?></u> :
                              <?php echo $Functions->FilterText($forum['title']); ?>
                           </div>
                           <div id="habboforumbulle" style="top:38px;left:80px;"></div>
                        </div>
                     </div>
                  </a>
                  <?php } ?>
               </div>
            </div>
         </div>
      </div>
      <div id="index54">
         <div id="index55">
            <a place="<?php echo $yezz['hotelname']; ?>: Condiciones de uso" href="<?php echo PATH ?>/conditions" style="color:white;">
            <u><strong>Condiciones de uso</strong></u></a> |
            <a target="blank" href="<?php echo $yezz['facebook']; ?>" style="color:white;">
            <u><strong>Contáctenos </strong></u></a> |
            <a place="<?php echo $yezz['hotelname']; ?>: Crea un avatar" href="<?php echo PATH ?>/register" style="color:white;">
            <u>Registrarme</u></a>
            <div style="position:absolute;right:0px;top:0px;">© <?php echo $yezz['hotelname']; ?>, 2017 - 2018</div>
         </div>
      </div>

<div id="indexl1">
<div onclick="CloseMdpPerdu();" style="top:75px;" id="fermeture"></div>
<div id="indexl2">
<div id="indexl2n">
<div id="indexl3">Olvidé mi contraseña</div>
<input class="lostmail" id="indexl4" placeholder="Dirección de correo electrónico"></input>
<div onclick="MdpPerdu()" id="indexl5">
<div id="b63"></div>
Enviar
</div>
<input id="indexl6" placeholder="Recopie le code"></input>
<div id="indexl7">
<img id="indexl8" src="/app/captcha/captchacolor.php?figure=<?php echo $Functions->GenerateCaptcha(); ?>" />
</div>
</div>
<div id="indexl9">
<div id="indexl3">Cambia tu contraseña!</div>
<input class="cdcode" placeholder="El código recibido por correo electrónico"></input>
<input type="password" class="cdmdp" placeholder="Nueva contraseña"></input>
<input type="password" class="cdmdp2" placeholder="Nueva contraseña (otra vez)"></input>
<div onclick="MdpPerduEnd()" class="cd15" style="top:6px;right:30px;" id="indexl5">
<div id="b63"></div>
Terminar
</div>
</div>
</div>
</div>




      <div id="secu1">
         <div id="secu2">
            <div id="secu3">Un instante...</div>
            <div id="secuload"></div>
         </div>
      </div>
   </body>

   <script src="app/assets/js/jquery.js" charset="utf-8"></script>
   <script src="app/assets/js/power.js" charset="utf-8"></script>
</html>