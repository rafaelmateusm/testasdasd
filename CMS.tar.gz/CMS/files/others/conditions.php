<?php
    ob_start();
	require_once '../../global.php';
	$Functions->Logged("true");
	$TplClass->SetAll();
	
    $result = $db->query("SELECT * FROM cms_settings WHERE id = 1 LIMIT 1");
	$data = $result->fetch_array();

	$TplClass->SetParam('title', $data['hotelname'].': Conditions dUtilisation');
	$TplClass->AddTemplate("header", "menu");

	ob_end_flush();
?>



<div id="webcenter" class="con">
<h1 id="con1">Bienvenue sur le site Internet&nbsp;<strong>HabboCity</strong></h1>
<div id="con2">
<p>Nous vous remercions de lire attentivement l'ensemble des dispositions ci-dessous qui régissent l'utilisation du Site (ci-après désignées les "Conditions d'Utilisation"). L’accès au Site et aux services proposés sont réservés aux personnes âgées de plus de 10 ans.</p>
</div>
<div id="con3">
<p><strong id="con4">Si vous avez moins de 18 ans, vous devez demander à vos parents ou tuteurs de vous expliquer tous les termes ou expressions utilisés ci-dessous que vous ne comprenez pas et valider avec eux votre décision d'accepter l'ensemble des Conditions d'Utilisation.</strong></p>
<br>
<p></p><h2><u>1. Conditions d'accès au jeu:</u></h2><p></p>
<br>
<p><strong>1.2</strong> Habbocity est un jeu gratuit pour y accéder ainsi qu'y jouer. Nous proposons cependant des services optionnels payants, avec des services haut de gamme en option sur le site par achat direct ou par l'achat de CityCash. Ces services optionnels peuvent comprendre notamment l'adhésion au CityClub, l'achat de badge personnalisé, badges. L'achat de ces articles haut de gamme en option ne soumet pas de droit de rétractation.</p>
<p><strong>1.3</strong> Nous ne sommes en aucun cas tenus responsables de tout problème de paiement ou de transaction avec le service de la "Boutique Habbocity". Aucun remboursement ne peut être effectué en cas de problème technique.</p>
<p><strong>1.4</strong> Toute arnaque de crédits, rares ou divers mobis n'est pas de notre responsabilité. En cas de ce genre de problème nous ne sommes donc pas responsables.</p>
<p><strong>1.5 </strong> Pour utiliser les fonctionnalités proposées par le site (ces fonctionnalités sont désignées par le "Service"), vous devez vous enregistrer. Pour permettre votre enregistrement, vous devez nous fournir les informations qui vous seront demandées. Vous devrez ainsi nous informer de toute modification éventuelle de ces informations par email.</p>
<p><strong>1.6</strong> En cas d'oubli de votre mot de passe, vous devez nous informer votre nom d'utilisateur suivi de votre adresse email liée à votre compte. Un lien de réinitialisation pour changer votre mot de passe vous sera envoyé par mail dans les 2 minutes qui suivent.</p>
<br>
<p></p><h2><u>2. Régles à respecter:</u></h2><p></p>
<br>
<p><strong> 2.1</strong> Ce que tu ne peux pas faire : Par exemple, insulter des joueurs quelconques ou bien leur demander leurs identifiants de compte. Si les auteurs de ces faits sont retrouvés (ce qui est facile pour notre équipe de modération), une exclusion définitive sera prononcée sans avis préalable.</p>
<p><strong>2.2 </strong>Toutes les activités sexuelles imaginables sur un jeu en ligne sont exclues de Habbocity. Les discussions et comportements de ce type sont interdits, dans le souci de garantir à nos utilisateurs leur sécurité et écarter les individus suspects de notre plateforme. Ceci s'applique à la demande de plan cam.</p>
<p><strong>2.3</strong> Il est impossible de supprimer un compte mais vous pouvez néanmoins faire une demande de désactivation du compte via le Support Client&nbsp;du site.</p>
<p><strong>2.4</strong> La publicité envers un autre serveur similaire à celui de Habbocity est strictement interdite. Dans l'hôtel en message privé, en invitation ou même en tchat direct avec les autres joueurs. En cas de publicité, un bannissement permanent aura lieu sur votre compte ainsi que sur votre Ip internet.</p>
<p><strong>2.5</strong> Les appels à l'aide inutile vers des modérateurs comme une fausse demande par exemple; Les staffs ont des choses plus importantes à faire ! Penser à la priorité de votre demande d'aide avant de l'envoyer. Ceci est donc pénalisé au départ d'un simple avertissement puis à la longue si cela se reproduit d'une exclusion temporaire.</p>
<p><strong>2.6&nbsp;</strong> Nous nous réservons le droit d'approuver ou de rejeter tout nom d'utilisateur ou nom de groupe que vous aurez choisis.</p>
<p><strong>2.7</strong>&nbsp;Parler d'un autre serveur similaire à celui de Habbocity sans même citer le nom de celui-ci est tout de même interdit.</p>
<p><strong>2.8</strong>&nbsp;Les comptes clones créés pour abuser seront immédiatement exclus.</p>
<p><strong>2.9</strong>&nbsp;Toute vente de mobilier sur Habbocity en échange d'argent réel sera considérée comme une faute grave et entraînera une exclusion permanente.</p>
<br>
<p></p><h2><u>3. Tu t'engages à ne pas:</u></h2><p></p>
<br>
<p><strong>3.1 </strong>Abuser, harceler, menacer, tenir des propos diffamatoires, obscènes, racistes ou portant atteinte aux droits des autres (notamment les droits au respect de la vie privée).</p>
<p><strong>3.2</strong>&nbsp;Restreindre ou empêcher l'utilisation du Service pour tout autre utilisateur.</p>
<p><strong>3.3 </strong>Enfreindre les règles de bonne conduite, ou toute règle édictée sur le site pour tout service ou évènement particulier.</p>
<p><strong>3.4 </strong>Tenter d'induire en erreur d'autres utilisateurs en créant une fausse identité ou en usurpant le nom d'autrui.&nbsp;</p>
<p><strong>3.5 </strong>Refuser de suivre les instructions d'un membre de l'équipe d'HabboCity.</p>
<p><strong>3.6 </strong>Transmettre des informations personnelles d'une personne interne ou externe à HabboCity permettant de l'identifier.</p>
<p><strong>3.7</strong>&nbsp;Utiliser HabboCity à travers une autre adresse IP (De par un VPN par exemple).</p>
<br>
<p></p><h2><u>4. L'utilisation des cookies:</u></h2><p></p>
<br>
<p>Les cookies nous permettent de <strong>personnaliser le contenu et les annonces</strong>, d'offrir des fonctionnalités relatives aux médias sociaux d'HabboCity et d'<strong>analyser notre trafic</strong>. Nous partageons également des informations sur l'utilisation de notre site avec nos partenaires de médias sociaux, de publicité et d'analyse, qui peuvent combiner celles-ci avec d'autres informations que vous leur avez fournies ou qu'ils ont collectées lors de votre utilisation de leurs services.</p>
<br><p><strong style="font-size:120%;color:rgb(80,80,80)">AVANT TOUTE UTILISATION DU SITE, TU RECONNAIS AVOIR PRIS CONNAISSANCE ET ACCEPTER LES PRESENTES CONDITIONS D'UTILISATION.</strong></p>
<br><b>Dernière mise à jour le: <strong>10 avril 2017</strong>.</b>
</div>
</div>




<?php
//COLUMNA FOOTER
  $TplClass->AddTemplate("others", "footer");
?>