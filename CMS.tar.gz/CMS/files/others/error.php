<?php
   require_once '../../global.php';
   
   //HOTEL CONFIG
   $result2 = $db->query("SELECT * FROM cms_settings WHERE id = 1 LIMIT 1");
   $yezz = $result2->fetch_array();
   //END HOTEL CONFIG
   ?>
<!DOCTYPE html>
<html>
   <head>
      <link rel="shortcut icon" href="<?php echo PATH; ?>/app/assets/img/favicon.ico" type="image/vnd.microsoft.icon" />
      <base href="<?php echo PATH ?>/" />
      <meta http-equiv="content-type" content="text/html; charset=utf-8" />
      <meta name="robots" content="index,follow,all" />
      <meta name="viewport" content="width=device-width,initial-scale=0.4">
      <meta name="theme-color" content="#00a2e8" />
      <meta name="keywords" content="<?php echo $yezz['hotelname']; ?>, pixeled, forbi, habbo, habbo hoteles, habbo plux, habboplux, hplux, plux, yezzcms, yeezycms, yezz, yeezy, forb, forbi, créditos grátis, retro, habbo creditos, habbo creditos gratis, hc gratis, hc, diseños, salas, habbo-plux, plux, facebook, twitter, el mejor holo, holo, habbo holo, creditos infinos, hc infinito, el mejor holo, furnis, nuevos furnis, habbo custom, nombre de color, prefijo, tag, hotel, habbo hotel, amigos, nuevos amigos, juego online, online.">
      <meta name="Geography" content="España">
      <meta name="country" content="España">
      <meta name="Language" content="Español">
      <meta name="identifier-url" content="<?php echo PATH ?>/" />
      <meta name="Copyright" content="<?php echo $yezz['hotelname']; ?>" />
      <meta name="Copyright" content="Forbi (Edit)">
      <meta name="language" content="es_ES">
      <meta name="hreflang" content="es_ES">
      <meta name="category" content="Website">
      <meta name="author" content="Forbi (Edit)">
      <meta property="og:site_name" content="<?php echo $yezz['hotelname']; ?>" />
      <meta property="og:image" content="<?php echo PATH ?>/app/assets/img/miniatura.png" />
      <meta property="og:locale" content="es_ES">
      <meta property="og:url" content="<?php echo PATH ?>/" />
      <meta property="og:type" content="website">
      <meta property="og:description" content="<?php echo $yezz['hotelname']; ?> es un juego gratuito que te permite crear tu propio personaje y acceder a un mundo donde puedes hacer miles de reuniones. Nuestro equipo de animadores ofrece animaciones todos los días. ¿Te convertirás en el jugador más popular en el hotel?" />
      <meta property="og:title" content="<?php echo $yezz['hotelname']; ?> Hôtel" />
      <meta name="twitter:title" content="<?php echo $yezz['hotelname']; ?> Hotel">
      <meta name="twitter:description" content="<?php echo $yezz['hotelname']; ?> es un juego gratuito que te permite crear tu propio personaje y acceder a un mundo donde puedes hacer miles de reuniones. Nuestro equipo de animadores ofrece animaciones todos los días. ¿Te convertirás en el jugador más popular en el hotel?">
      <meta name="twitter:site" content="@PixeledES">
      <meta name="twitter:image:src" content="<?php echo PATH ?>/app/assets/img/miniatura.png" />
      <meta name="twitter:domain" content="<?php echo PATH ?>/" />
      <meta name="description" content="<?php echo $yezz['hotelname']; ?> es un juego gratuito que te permite crear tu propio personaje y acceder a un mundo donde puedes hacer miles de reuniones. Nuestro equipo de animadores ofrece animaciones todos los días. ¿Te convertirás en el jugador más popular en el hotel?" />
      <link rel="dns-prefetch" href="<?php echo PATH ?>" />
      <link rel="stylesheet" href="app/assets/css/power.css" type="text/css" media="all" />
      <title><?php echo $yezz['hotelname']; ?>: Página no encontrada.</title>
   </head>
   <div id="loader">
      <div id="loader-spin"></div>
   </div>
   <div style="position: absolute;bottom: 0; left: 0; right: 0">
      <strong>
      <a style="color:rgba(100,100,100,0); font-size:1px;">habbo, habbo hoteles, habbo plux, habboplux, hplux, plux, yezzcms, yeezycms, yezz, yeezy, forb, forbi, créditos grátis, retro, habbo creditos, habbo creditos gratis, hc gratis, hc, diseños, salas, habbo-plux, plux, facebook, twitter, el mejor holo, holo, habbo holo, creditos infinos, hc infinito, el mejor holo, furnis, nuevos furnis, habbo custom, nombre de color, prefijo, tag, hotel, habbo hotel, amigos, nuevos amigos, juego online, online, pixeled, juegos gratis, juego gratis, créditos gratis, diamantes grátis, todo gratis, habbo grati, habbo holo, yezzcms.</a>
      </strong>
   </div>
   <style>
      body {
      background: #00a2e8;
      }
   </style>
   <body>
      <div style="position:relative;left:15%;width:70%;top:100px;color:white;text-shadow:1px 2px rgba(0,0,0,0.4);">
         <p style="font-size:1000%;">Oops!</p>
         <br>
         <d style="font-size:350%;">El enlace que usted busca es incorrecto o ha sido eliminado. Por favor verifique el enlace o intente <u style="cursor:pointer;" onclick="window.history.go(-2); return false;">regresar</u>.</d>
      </div>
      <div style="position:fixed;bottom:50px;width:455px;height:76px;left:50%;margin-left:-227px;background:url(app/assets/img/ban.png);"></div>
   </body>
   <script src="app/assets/js/jquery.js" charset="utf-8"></script>
   <script src="app/assets/js/power.js" charset="utf-8"></script>
</html>