<?php
   ob_start();
   require_once '../../global.php';
   
      $TplClass->SetParam('description', 'Noticias');
      $Functions->Logged("allow");
      $Functions->pin("true");
   
   //HOTEL CONFIG
   $result2 = $db->query("SELECT * FROM cms_settings WHERE id = 1 LIMIT 1");
   $yezz = $result2->fetch_array();
   //END HOTEL CONFIG
   
   $users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
   $user = $users->fetch_array();
   
   $TplClass->SetAll();
      
   
     $TplClass->SetParam('title', $yezz['hotelname'].': Noticias');
   
   $TplClass->AddTemplate("header", "menu");
    
   
   
   ob_end_flush();
   ?>
<div id="appcontent">
<style>
   body {
   background: rgb(238, 238, 238);
   }
</style>
<div id="webcenter">
   <div id="article20">
      <h1>¿Qué hay de nuevo?</h1>
   </div>
   <div id="article21">
      <?php global $db;
         $result = $db->query("SELECT * FROM cms_slider ORDER BY id DESC LIMIT 2");
         if($result->num_rows > 0){
           while($data = $result->fetch_array()){
             $result2 = $db->query("SELECT * FROM users WHERE username = '".$data['author'] ."'");
                                              while($userinfo = $result2->fetch_array()){
                   $info = $db->query("SELECT * FROM cms_comments_news WHERE new_id = '".$data['id']."'");
                                                         $comentarios_total = $info->num_rows;
         
         ?>
      <a place="<?php echo $Functions->FilterText($data['title']); ?> - <?php echo $yezz['hotelname']; ?>" href="/news/<?php echo $data['id']; ?>-<?php echo $data['link']; ?>">
         <div id="boxarticles">
            <div id="fnews1">
               <img draggable="false" oncontextmenu="return false" class="lazy" alt="<?php echo $Functions->FilterText($data['title']); ?>" id="fnews2" src="<?php echo $data['image']; ?>">
            </div>
            <div id="shadowarticles"></div>
            <div id="titrearticles" style="width:81%;">
               <h2 style="text-overflow: ellipsis;white-space: nowrap;overflow: hidden;"><strong><?php echo $Functions->FilterText($data['title']); ?></strong></h2>
            </div>
            <div id="comarticlesimg"></div>
            <div id="comarticlestxt">
               <?php echo $comentarios_total; ?> 
            </div>
         </div>
      </a>
      <?php  }}}else{  } ?>
   </div>
   <div id="article20">
      <h1>Lista de noticias</h1>
   </div>
   <div id="articles22">
      <div id="articles21"></div>
      <input onclick="SearchOpen('news')" id="articles20" placeholder="Buscar una noticia..." type="text">
   </div>
   <br>
   <div class="searchnews" id="article21" style="height:1000px;">
      <?php global $db;
         $resultn = $db->query("SELECT * FROM cms_slider ORDER BY id DESC LIMIT 2");
         while($n = $resultn->fetch_array()){
             
                   $result = $db->query("SELECT * FROM cms_slider WHERE id < '".$n['id']."' ORDER BY id DESC LIMIT 12");}
                   if($result->num_rows > 0){
                     while($data = $result->fetch_array()){
         
          
                ?>
      <a place="<?php echo $Functions->FilterText($data['title']); ?> - <?php echo $yezz['hotelname']; ?>" style="color:black;" href="/news/<?php echo $data['id']; ?>-<?php echo $data['link']; ?>">
         <div id="articlesbox" style="height:240px;width:calc(33.33% - 20px);margin-bottom:15px;">
            <div id="fnews1">
               <img  draggable="false" oncontextmenu="return false" class="lazy" alt="<?php echo $Functions->FilterText($data['title']); ?>" id="fnews2" src="<?php echo $data['image']; ?>">
            </div>
            <div id="articlespac"></div>
            <div id="articlestitre">
               <div id="articlestitre_text">
                  <center>
                     <h2><strong><?php echo $Functions->FilterText($data['title']); ?></strong></h2>
                  </center>
               </div>
            </div>
         </div>
      </a>
      <?php  }}else{  } ?>
   </div>
   <div id="articles23"></div>
</div>
<strong>
<a style="color:rgba(100,100,100,0); font-size:1px;">habbo noticias, noticias, habbonews, habbo news, habbo-news, pixeled noticias, habbo hotel news, habbohotel</a>
</strong>
<?php
   //COLUMNA FOOTER
     $TplClass->AddTemplate("others", "footer");
   ?>