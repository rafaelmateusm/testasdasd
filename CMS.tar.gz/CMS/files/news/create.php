<?php
   ob_start();
   require_once '../../global.php';
   
    $Functions->Logged("true");
    $Functions->pin("true");
   
   
   //HOTEL CONFIG
   $result2 = $db->query("SELECT * FROM cms_settings WHERE id = 1 LIMIT 1");
   $yezz = $result2->fetch_array();
   //END HOTEL CONFIG
   
   
   $TplClass->SetParam('title', $yezz['hotelname'] .': Crear noticias');  
   $TplClass->SetParam('description', $yezz['hotelname'] .': Crear noticias');
   
   $users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
   $user = $users->fetch_array();
   $action = $Functions->FilterText($_GET['action']);
   $id = $Functions->FilterText($_GET['id']);
   
         
   $users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
   $user = $users->fetch_array();
   $action = $Functions->FilterText($_GET['action']);
   $id = $Functions->FilterText($_GET['id']);
   
   
   $TplClass->SetAll();
   if( $_SESSION['ERROR_RETURN'] ){
   $TplClass->SetParam('error', '<script>toastr.error(\''.$_SESSION['ERROR_RETURN'].'\');</script>');
   unset($_SESSION['ERROR_RETURN']);
   }
   if( $_SESSION['GOOD_RETURN'] ){
   $TplClass->SetParam('error', '<script>toastr.success(\''.$_SESSION['GOOD_RETURN'].'\');</script>');
   unset($_SESSION['GOOD_RETURN']);
   }
   $result = $db->query("SELECT * FROM cms_settings WHERE id = 1 LIMIT 1");
   $data = $result->fetch_array();
   $SHORTNAME = $data['hotelname'];
   $FACE = $data['facebook'];
   $LOGO = $data['logo'];
   
   function generarCodigo($longitud) {
       $key = '';
       $pattern = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
       $max = strlen($pattern)-1;
       for($i=0;$i < $longitud;$i++) $key .= $pattern{mt_rand(0,$max)};
       return $key;
      }
      
      if($_POST['addpromo']){
      if(isset($_POST['title']) && isset($_POST['content']) && isset($_POST['longcontent']) && isset($_POST['image']) && isset($_POST['category'])){
       $title = $Functions->FilterText($_POST['title']);
       $content = $_POST['content'];
       $longcontent = $_POST['longcontent'];
       $image = $Functions->FilterText($_POST['image']);
       $category = $Functions->FilterText($_POST['category']);
   
       $cadena = $image;
       $tutorial = explode('.',$cadena);
       $alecode = generarCodigo(10);
       if(empty($title) || empty($image) || empty($content)){
           $_SESSION['ERROR_RETURN'] = "Has dejado campos vac&iacute;os";
   header("LOCATION: ". PATH ."/create/new");
          
       }else{
           $dbQuery= array();
           $dbQuery['title'] = $title;
           $dbQuery['image'] = $image;                
           $dbQuery['story'] = $content;
           $dbQuery['longstory'] = $longcontent;
           $dbQuery['author'] = $user['username'];
           $dbQuery['time'] = time();
           $dbQuery['category'] = $category;
           $dbQuery['sobre'] = 'Leer más';
           $dbQuery['link'] = $Functions->FilterTextLink($title);
           $query = $db->insertInto('cms_slider', $dbQuery);
           $db->query("INSERT INTO cms_stafflogs (username, action, message, rank, userid, timestamp) VALUES ('". $user['username'] ."','Noticias', 'Ha creado la noticia ".$title."', '". $user['rank'] ."', '". $user['id'] ."', '".date("Y-m-d ")."')");
           $_SESSION['GOOD_RETURN'] = "Promo creado correctamente";
           $rf = $db->query("SELECT * FROM cms_slider ORDER BY id DESC LIMIT 1");
           $forum = $rf->fetch_array();
   header("LOCATION: ". PATH ."/news/".$forum['id']);
           
       }
   }
   }
   
   if($_POST['editpromo']){
   if(isset($_POST['title']) && isset($_POST['content']) && isset($_POST['longcontent']) && isset($_POST['image'])){
       $title = $Functions->FilterText($_POST['title']);
       $content = $_POST['content'];
       $longcontent = $_POST['longcontent'];
       $image = $Functions->FilterText($_POST['image']);
       if(empty($_POST['title']) || empty($_POST['content']) || empty($_POST['image'])){
           $_SESSION['ERROR_RETURN'] = "Has dejado campos vac&iacute;os";
            header("LOCATION: ". PATH ."/create/new?action=edit&id=".$id."");
       }else{
           $db->query("UPDATE cms_slider SET title = '{$title}', story = '{$content}', image = '{$image}', longstory = '{$longcontent}', time = '".time()."', link = '{$Functions->FilterTextLink($title)}' WHERE id = '{$id}' LIMIT 1");
           $db->query("INSERT INTO cms_stafflogs (username, action, message, rank, userid, timestamp) VALUES ('". $user['username'] ."','Noticias', 'Ha editado la noticia ".$title."', '". $user['rank'] ."', '". $user['id'] ."', '".date("Y-m-d ")."')");
           $_SESSION['GOOD_RETURN'] = "Promo editado correctamente";
           header("LOCATION: ". PATH ."/create/new?action=edit&id=".$id."");
       }
   }
   }
   
   if($action == "err" && !empty($id)){
   $db->query("INSERT INTO cms_stafflogs (username, action, message, rank, userid, timestamp) VALUES ('". $user['username'] ."','Noticias', 'Ha borrado una noticia', '". $user['rank'] ."', '". $user['id'] ."', '".date("Y-m-d ")."')");
   $db->query("DELETE FROM cms_slider WHERE id = '{$id}' LIMIT 1");
   $db->query("DELETE FROM cms_likes_publi WHERE publi_id = '".$id."' AND page = '1'");
   $_SESSION['GOOD_RETURN'] = "Promo borrado correctamente";
   header("LOCATION: ". PATH ."/create/new");
   }
   $TplClass->AddTemplate("header", "menu");
   ob_end_flush(); 
   ?>
<!--Main layout-->
<div id="appcontent">
<?php if($user['rank'] > 11){ ?>
<main>
   <div class="container">
   <?php global $db;
      if($action == "edit" && !empty($id)){
      $hj = $db->query("SELECT * FROM cms_slider WHERE id = '". $id ."'");
      $h_edit = $hj->fetch_array();
      ?>
   <?php if($user['username'] == $h_edit['author'] || $user['rank'] > 8){ ?> 
   <form action="" method="post">
      <div id="appcontent">
         <div id="webcenter">
            <div id="forum67">Crea una nueva noticia</div>
            <input type="text" id="form1" placeholder="Título de la noticia" class="indexinput" style="width:calc(100% - 25px);background:white;color:black;" name="title" value="<?php echo $h_edit['title']; ?>">
            <div id="indexformsepare"></div>
            <input type="text" id="form447" placeholder="¿De qué habla la noticia?" class="indexinput" style="width:calc(100% - 25px);background:white;color:black;" name="content" value="<?php echo $h_edit['story']; ?>">
            <div id="indexformsepare"></div>
            <input type="text" id="fform1" placeholder="Ingresa URL de imagen" class="indexinput" style="width:calc(100% - 25px);background:white;color:black;" name="image" value="<?php echo $h_edit['image']; ?>">
            <div id="indexformsepare"></div>
            <select class="indexinput" style="width:100%;height:80px;background:white;" name="category">
               <option value="General" selected>General</option>
               <option value="Actualizaciones">Actualizaciones</option>
               <option value="Competiciones">Competiciones</option>
               <option value="Concursos">Concursos</option>
               <option value="Encuestas">Encuestas</option>
               <option value="Informativo">Informativo</option>
               <option value="Radio">Radio</option>
               <option value="Soporte">Soporte</option>
            </select>
            <div id="indexformsepare"></div>
            <div style="position:relative;height:12px;"></div>
            <div style="position:relative;height:48px;"></div>
            <div class="card mb-r">
               <textarea cols="80" id="editor1" name="longcontent" rows="10" class="md-textarea"><?php echo $h_edit['longstory']; ?></textarea>
            </div>
            <div id="indexformsepare"></div>
            <input id="indexsubmit" name="editpromo" type="submit" style="width:100%;background:rgb(99,200,98);margin-bottom:30px;" value="Publicar Noticia">
            <button onclick="window.location.href='/create/new'" type="button" class="btn-flat waves-effect">Volver</button>
         </div>
         <strong>
         <a style="color:rgba(100,100,100,0); font-size:1px;">habboforum, forum, habbo, habbo partage, habbo échange, habbo, discussion, discussion habbo, forum habbo, aide habbo, help habbo, habbo help, devenir riche sur habbo, richesse habbo</a>
         </strong>
         <div onclick="OpenStream()" id="opac" class="footer20">
            <div id="footer21" style="background:url(<?php echo PATH ?>/app/assets/img/chat.png) -355px -121px;"></div>
            <div style="display:block" id="usernotif">
               <div id="usernotifimg"></div>
            </div>
         </div>
      </div>
   </form>
   <?php }else{ ?>
   <div id="webcenter">
      <div id="forum60">
         <center>
            <div id="forum55"></div>
            <br>¡No puedes editar esta noticia! ;)
         </center>
      </div>
   </div>
   <?php } ?>
   <?php }else{ ?>
   <form action="" method="post">
      <div id="appcontent">
         <div id="webcenter">
            <div id="forum67">Crea una nueva noticia</div>
            <input type="text" id="form1" placeholder="Título de la noticia" class="indexinput" style="width:calc(100% - 25px);background:white;color:black;" name="title">
            <div id="indexformsepare"></div>
            <input type="text" id="form447" placeholder="¿De qué habla la noticia?" class="indexinput" style="width:calc(100% - 25px);background:white;color:black;" name="content">
            <div id="indexformsepare"></div>
            <input type="text" id="fform1" placeholder="Ingresa URL de imagen" class="indexinput" style="width:calc(100% - 25px);background:white;color:black;" name="image">
            <div id="indexformsepare"></div>
            <select class="indexinput" style="width:100%;height:80px;background:white;" name="category">
               <option value="General" selected>General</option>
               <option value="Actualizaciones">Actualizaciones</option>
               <option value="Competiciones">Competiciones</option>
               <option value="Concursos">Concursos</option>
               <option value="Encuestas">Encuestas</option>
               <option value="Informativo">Informativo</option>
               <option value="Radio">Radio</option>
               <option value="Soporte">Soporte</option>
            </select>
            <div id="indexformsepare"></div>
            <div style="position:relative;height:12px;"></div>
            <div style="position:relative;height:48px;"></div>
            <div class="card mb-r">
               <textarea cols="80" id="editor1" name="longcontent" rows="10" class="md-textarea"></textarea>
            </div>
            <div id="indexformsepare"></div>
            <input id="indexsubmit" name="addpromo" type="submit" style="width:100%;background:rgb(99,200,98);margin-bottom:30px;" value="Publicar Noticia">
            </button>
         </div>
         <strong>
         <a style="color:rgba(100,100,100,0); font-size:1px;">habboforum, forum, habbo, habbo partage, habbo échange, habbo, discussion, discussion habbo, forum habbo, aide habbo, help habbo, habbo help, devenir riche sur habbo, richesse habbo</a>
         </strong>
   </form>
   <?php } ?>
   </div>
</main>
<?php }else{ ?>
<meta http-equiv="Refresh" content="3;url=<?php echo PATH; ?>/home">
<div id="webcenter">
   <div id="forum60">
      <center>
         <div id="forum55"></div>
         <br>¡No puedes crear noticias! ;)
      </center>
   </div>
</div>
<?php } ?>
<script type="text/javascript" src="<?php echo PATH ?>/app/assets/ckeditor/ckeditor.js"></script>
<script type="text/javascript">
   CKEDITOR.replace ("editor1");
</script>
<?php
   //COLUMNA FOOTER
     $TplClass->AddTemplate("others", "footer");
   ?>