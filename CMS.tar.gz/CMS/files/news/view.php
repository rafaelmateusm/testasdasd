<?php
   ob_start();
   require_once '../../global.php';
   
      $Functions->Logged("allow");
      $Functions->pin("true");
   
   //HOTEL CONFIG
   $result2 = $db->query("SELECT * FROM cms_settings WHERE id = 1 LIMIT 1");
   $yezz = $result2->fetch_array();
   //END HOTEL CONFIG
   
   $users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
   $user = $users->fetch_array();
   
   $TplClass->SetAll();
      
   //FUNCIONES NEWS
    $cadena = $Functions->FilterText($_GET['link']);
    $resultado = explode('-',$cadena);
    $getid = $resultado[0];
   
   if(empty($getid)){
   $news_new = $db->query("SELECT * FROM cms_slider ORDER BY id DESC LIMIT 1");
   $news_info = $news_new->fetch_array();
   $getid = $news_info['id'];
   }else
   $news_new = $db->query("SELECT * FROM cms_slider WHERE id = '{$getid}' LIMIT 1");
   $news_info = $news_new->fetch_array();
   
   $rauthor = $db->query("SELECT * FROM users WHERE username = '".$news_info['author']."'");
   $authorinfo = $rauthor->fetch_array();
   
   //END FUNCIONES NEWS
   
   $TplClass->SetParam('title', $Functions->FilterText($news_info['title']));  
   $TplClass->SetParam('description', $news_info['story']);
    $TplClass->SetParam('image', $news_info['image']);
   
   $TplClass->AddTemplate("header", "menu");
    
   
   
   ob_end_flush();
   ?>
<div id="appcontent">
<style>
   body {
   background: rgb(230, 230, 230);
   }
</style>
<div id="lecutre20">
   <div id="lecture21">
      <div id="lecture22">
         <a place="<?php echo $authorinfo['username']; ?>" href="<?php echo PATH ?>/profile/<?php echo $authorinfo['username']; ?>">
            <div id="auteurarticles" style="height:100px;">
               <div id="auteurarticles2">
                  <img class="" draggable="false" oncontextmenu="return false" alt="<?php echo $authorinfo['username']; ?>" src="<?php echo AVATARIMAGE . $authorinfo['look']; ?>&size=l" style="">
               </div>
               <div id="auteurarticles3">
                  <p style="font-size:130%;">Por <?php echo $authorinfo['username']; ?></p>
                  <br>
                  <?php echo $Functions->GetLast($news_info['time']); ?> 
               </div>

                <?php //+40 
                      if($authorinfo['rank'] == 12) {
                         $position = '-200';                
                      }elseif($authorinfo['rank'] == 13) {
                        $position = '-120';                
                     }elseif($authorinfo['rank'] == 14) {
                      $position = '-160';                
                   }elseif($authorinfo['rank'] == 15) {
                    $position = '-80';                
                 }elseif($authorinfo['rank'] == 16) {
                  $position = '-40';                
               }elseif($authorinfo['rank'] == 17) {
                $position = '0';                
             }
             ?>
               <div id="teambadge" style="background:url(<?php echo PATH ?>/app/assets/img/staff_badge.png?20018);background-position-x:<?php echo $position; ?>px;top:4px;"></div>
            
            
            </div>
         </a>
      </div>
      <div id="lecture23">
         <div id="lecture24">
            <h1>Los últimos artículos</h1>
         </div>
         <?php global $db;
            $result = $db->query("SELECT * FROM cms_slider ORDER BY id DESC LIMIT 10");
              while($data = $result->fetch_array()){
                $resultuser = $db->query("SELECT * FROM users WHERE username = '".$data['author']."'");
                $userinf = $resultuser->fetch_array();
                if($data['id'] == $news_info['id']){}else{
            ?>
         <a place="<?php echo $Functions->FilterText($data['title']);?>" style="color:white;" href="<?php echo PATH ?>/news/<?php echo $data['id']; ?>-<?php echo $data['link']; ?>">
            <div id="articlesnextbox">
               <div id="articlesimagebg"><img class="" alt="<?php echo $Functions->FilterText($data['title']);?>" src="<?php echo $data['image']; ?>" style=""></div>
               <div id="articlesshadowbox"></div>
               <div id="articlesnextavatar">
                  <img draggable="false" oncontextmenu="return false" class="" alt="<?php echo $userinf['username']; ?>" src="<?php echo AVATARIMAGE . $userinf['look']; ?>" style="">
               </div>
               <div id="articlesnexttitre">
                  <h2><?php echo $Functions->FilterText($data['title']);?></h2>
               </div>
               <div id="lecture25">Por <?php echo $userinf['username']; ?> </div>
            </div>
         </a>
         <?php  }} ?>
		 <div id="pubnews">
<div style="position:absolute;right:0px;">
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Pixeled #4 -->
<ins class="adsbygoogle"
     style="display:inline-block;width:336px;height:280px"
     data-ad-client="ca-pub-8758885421899894"
     data-ad-slot="2542858004"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
</div>
      </div>
   </div></div>
   <div id="lecture26">
      <div id="lecture27">
         <div id="lecture28"><img class="" draggable="false" oncontextmenu="return false" alt="<?php echo $Functions->FilterText($news_info['title']); ?>" style="width: 100%;" src="<?php echo $news_info['image']; ?>"></div>
         <div id="shadowarticles"></div>
         <div id="lecture29">
            <h1><?php echo $Functions->FilterText($news_info['title']); ?></h1>
            <h1> </h1>
         </div>
         <?php if($user['rank'] > 13){ ?>
   <div>
   <a place="Editar" onclick="window.location.href='<?php echo PATH ?>/create/new?action=edit&id=<?php echo $news_info['id']; ?>'" href="<?php echo PATH ?>/create/new?action=edit&id=<?php echo $news_info['id']; ?>">
         <div id="forum57">Editar</div>
      </a>
<a place="Borrar" onclick="window.location.href='/create/new?action=err&amp;id=<?php echo $news_info['id']; ?>'" href="<?php echo PATH ?>/create/new?action=err&amp;id=<?php echo $news_info['id']; ?>">
         <div id="forum57">Borrar</div>
      </a>
     
   </div>
   <?php } ?>
      </div>
      <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
      <article id="lecture30">
         <p></p>
         <p><em><?php echo $news_info['story']; ?> </em></p>
         <br>
         <p><?php echo $news_info['longstory']; ?></p>
         <br>
      </article>
      <div id="lecture31">
         <div onclick="Share('https://www.facebook.com/sharer.php?u=','<?php echo PATH ?>/news/<?php echo $news_info['id']; ?>-<?php echo $news_info['link']; ?>');" id="articlesreseaux" style="background:rgb(59,89,152);">
            <div id="articlesreseauxicones" style="width:59px;background:url(<?php echo PATH ?>/app/assets/img/pagenews.png);"></div>
         </div>
         <div onclick="Share('https://twitter.com/intent/tweet?url=','<?php echo PATH ?>/news/<?php echo $news_info['id']; ?>-<?php echo $news_info['link']; ?>');" id="articlesreseaux" style="background:rgb(40,169,224);">
            <div id="articlesreseauxicones" style="background:url(<?php echo PATH ?>/app/assets/img/pagenews.png) -61px 0px;"></div>
         </div>
         <div onclick="Share('https://plus.google.com/share?url=','<?php echo PATH ?>/news/<?php echo $news_info['id']; ?>-<?php echo $news_info['link']; ?>');" id="articlesreseaux" style="background:rgb(220,78,65);">
            <div id="articlesreseauxicones" style="background:url(<?php echo PATH ?>/app/assets/img/pagenews.png) -161px 0px;"></div>
         </div>
         <div id="ar_reaction">
            <?php $rreacts = $db->query("SELECT * FROM cms_likes_publi WHERE publi_id = '".$news_info['id']."' AND page = '1' AND  username = '".$user['username']."'"); 
               $inforeac = $rreacts->fetch_array();
               if($inforeac['type'] == 1){
                 $position = '45px 0px';
               }elseif($inforeac['type'] == 2){
                 $position = '225px 0px';
               }elseif($inforeac['type'] == 3){
                 $position = '90px 0px';
               }elseif($inforeac['type'] == 4){
                 $position = '180px 0px';
               }elseif($inforeac['type'] == 5){
                 $position = '135px 1px';
               }else{
               $position = '135px 1px';
               }
               ?> 
            <?php echo $rreact1->num_rows; ?>
            <div id="lecture32" style="background-position: <?php echo $position; ?>;"></div>
            <div id="lecture33">
               <x id="nbreact">
                  <?php $rreact = $db->query("SELECT * FROM cms_likes_publi WHERE publi_id = '".$news_info['id']."' AND page = '1'"); ?> 
                  <?php echo $rreact->num_rows; ?> 
               </x>
               reacciones
            </div>
            <div id="js_reaction">
               <div onclick="React('<?php echo $news_info['id']; ?>','1','45px 0px','react1','1');" id="articlesreaction" style="background:url(<?php echo PATH ?>/app/assets/img/reactions_sprite.png);background-position: 45px 0px;">
                  <div class="react1" id="articlesreactionnb" style="background:rgb(255,201,14);">
                     <?php $rreact1 = $db->query("SELECT * FROM cms_likes_publi WHERE publi_id = '".$news_info['id']."' AND page = '1' AND type = '1'"); ?> 
                     <?php echo $rreact1->num_rows; ?> 
                  </div>
               </div>
               <div onclick="React('<?php echo $news_info['id']; ?>','2','225px 0px','react2','1');" id="articlesreaction" style="background:url(<?php echo PATH ?>/app/assets/img/reactions_sprite.png);background-position: 225px 0px;">
                  <div class="react2" id="articlesreactionnb" style="background:white;color:black;">
                     <?php $rreact2 = $db->query("SELECT * FROM cms_likes_publi WHERE publi_id = '".$news_info['id']."' AND page = '1' AND type = '2'"); ?> 
                     <?php echo $rreact2->num_rows; ?> 
                  </div>
               </div>
               <div onclick="React('<?php echo $news_info['id']; ?>','3','90px 0px','react3','1');" id="articlesreaction" style="background:url(<?php echo PATH ?>/app/assets/img/reactions_sprite.png);background-position: 90px 0px;">
                  <div class="react3" id="articlesreactionnb" style="background:rgb(237,28,36);">
                     <?php $rreact3 = $db->query("SELECT * FROM cms_likes_publi WHERE publi_id = '".$news_info['id']."' AND page = '1' AND type = '3'"); ?> 
                     <?php echo $rreact3->num_rows; ?> 
                  </div>
               </div>
               <div onclick="React('<?php echo $news_info['id']; ?>','4','180px 0px','react4','1');" id="articlesreaction" style="background:url(<?php echo PATH ?>/app/assets/img/reactions_sprite.png);background-position: 180px 0px;">
                  <div class="react4" id="articlesreactionnb" style="background:white;color:black;">
                     <?php $rreact4 = $db->query("SELECT * FROM cms_likes_publi WHERE publi_id = '".$news_info['id']."' AND page = '1' AND type = '4'"); ?> 
                     <?php echo $rreact4->num_rows; ?> 
                  </div>
               </div>
               <div onclick="React('<?php echo $news_info['id']; ?>','5','135px 1px','react5','1');" id="articlesreaction" style="background:url(<?php echo PATH ?>/app/assets/img/reactions_sprite.png);background-position: 135px 0px;">
                  <div class="react5" id="articlesreactionnb" style="background:rgb(0,162,232);">
                     <?php $rreact5 = $db->query("SELECT * FROM cms_likes_publi WHERE publi_id = '".$news_info['id']."' AND page = '1' AND type = '5'"); ?> 
                     <?php echo $rreact5->num_rows; ?> 
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
   <div id="lecture34">
      <?php if($user['id'] > 0){	?>
      <div id="lecture35">Reaccionar ahora</div>
      <div id="lecture36">
         <div id="habboforumbulle" style="left:73px;top:73px;"></div>
         <div id="lecture37">
            <img class="" style="position:relative;top:15px;left:15px;" draggable="false" oncontextmenu="return false" alt="<?php echo $user['username']; ?>" src="<?php echo AVATARIMAGE . $user['look']; ?>&action=std&gesture=sml&direction=2&head_direction=2&size=l&headonly=1&img_format=png" >
         </div>
         <button id="articlescombbcode" type="button" onclick="balise('bold');"><b>B</b></button>
         <button id="articlescombbcode" type="button" onclick="balise('underline')"><u>U</u></button>
         <button id="articlescombbcode" type="button" onclick="balise('italic')"><i>I</i></button>
         <button id="articlescombbcode" style="background:#ED1C24;" type="button" onclick="balise('redcolor');">
         Rojo
         </button>
         <button id="articlescombbcode" style="background:#22B14C;" type="button" onclick="balise('vertcolor');">
         Verde
         </button>
         <button id="articlescombbcode" style="background:#4286CA;" type="button" onclick="balise('bleucolor');">
         Azul
         </button>
         <div id="lecture38"></div>
         <div class="comediteur" id="editeur" contenteditable="" type="text">Escribe algo...</div>
         <div id="opac" style="text-align:center;" class="articlecomsend" onclick="AddCom('<?php echo $user['username']; ?>','<?php echo AVATARIMAGE . $user['look']; ?>&action=std&gesture=sml&direction=2&head_direction=2&size=l&headonly=1&img_format=png','<?php echo $news_info['id']; ?>','<?php echo $user['rank']; ?>',' news/ <?php echo $news_info['id']; ?>- <?php echo $news_info['link']; ?>')">
            Comentar
         </div>
      </div>
      <?php }else{echo '<div class="error">Necesitas estar conectad@ para comentar.</div>';} ?>
      <div id="lecture42">
         <div id="lecture43"></div>
         <div id="lecture44"></div>
      </div>
      <div id="lecture39"></div>
      <div id="commentairesliste">
         <?php global $db;
            $comentarios2 = $db->query("SELECT * FROM cms_comments_news WHERE new_id = '".$news_info['id']."' ORDER BY id DESC");
            	while($coment = $comentarios2->fetch_array()){
            		$userinfo = $db->query("SELECT * FROM users WHERE username = '".$coment['username']."'");
            		while($userrinf = $userinfo->fetch_array()){
                        ?>
         <div class="com<?php echo $coment['id']; ?>" id="lecture40">
            <div id="habboforumbulle" style="left:73px;top:35px;"></div>
            <?php	global $db; if($userrinf['username'] == $user['username'] || $user['rank'] > 10){?>
            <div onclick="DeleteCom('<?php echo $coment['id']; ?>');" id="articlescomdelete"></div>
            <?php } ?>
            <?php //+40 
                      if($userrinf['rank'] == 4) {
                        $position2 = '80';                
                     }elseif($userrinf['rank'] == 5) {
                         $position2 = '-240';                
                      }elseif($userrinf['rank'] == 6) {
                        $position2 = '360';                
                     }elseif($userrinf['rank'] == 7) {
                      $position2 = '-240';                
                   }elseif($userrinf['rank'] == 8) {
                    $position2 = '240';                
                 }elseif($userrinf['rank'] == 9) {
                  $position2 = '400';                
               }elseif($userrinf['rank'] == 10) {
                $position2 = '440';                
             }elseif($userrinf['rank'] == 11) {
              $position2 = '480';                
           }elseif($userrinf['rank'] == 12) {
            $position2 = '-200';                
         }elseif($userrinf['rank'] == 13) {
                        $position2 = '-120';                
                     }elseif($userrinf['rank'] == 14) {
                      $position2 = '-160';                
                   }elseif($userrinf['rank'] == 15) {
                    $position2 = '-80';                
                 }elseif($userrinf['rank'] == 16) {
                  $position2 = '-40';                
               }elseif($userrinf['rank'] == 17) {
                $position2 = '0';                
             }
             ?>
            <?php if($userrinf['rank'] == 1 || $userrinf['rank'] == 2 || $userrinf['rank'] == 3){}else{ ?><div id="articlescombadge" style="background-position-x:<?php echo $position2; ?>px;"></div><?php } ?>
            <a place="<?php echo $userrinf['username']; ?>" href="<?php echo PATH ?>/profile/<?php echo $userrinf['username']; ?>">
               <div id="articlescomtete">
                  <img class="" style="position:relative;top:15px;left:15px;" draggable="false" oncontextmenu="return false" alt="<?php echo $userrinf['username']; ?>" src="<?php echo AVATARIMAGE . $userrinf['look']; ?>&action=std&gesture=sml&direction=2&head_direction=2&size=l&headonly=1&img_format=png" >
               </div>
            </a>
            <div id="lecture41">
               <div id="articlescomtext">
                  <b><?php echo $userrinf['username']; ?></b> : <strong><?php echo $Functions->FilterText2($coment['commentary']); ?></strong>
               </div>
            </div>
         </div>
         <?php }} ?>
      </div>
   </div>
   <div class="end"></div>
   <div onclick="OpenSupport('news','<?php echo PATH ?>/app/load/HelpPage.php?page=news&amp;newsid=<?php echo $news_info['id']; ?>')" id="articlesignale" style="bottom: 18px; right: calc(15% - 70px);">
      <div id="articlessignaleimg"></div>
   </div>
</div>
<strong>
<a style="color:rgba(100,100,100,0); font-size:1px;">habbo noticias, noticias, habbonews, habbo news, habbo-news, pixeled noticias, habbo hotel news, habbohotel</a>
</strong>
<?php
   //COLUMNA FOOTER
     $TplClass->AddTemplate("others", "footer");
   ?>