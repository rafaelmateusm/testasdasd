<?php
/* ♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛\
██╗   ██╗███████╗███████╗███████╗    ███████╗███████╗██████╗ ██╗   ██╗███████╗██████╗ 
╚██╗ ██╔╝██╔════╝╚══███╔╝╚══███╔╝    ██╔════╝██╔════╝██╔══██╗██║   ██║██╔════╝██╔══██╗
 ╚████╔╝ █████╗    ███╔╝   ███╔╝     ███████╗█████╗  ██████╔╝██║   ██║█████╗  ██████╔╝
  ╚██╔╝  ██╔══╝   ███╔╝   ███╔╝      ╚════██║██╔══╝  ██╔══██╗╚██╗ ██╔╝██╔══╝  ██╔══██╗
   ██║   ███████╗███████╗███████╗    ███████║███████╗██║  ██║ ╚████╔╝ ███████╗██║  ██║
   ╚═╝   ╚══════╝╚══════╝╚══════╝    ╚══════╝╚══════╝╚═╝  ╚═╝  ╚═══╝  ╚══════╝╚═╝  ╚═╝
   ────────────────────────CMS de Uso Privado 2018  by Forbi───────────────────────────
\ ♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛*/


	error_reporting(0);

	session_set_cookie_params(94608000); 
	ini_set('session.gc_maxlifetime', 94608000);
	session_start();
	//setcookie($_SESSION['username'], 'abierto', time()+3600*24*365, '/');
	//ini_set('session.cache_expire', 200000);
	//ini_set('session.cache_limiter', 'none');
	//ini_set('session.cookie_lifetime', 2000000);
	//ini_set('session.gc_maxlifetime', 200000);

    function SacarIP(){
		if($_SERVER){
			if($_SERVER["HTTP_X_FORWARDED_FOR"]){
				$realip = $_SERVER["HTTP_X_FORWARDED_FOR"];
			}elseif ($_SERVER["HTTP_CLIENT_IP"]){
				$realip = $_SERVER["HTTP_CLIENT_IP"];
			}else{
				$realip = $_SERVER["REMOTE_ADDR"];
			}
		}else{
			if(getenv("HTTP_X_FORWARDED_FOR")){
				$realip = getenv("HTTP_X_FORWARDED_FOR");
			}elseif(getenv("HTTP_CLIENT_IP")){
				$realip = getenv("HTTP_CLIENT_IP");
			}else{
				$realip = getenv("REMOTE_ADDR");
			}
		}
		return $realip;
	}
	$realip = SacarIP();
	define ( 'USER_IP', $realip );
	define ( 'SEPARATOR', DIRECTORY_SEPARATOR );
	define ( 'DIR', __DIR__ );
	define ( 'WEB', true );
	define ( 'YeezyCMS', true );

	define( 'CHARSET','UTF-8' );
	header( 'Content-type: text/html; charset='.CHARSET );

	include( 'deprived/class.core.php' );

	$TplClass->SetParam( 'error', '' );

	$result = $db->query("SELECT * FROM cms_settings WHERE id = 1 LIMIT 1");
	$data = $result->fetch_array();
	$TplClass->SetParam( 'SHORTNAME', $data['hotelname'] );
	$TplClass->SetParam( 'FACE', $data['facebook'] );
	$TplClass->SetParam( 'LOGO', $data['logo'] );

	$TplClass->SetParam( 'PATH', PATH );
	$TplClass->SetParam( 'PATHC', PATHC );
	$TplClass->SetParam( 'FILES', FILES );
	$TplClass->SetParam( 'PATHCLIENT', PATHCLIENT );
	$TplClass->SetParam( 'HK', HK );
	$TplClass->SetParam( 'CLUBNAME', CLUBNAME );
	$TplClass->SetParam( 'ID', '&#89;&#101;&#122;&#122;&#67;&#77;&#83; &#98;&#121; &#70;&#111;&#114;&#98;&#105;');
	$TplClass->SetParam( 'FECHAF', '2017 - 2018');
	$TplClass->SetParam( 'FOOTER', 'Todos los derechos reservados. No reclamar derechos del contenido ni copyright.' );
	$TplClass->SetParam( 'FOOTER2', 'Este Hotel no Pertenece a Sulake© ni a habbo original.' );
	$TplClass->SetParam( 'AVATARIMAGE', AVATARIMAGE );
	$TplClass->SetParam( 'USERID', $_SESSION['id'] );
	$TplClass->SetParam( 'USERSON', $Functions->GetOns() );
    $TplClass->SetParam( 'USERREG', $Functions->GetCount('users') );
	$TplClass->SetParam( 'MYID', $Functions->GetID() );

	//USER INFO
	$users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
	$user = $users->fetch_array();	
	$TplClass->SetParam( 'USERNAME', $Functions->FilterText($user['username']) );
	//END USER INFO

    //HK
    if($user['rank'] > 10){
    $TplClass->SetParam( 'HKLINK', '<a onclick="window.location.href=\''.HK.'\'" href="'.HK.'" target="_blank">
                  <li id="usertogglemenu">
                     <div id="head22" style="background:url('.PATH.'/app/assets/img/pagetemplate.png?5x5x) -142px -133px;"></div>
                     <div id="usertoggletext">HK</div>
                  </li>
               </a>');
    }else{
    $TplClass->SetParam( 'HKLINK', '');
    }

	$resulta = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
	while($lastc = $resulta->fetch_array()){ $TplClass->SetParam( 'LASTC', $Functions->GetLast($lastc['last_online']) ); }

	$db->query("DELETE from cms_stories where (UNIX_TIMESTAMP()-cms_stories.time)>86400");
	$db->query("DELETE from cms_stories_likes where (UNIX_TIMESTAMP()-cms_stories_likes.time)>86400");

	if($user['cms_pin'] == 1){
		$db->query("UPDATE users SET pin_intentos = '3' WHERE id = '".$user['id']."' AND (UNIX_TIMESTAMP()-users.pin_time)>7200");
	}
	
	if($user['cms_pin'] == 2){
	$db->query("UPDATE users SET pin_time = '".time()."', cms_pin = '1'  WHERE id = '".$user['id']."' AND (UNIX_TIMESTAMP()-users.pin_time)>7200");
	}
?>
