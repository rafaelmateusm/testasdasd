-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 06-06-2018 a las 10:33:22
-- Versión del servidor: 10.1.28-MariaDB
-- Versión de PHP: 5.6.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `pixeled`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `catalog_bc_frontpage`
--

CREATE TABLE `catalog_bc_frontpage` (
  `id` int(1) NOT NULL,
  `front_name` varchar(50) NOT NULL,
  `front_link` varchar(50) NOT NULL,
  `front_image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `catalog_bc_frontpage`
--

INSERT INTO `catalog_bc_frontpage` (`id`, `front_name`, `front_link`, `front_image`) VALUES
(1, 'Ei men el catalogo BC men', '', 'catalogue/feature_cata_vert_oly16bundle4.png'),
(2, 'Ui que es estoooo', '', 'catalogue/feature_cata_hort_habbergerbundle.png'),
(3, 'El segundo de espaÃ±a en tenerlo o que?', '', 'catalogue/feature_cata_hort_olympic16.png'),
(4, 'wtf', 'habbo_club', 'catalogue/feature_cata_hort_HC_b.png');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `catalog_bc_items`
--

CREATE TABLE `catalog_bc_items` (
  `id` int(11) NOT NULL,
  `page_id` int(11) NOT NULL,
  `item_id` varchar(120) NOT NULL,
  `catalog_name` varchar(100) NOT NULL,
  `cost_credits` int(11) NOT NULL DEFAULT '3',
  `cost_pixels` int(11) NOT NULL DEFAULT '0',
  `cost_diamonds` int(11) NOT NULL DEFAULT '0',
  `amount` int(11) NOT NULL DEFAULT '1',
  `limited_sells` int(11) NOT NULL DEFAULT '0',
  `limited_stack` int(11) NOT NULL DEFAULT '0',
  `offer_active` enum('0','1') NOT NULL DEFAULT '1',
  `extradata` varchar(255) NOT NULL DEFAULT '',
  `badge` varchar(10) NOT NULL DEFAULT '',
  `offer_id` int(11) NOT NULL DEFAULT '-1',
  `cost_honor` int(11) NOT NULL DEFAULT '0',
  `predesigned_id` int(11) NOT NULL DEFAULT '0',
  `cost_pumpkins` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `catalog_bc_items`
--

INSERT INTO `catalog_bc_items` (`id`, `page_id`, `item_id`, `catalog_name`, `cost_credits`, `cost_pixels`, `cost_diamonds`, `amount`, `limited_sells`, `limited_stack`, `offer_active`, `extradata`, `badge`, `offer_id`, `cost_honor`, `predesigned_id`, `cost_pumpkins`) VALUES
(1, 2, '206', 'Tronito', 3, 0, 0, 1, 0, 0, '1', '', '', -1, 0, 0, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `catalog_bc_pages`
--

CREATE TABLE `catalog_bc_pages` (
  `id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '-1',
  `caption` varchar(35) NOT NULL,
  `icon_image` int(11) NOT NULL DEFAULT '1',
  `visible` enum('0','1') NOT NULL DEFAULT '1',
  `enabled` enum('0','1') NOT NULL DEFAULT '1',
  `min_rank` int(11) UNSIGNED NOT NULL DEFAULT '1',
  `min_vip` int(11) NOT NULL DEFAULT '0',
  `order_num` int(11) NOT NULL,
  `page_link` varchar(35) NOT NULL DEFAULT '',
  `page_layout` varchar(35) NOT NULL DEFAULT 'default_3x3',
  `page_strings_1` text NOT NULL,
  `page_strings_2` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `catalog_bc_pages`
--

INSERT INTO `catalog_bc_pages` (`id`, `parent_id`, `caption`, `icon_image`, `visible`, `enabled`, `min_rank`, `min_vip`, `order_num`, `page_link`, `page_layout`, `page_strings_1`, `page_strings_2`) VALUES
(1, -10001, 'Inicio', 213, '1', '1', 1, 0, 1, '', 'frontpage4', 'catalog_frontpage_headline_shop_ES_02|catalog_frontpage_headline_shop_ES_02|', '|Canjea tu voucher aquÃ­:'),
(2, 10002, 'Testing', 1, '1', '1', 1, 0, 0, '', 'default_3x3', '', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `catalog_frontpage`
--

CREATE TABLE `catalog_frontpage` (
  `id` int(1) NOT NULL,
  `front_name` varchar(50) NOT NULL,
  `front_link` varchar(50) NOT NULL,
  `front_image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `catalog_frontpage`
--

INSERT INTO `catalog_frontpage` (`id`, `front_name`, `front_link`, `front_image`) VALUES
(1, 'Â¡ActualizaciÃ³n: WIRED!', 'rareaster2017', 'catalogue/frontpagenewired.png'),
(2, 'Â¡Nueva secciÃ³n Bazaar 2017!', 'xmnas2016', 'catalogue/hort1.png'),
(3, 'Â¡Nueva secciÃ³n Santorini 2017!', 'room_bundles_mobile', 'catalogue/feature_cata_hort_santo17_bun2.png'),
(4, 'Â¡Ya disponibles los furnis pÃºblicos en Construcc', 'testerino', 'catalogue/catalog_publics.png');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `catalog_bc_frontpage`
--
ALTER TABLE `catalog_bc_frontpage`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `catalog_bc_items`
--
ALTER TABLE `catalog_bc_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `item_ids` (`item_id`) USING BTREE;

--
-- Indices de la tabla `catalog_bc_pages`
--
ALTER TABLE `catalog_bc_pages`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`) USING BTREE,
  ADD KEY `order_num` (`order_num`) USING BTREE;

--
-- Indices de la tabla `catalog_frontpage`
--
ALTER TABLE `catalog_frontpage`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `catalog_bc_frontpage`
--
ALTER TABLE `catalog_bc_frontpage`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `catalog_bc_items`
--
ALTER TABLE `catalog_bc_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `catalog_bc_pages`
--
ALTER TABLE `catalog_bc_pages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `catalog_frontpage`
--
ALTER TABLE `catalog_frontpage`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
