
--
-- Estructura de tabla para la tabla `cms_buy_badge`
--

CREATE TABLE `cms_buy_badge` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `code2` varchar(50) NOT NULL,
  `code3` varchar(50) NOT NULL,
  `code4` varchar(50) NOT NULL,
  `code5` varchar(50) NOT NULL,
  `dispo` varchar(10) NOT NULL,
  `price` int(10) NOT NULL DEFAULT '5',
  `time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `cms_buy_badge`
--

INSERT INTO `cms_buy_badge` (`id`, `code`, `code2`, `code3`, `code4`, `code5`, `dispo`, `price`, `time`) VALUES
(1, 'ASH', 'SLP', '', '', '', '99', 10, 1526871761),
(2, 'PEP', 'LOGIC', 'WEST3', '', '', '100', 30, 1526871779),
(3, 'james', '', '', '', '', '100', 5, 1526871791),
(4, 'KYR', 'KMT', 'POOP', 'YSM', 'TYLER', '100', 100, 1526871880);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cms_comments_forum`
--

CREATE TABLE `cms_comments_forum` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `commentary` text NOT NULL,
  `posted_in` int(11) NOT NULL,
  `category` enum('c1','c2','c3','c4','c5','c6','c7','c8') NOT NULL DEFAULT 'c1',
  `edit` enum('0','1') NOT NULL DEFAULT '0',
  `user_edit` varchar(150) NOT NULL,
  `edit_time` int(11) NOT NULL,
  `time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cms_comments_news`
--

CREATE TABLE `cms_comments_news` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `commentary` text NOT NULL,
  `new_id` int(11) NOT NULL,
  `type` varchar(8) NOT NULL DEFAULT 'articles',
  `time` int(11) NOT NULL,
  `visto` enum('0','1') NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cms_eventos`
--

CREATE TABLE `cms_eventos` (
  `id` int(11) NOT NULL,
  `title` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `fecha` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `id_sala` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT '1',
  `category` enum('alert','creditos','reloj','torneo') CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT 'alert',
  `desc` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `user_id` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cms_forgot`
--

CREATE TABLE `cms_forgot` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(200) NOT NULL,
  `time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cms_forum`
--

CREATE TABLE `cms_forum` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `title` varchar(1000) NOT NULL,
  `content` text NOT NULL,
  `posted_in` int(11) NOT NULL,
  `fijo` enum('0','1') NOT NULL DEFAULT '0',
  `category` enum('c1','c2','c3','c4','c5','c6','c7','c8') NOT NULL DEFAULT 'c1',
  `cerrado` enum('0','1') NOT NULL DEFAULT '0',
  `views` varchar(100) NOT NULL DEFAULT '0',
  `link` varchar(1000) NOT NULL,
  `time` int(11) NOT NULL,
  `timec` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cms_likes_publi`
--

CREATE TABLE `cms_likes_publi` (
  `id` int(11) UNSIGNED NOT NULL,
  `username` varchar(50) NOT NULL,
  `type` int(5) NOT NULL DEFAULT '0',
  `page` varchar(150) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `publi_id` int(11) NOT NULL,
  `time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cms_logs_upbadges`
--

CREATE TABLE `cms_logs_upbadges` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `badge` varchar(10) NOT NULL,
  `url` varchar(500) NOT NULL,
  `type` enum('badge','fondo') NOT NULL,
  `time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cms_message`
--

CREATE TABLE `cms_message` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `from_id` int(20) NOT NULL,
  `message` varchar(150) NOT NULL,
  `for_id` int(11) NOT NULL,
  `type` varchar(8) NOT NULL DEFAULT 'articles',
  `time` int(11) NOT NULL,
  `visto` enum('0','1') NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cms_reports`
--

CREATE TABLE `cms_reports` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `from_id` int(20) NOT NULL,
  `message` varchar(150) NOT NULL,
  `for_id` int(11) NOT NULL,
  `post_id` int(50) NOT NULL,
  `type` varchar(8) NOT NULL DEFAULT 'articles',
  `category` varchar(150) NOT NULL,
  `time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cms_room_po`
--

CREATE TABLE `cms_room_po` (
  `id` int(11) NOT NULL,
  `room_id` int(11) NOT NULL,
  `time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `cms_room_po`
--

INSERT INTO `cms_room_po` (`id`, `room_id`, `time`) VALUES
(1, 1, 1525901378),
(2, 2, 1526659499),
(3, 3, 1526854205);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cms_settings`
--

CREATE TABLE `cms_settings` (
  `id` int(11) NOT NULL,
  `hotelname` varchar(20) COLLATE latin1_general_ci NOT NULL DEFAULT 'Yeez Priv' COMMENT 'by Forbi',
  `host` varchar(30) COLLATE latin1_general_ci NOT NULL DEFAULT '127.0.0.1',
  `port` int(10) NOT NULL DEFAULT '30000',
  `external_variables` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `external_texts` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `productdata` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `furnidata` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `figuredata` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `figuremap` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `external_Texts_Override` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `external_Variables_Override` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `flash_client_url` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `habbo_swf` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `mantenimiento` enum('0','1') COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  `registros` enum('0','1') COLLATE latin1_general_ci NOT NULL DEFAULT '1',
  `reg_mod` enum('0','1') COLLATE latin1_general_ci NOT NULL DEFAULT '1',
  `reg_ip` enum('0','1') COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  `facebook` varchar(500) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `logo` varchar(500) COLLATE latin1_general_ci NOT NULL DEFAULT 'https://hsource.fr/font/1/Yeezycms.gif',
  `id_paygol` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `copy` varchar(20) COLLATE latin1_general_ci NOT NULL DEFAULT 'Yeez VI by Forbi',
  `v3_style` enum('0','1') COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  `design` enum('normal','valentine','summer','halloween','navidad') COLLATE latin1_general_ci NOT NULL DEFAULT 'normal',
  `twitter` varchar(500) CHARACTER SET latin1 NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Volcado de datos para la tabla `cms_settings`
--

INSERT INTO `cms_settings` (`id`, `hotelname`, `host`, `port`, `external_variables`, `external_texts`, `productdata`, `furnidata`, `figuredata`, `figuremap`, `external_Texts_Override`, `external_Variables_Override`, `flash_client_url`, `habbo_swf`, `mantenimiento`, `registros`, `reg_mod`, `reg_ip`, `facebook`, `logo`, `id_paygol`, `copy`, `v3_style`, `design`, `twitter`) VALUES
(1, 'Pixeled', 'localhost', 30000, 'http://localhost/game/gamedata/external_variables.txt', 'http://localhost/game/gamedata/external_flash_texts.txt', 'http://localhost/game/gamedata/productdata.txt', 'http://localhost/game/gamedata/furnidata.xml?4556454465', 'http://localhost/game/gamedata/figuredata.xml', 'http://localhost/game/gamedata/figuremap.xml', 'http://localhost/game/gamedata/override/external_flash_override_texts.php', 'http://localhost/game/gamedata/override/external_override_variables.txt', 'http://localhost/game/gordon/PRODUCTION/', 'http://localhost/game/gordon/PRODUCTION/SKERE.swf', '0', '1', '0', '0', 'https://www.facebook.com/PixeledH', '/app/assets/img/logos/logo.png', '', 'YeezyCMS by Forbi', '0', '', 'https://twitter.com/PixeledES');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cms_shop_news`
--

CREATE TABLE `cms_shop_news` (
  `id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `image_portada` varchar(1000) NOT NULL,
  `image_info` varchar(1000) NOT NULL,
  `link` varchar(500) NOT NULL,
  `time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `cms_shop_news`
--

INSERT INTO `cms_shop_news` (`id`, `title`, `image_portada`, `image_info`, `link`, `time`) VALUES
(1, 'skereeeeee', 'https://images.habbo.com/c_images/catalogue/feature_cata_vert_santo17_r_mino.png', 'https://puhekupla.com/images/uploads/azure-chest.png', 'b', 1526869815),
(2, 'Hola nuevooo', 'https://images.habbo.com/c_images/catalogue/feature_cata_vert_santo17_chest.png', 'https://images.habbo.com/c_images/catalogue/feature_cata_hort_santo17_chest.png', 'badges', 1526870658);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cms_slider`
--

CREATE TABLE `cms_slider` (
  `id` int(11) NOT NULL,
  `title` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `image` varchar(255) COLLATE latin1_general_ci DEFAULT '',
  `story` longtext CHARACTER SET latin1 COLLATE latin1_spanish_ci,
  `longstory` longtext COLLATE latin1_general_ci,
  `author` text COLLATE latin1_general_ci,
  `time` double DEFAULT NULL,
  `category` enum('Actualizaciones','Competiciones','Concursos','Encuestas','General','Informativo','Radio','Soporte') COLLATE latin1_general_ci NOT NULL DEFAULT 'General',
  `sobre` varchar(50) CHARACTER SET latin1 NOT NULL DEFAULT 'Leer mÃ¡s',
  `link` varchar(500) CHARACTER SET latin1 NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cms_stafflogs`
--

CREATE TABLE `cms_stafflogs` (
  `id` int(11) NOT NULL,
  `username` varchar(40) NOT NULL,
  `message` varchar(100) NOT NULL,
  `rank` int(2) NOT NULL,
  `action` text,
  `userid` int(11) DEFAULT NULL,
  `timestamp` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `cms_stafflogs`
--

INSERT INTO `cms_stafflogs` (`id`, `username`, `message`, `rank`, `action`, `userid`, `timestamp`) VALUES
(1, 'Forbi', 'Ha Actualizado la Configuraci&oacute;n global del Hotel', 17, 'Configuraci&oacute;n global del Hotel', 1, '2018-05-09'),
(2, 'Forbi', 'Ha Actualizado la Configuraci&oacute;n global del Hotel', 17, 'Configuraci&oacute;n global del Hotel', 1, '2018-05-09'),
(3, 'Forbi', 'Ha Actualizado la Configuraci&oacute;n global del Hotel', 17, 'Configuraci&oacute;n global del Hotel', 1, '2018-05-09'),
(4, 'Forbi', 'Ha Actualizado la configuraci&oacute;n incial del Hotel', 17, 'Configuraci&oacute;n del Hotel', 1, '2018-05-20'),
(5, 'Forbi', 'Ha Actualizado la configuraci&oacute;n incial del Hotel', 17, 'Configuraci&oacute;n del Hotel', 1, '2018-05-20'),
(6, 'Forbi', 'Ha Actualizado la configuraci&oacute;n incial del Hotel', 17, 'Configuraci&oacute;n del Hotel', 1, '2018-05-20'),
(7, 'Forbi', 'Ha agregado la placa ASH a 10 Diamantes', 17, 'Agregar Placa (Tienda)', 1, '2018-05-21'),
(8, 'Forbi', 'Ha agregado la placa PEP a 30 Diamantes', 17, 'Agregar Placa (Tienda)', 1, '2018-05-21'),
(9, 'Forbi', 'Ha agregado la placa james a 5 Diamantes', 17, 'Agregar Placa (Tienda)', 1, '2018-05-21'),
(10, 'Forbi', 'Ha agregado la placa KYR a 100 Diamantes', 17, 'Agregar Placa (Tienda)', 1, '2018-05-21');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cms_stats`
--

CREATE TABLE `cms_stats` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `ip` varchar(45) NOT NULL,
  `time` int(11) NOT NULL,
  `navegador` varchar(100) NOT NULL,
  `so` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cms_stats_admin`
--

CREATE TABLE `cms_stats_admin` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `ip` varchar(45) NOT NULL,
  `value` varchar(500) NOT NULL,
  `time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `cms_stats_admin`
--

INSERT INTO `cms_stats_admin` (`id`, `username`, `ip`, `value`, `time`) VALUES
(1, 'Forbi', '::1', 'Entro al panel de administraciÃ³n desde <b>Google Chrome</b>, usando la plataforma <b>Windows 10</b>', 1527189729),
(2, 'Forbi', '::1', 'Entro al panel de administraciÃ³n desde <b>Google Chrome</b>, usando la plataforma <b>Windows 10</b>', 1527189818),
(3, 'Forbi', '::1', 'Entro al panel de administraciÃ³n desde <b>Google Chrome</b>, usando la plataforma <b>Windows 10</b>', 1527193710),
(4, 'Forbi', '::1', 'Entro al panel de administraciÃ³n desde <b>Google Chrome</b>, usando la plataforma <b>Windows 10</b>', 1527196040),
(5, 'Forbi', '::1', 'Entro al panel de administraciÃ³n desde <b>Google Chrome</b>, usando la plataforma <b>Windows 10</b>', 1527198174),
(6, 'Forbi', '::1', 'Entro al panel de administraciÃ³n desde <b>Google Chrome</b>, usando la plataforma <b>Windows 10</b>', 1527199078),
(7, 'Forbi', '::1', 'Entro al panel de administraciÃ³n desde <b>Google Chrome</b>, usando la plataforma <b>Windows 10</b>', 1527199083),
(8, 'Forbi', '::1', 'Entro al panel de administraciÃ³n desde <b>Google Chrome</b>, usando la plataforma <b>Windows 10</b>', 1527199228),
(9, 'Forbi', '::1', 'Entro al panel de administraciÃ³n desde <b>Google Chrome</b>, usando la plataforma <b>Windows 10</b>', 1527201054),
(10, 'Forbi', '::1', 'Entro al panel de administraciÃ³n desde <b>Google Chrome</b>, usando la plataforma <b>Windows 10</b>', 1527201126),
(11, 'Forbi', '::1', 'Entro al panel de administraciÃ³n desde <b>Google Chrome</b>, usando la plataforma <b>Windows 10</b>', 1527201491),
(12, 'Forbi', '::1', 'Entro al panel de administraciÃ³n desde <b>Google Chrome</b>, usando la plataforma <b>Windows 10</b>', 1527201521),
(13, 'Forbi', '::1', 'Entro al panel de administraciÃ³n desde <b>Google Chrome</b>, usando la plataforma <b>Windows 10</b>', 1527201556),
(14, 'Forbi', '::1', 'Entro al panel de administraciÃ³n desde <b>Google Chrome</b>, usando la plataforma <b>Windows 10</b>', 1527201560),
(15, 'Forbi', '::1', 'Entro al panel de administraciÃ³n desde <b>Google Chrome</b>, usando la plataforma <b>Windows 10</b>', 1527202688),
(16, 'Forbi', '::1', 'Entro al panel de administraciÃ³n desde <b>Google Chrome</b>, usando la plataforma <b>Windows 10</b>', 1527207363),
(17, 'Forbi', '::1', 'Entro al panel de administraciÃ³n desde <b>Google Chrome</b>, usando la plataforma <b>Windows 10</b>', 1527375497),
(18, 'Forbi', '::1', 'Entro al panel de administraciÃ³n desde <b>Google Chrome</b>, usando la plataforma <b>Windows 10</b>', 1528267099);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cms_stories`
--

CREATE TABLE `cms_stories` (
  `id` int(32) NOT NULL,
  `user_id` int(7) NOT NULL DEFAULT '0',
  `photo` varchar(100) NOT NULL DEFAULT '',
  `views` int(20) NOT NULL DEFAULT '0',
  `time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cms_stories_likes`
--

CREATE TABLE `cms_stories_likes` (
  `id` int(32) NOT NULL,
  `user_id` int(7) NOT NULL DEFAULT '0',
  `photo_id` varchar(100) NOT NULL DEFAULT '',
  `time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cms_stories_views`
--

CREATE TABLE `cms_stories_views` (
  `id` int(32) NOT NULL,
  `user_id` int(7) NOT NULL DEFAULT '0',
  `photo_id` int(100) NOT NULL,
  `time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cms_tickets`
--

CREATE TABLE `cms_tickets` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `content` text NOT NULL,
  `category` enum('1','2','3','4','5','6','7') NOT NULL DEFAULT '1',
  `time` int(11) NOT NULL,
  `type` varchar(100) NOT NULL,
  `priority` enum('1','2','3','4','5') NOT NULL DEFAULT '1',
  `title` varchar(500) NOT NULL,
  `visto` enum('0','1') NOT NULL DEFAULT '0',
  `posted_in` int(11) NOT NULL,
  `abierto` enum('0','1') NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cms_trans_logs`
--

CREATE TABLE `cms_trans_logs` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `ip_user` varchar(50) NOT NULL,
  `value` varchar(500) NOT NULL,
  `value_staff` varchar(500) NOT NULL,
  `time` int(11) NOT NULL,
  `type` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `cms_trans_logs`
--

INSERT INTO `cms_trans_logs` (`id`, `username`, `ip_user`, `value`, `value_staff`, `time`, `type`) VALUES
(1, 'Forbi', '::1', 'Usted ha comprado un paquete de placas.', 'El usuario Forbi ha comprado el pack de placa de ID: 1', 1526872026, 'badge');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cms_views`
--

CREATE TABLE `cms_views` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `posted_in` int(11) NOT NULL,
  `type` varchar(8) NOT NULL DEFAULT 'articles',
  `time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `cms_buy_badge`
--
ALTER TABLE `cms_buy_badge`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `cms_comments_forum`
--
ALTER TABLE `cms_comments_forum`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `cms_comments_news`
--
ALTER TABLE `cms_comments_news`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `cms_eventos`
--
ALTER TABLE `cms_eventos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `cms_forgot`
--
ALTER TABLE `cms_forgot`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `cms_forum`
--
ALTER TABLE `cms_forum`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `cms_likes_publi`
--
ALTER TABLE `cms_likes_publi`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `cms_logs_upbadges`
--
ALTER TABLE `cms_logs_upbadges`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `cms_message`
--
ALTER TABLE `cms_message`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `cms_reports`
--
ALTER TABLE `cms_reports`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `cms_room_po`
--
ALTER TABLE `cms_room_po`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `cms_settings`
--
ALTER TABLE `cms_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `cms_shop_news`
--
ALTER TABLE `cms_shop_news`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `cms_slider`
--
ALTER TABLE `cms_slider`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indices de la tabla `cms_stafflogs`
--
ALTER TABLE `cms_stafflogs`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `cms_stats`
--
ALTER TABLE `cms_stats`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `cms_stats_admin`
--
ALTER TABLE `cms_stats_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `cms_stories`
--
ALTER TABLE `cms_stories`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `cms_stories_likes`
--
ALTER TABLE `cms_stories_likes`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `cms_stories_views`
--
ALTER TABLE `cms_stories_views`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `cms_tickets`
--
ALTER TABLE `cms_tickets`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `cms_trans_logs`
--
ALTER TABLE `cms_trans_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `cms_views`
--
ALTER TABLE `cms_views`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `cms_buy_badge`
--
ALTER TABLE `cms_buy_badge`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `cms_comments_forum`
--
ALTER TABLE `cms_comments_forum`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `cms_comments_news`
--
ALTER TABLE `cms_comments_news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `cms_eventos`
--
ALTER TABLE `cms_eventos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `cms_forgot`
--
ALTER TABLE `cms_forgot`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `cms_forum`
--
ALTER TABLE `cms_forum`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `cms_likes_publi`
--
ALTER TABLE `cms_likes_publi`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `cms_logs_upbadges`
--
ALTER TABLE `cms_logs_upbadges`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `cms_message`
--
ALTER TABLE `cms_message`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `cms_reports`
--
ALTER TABLE `cms_reports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `cms_room_po`
--
ALTER TABLE `cms_room_po`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `cms_shop_news`
--
ALTER TABLE `cms_shop_news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `cms_slider`
--
ALTER TABLE `cms_slider`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `cms_stafflogs`
--
ALTER TABLE `cms_stafflogs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `cms_stats`
--
ALTER TABLE `cms_stats`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `cms_stats_admin`
--
ALTER TABLE `cms_stats_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT de la tabla `cms_stories`
--
ALTER TABLE `cms_stories`
  MODIFY `id` int(32) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `cms_stories_likes`
--
ALTER TABLE `cms_stories_likes`
  MODIFY `id` int(32) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `cms_stories_views`
--
ALTER TABLE `cms_stories_views`
  MODIFY `id` int(32) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `cms_tickets`
--
ALTER TABLE `cms_tickets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `cms_trans_logs`
--
ALTER TABLE `cms_trans_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `cms_views`
--
ALTER TABLE `cms_views`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
