-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 06-06-2018 a las 10:48:49
-- Versión del servidor: 10.1.28-MariaDB
-- Versión de PHP: 5.6.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `pixeled`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `landing_communitygoalvs`
--

CREATE TABLE `landing_communitygoalvs` (
  `id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `left_votes` int(10) NOT NULL,
  `right_votes` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `landing_communitygoalvs`
--

INSERT INTO `landing_communitygoalvs` (`id`, `name`, `left_votes`, `right_votes`) VALUES
(1, 'tourdefrance17CommunityGoal', 21, 0);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `landing_communitygoalvs`
--
ALTER TABLE `landing_communitygoalvs`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
