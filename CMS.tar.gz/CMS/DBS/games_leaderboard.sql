-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 06-06-2018 a las 10:47:42
-- Versión del servidor: 10.1.28-MariaDB
-- Versión de PHP: 5.6.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `pixeled`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `games_leaderboard`
--

CREATE TABLE `games_leaderboard` (
  `id` int(11) NOT NULL,
  `game_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `record` int(11) NOT NULL,
  `points` int(11) NOT NULL,
  `week` int(11) NOT NULL,
  `year` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `games_leaderboard`
--

INSERT INTO `games_leaderboard` (`id`, `game_id`, `user_id`, `record`, `points`, `week`, `year`) VALUES
(1, 3, 1, 20, 12, 1, 2018),
(2, 3, 2, 19, 11, 1, 2018),
(3, 3, 3, 18, 10, 1, 2018),
(4, 3, 4, 17, 9, 1, 2018),
(5, 3, 5, 16, 8, 1, 2018),
(6, 3, 6, 15, 7, 52, 2017),
(7, 3, 7, 14, 6, 52, 2017),
(8, 3, 8, 21, 5, 52, 2017),
(9, 3, 9, 22, 4, 52, 2017),
(10, 3, 10, 23, 3, 52, 2017),
(11, 4, 1, 23, 99, 1, 2018);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `games_leaderboard`
--
ALTER TABLE `games_leaderboard`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `games_leaderboard`
--
ALTER TABLE `games_leaderboard`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
