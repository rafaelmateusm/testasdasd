<?php
/* ♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛\
██╗   ██╗███████╗███████╗███████╗    ███████╗███████╗██████╗ ██╗   ██╗███████╗██████╗ 
╚██╗ ██╔╝██╔════╝╚══███╔╝╚══███╔╝    ██╔════╝██╔════╝██╔══██╗██║   ██║██╔════╝██╔══██╗
 ╚████╔╝ █████╗    ███╔╝   ███╔╝     ███████╗█████╗  ██████╔╝██║   ██║█████╗  ██████╔╝
  ╚██╔╝  ██╔══╝   ███╔╝   ███╔╝      ╚════██║██╔══╝  ██╔══██╗╚██╗ ██╔╝██╔══╝  ██╔══██╗
   ██║   ███████╗███████╗███████╗    ███████║███████╗██║  ██║ ╚████╔╝ ███████╗██║  ██║
   ╚═╝   ╚══════╝╚══════╝╚══════╝    ╚══════╝╚══════╝╚═╝  ╚═╝  ╚═══╝  ╚══════╝╚═╝  ╚═╝
   ────────────────────────CMS de Uso Privado 2018  by Forbi───────────────────────────
\ ♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛*/



$config = array(
'DB_HOST'	  => 'localhost',/*HOST*/
'DB_PORT'	  => '3306',     /*PUERTO MYSQL*/
'DB_USER'	  => 'root',     /*USUARIO DEL PHPMYADMIN*/
'DB_PASSWORD' => '',   /*CONTRASEÑA DEL PHPMYADMIN*/
'DB_DATABASE' => 'hlatino',   /*BASE DE DATOS*/


//CONFIG PARA EL CREADOR
'PATH'			    	=> 'http://localhost',
'PATHC'			    	=> 'http://localhost/',
'FILES'			    	=> 'http://localhost/landing',
'AVATARIMAGE'       	=> 'https://www.habbo.nl/habbo-imaging/avatarimage?figure=', //game.boon.pw
'SWF'      	        	=> 'http://localhost/game/',
'SWFICON'      	        => 'http://localhost/game/dcr/hof_furni/icon/',
'BADGEURL'          	=> 'http://localhost/game/c_images/album1584/',
'BADGEGROUPURL'         => 'http://localhost/habbo-imaging/badge/',
'CDN'    		    	=> 'http://localhost/gallery/',
'PATHCLIENT'        	=> 'http://localhost/hotel',
'HK'       				=> 'http://localhost/YezzPanel/',
'MINRANK'           	=> '11',
'MERANK'          		=> '15',
'MAXRANK'          		=> '16',
);

?>
