 <?php
 /* ♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛\
██╗   ██╗███████╗███████╗███████╗    ███████╗███████╗██████╗ ██╗   ██╗███████╗██████╗ 
╚██╗ ██╔╝██╔════╝╚══███╔╝╚══███╔╝    ██╔════╝██╔════╝██╔══██╗██║   ██║██╔════╝██╔══██╗
 ╚████╔╝ █████╗    ███╔╝   ███╔╝     ███████╗█████╗  ██████╔╝██║   ██║█████╗  ██████╔╝
  ╚██╔╝  ██╔══╝   ███╔╝   ███╔╝      ╚════██║██╔══╝  ██╔══██╗╚██╗ ██╔╝██╔══╝  ██╔══██╗
   ██║   ███████╗███████╗███████╗    ███████║███████╗██║  ██║ ╚████╔╝ ███████╗██║  ██║
   ╚═╝   ╚══════╝╚══════╝╚══════╝    ╚══════╝╚══════╝╚═╝  ╚═╝  ╚═══╝  ╚══════╝╚═╝  ╚═╝
   ────────────────────────CMS de Uso Privado 2018  by Forbi───────────────────────────
\ ♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛*/

	ob_start();
  require_once '../../global.php';

	$TplClass->SetAll();
	
	
	if( $_SESSION['ERROR_RETURN'] ){
		$TplClass->SetParam('error', '<div id="generic"><div id="error">'.$_SESSION['ERROR_RETURN'].'</div></div>');
		unset($_SESSION['ERROR_RETURN']);
	}

	if( $_SESSION['GOOD_RETURN'] ){
		$TplClass->SetParam('error', '<div id="generic"><div id="error" style="background: #88B600;border: 1px solid #88B600;">'.$_SESSION['GOOD_RETURN'].'</div></div>');
		unset($_SESSION['GOOD_RETURN']);
	}
	$online = $Functions->Get('online');
	$diamonds = $Functions->Get('vip_points');
	$duckets = $Functions->Get('activity_points');
	$userid = $Functions->Get('id');
	$users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
	$user = $users->fetch_array();

	
	
	
	//CAMBIAR NOMBRE
		$oldname = $Functions->Get('username');
		$changename = $Functions->FilterText($_POST['changename']);
		$confpass = $Functions->FilterText($_POST['pnpass']);
		$str = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890";
		$cad = "";
		for($i=0;$i<12;$i++) {
			$cad .= substr($str,rand(0,62),1);
		}
		$passwordchanged = $Functions->Hash($changename, $confpass);

		if(isset($_POST['changename'])){
			$newname = $Functions->FilterText($_POST['changename']);
			$filter = preg_replace("/[^a-z\d\-=\?!@:\.]/i", "", $newname);
			if($user['cms_changename'] == 1){
				$_SESSION['ERROR_RETURN'] = "Lo sentimos, pero ya has cambiado tu nombre 1 vez";
					header("LOCATION: ". PATH ."/account/settings?save=true&tab=1");
			}elseif($online == 1){
				$_SESSION['ERROR_RETURN'] = "Debes estar fuera del client para evitar errores";
					header("LOCATION: ". PATH ."/account/settings?save=true&tab=1");
			}elseif($newname !== $filter || strlen($newname) < 2 || strlen($newname) > 19){
				$_SESSION['ERROR_RETURN'] = "Inserta un nombre valido (Min: 2 Caract. Max 18 Caract.)";
				header("LOCATION: ". PATH ."/account/settings?save=true&tab=1");
			}elseif($Functions->ComprobateExist($newname)){
				$_SESSION['ERROR_RETURN'] = "Ese nombre ya esta en uso.";
					header("LOCATION: ". PATH ."/account/settings?save=true&tab=1");
			}elseif(empty($_POST['changename']) || empty($_POST['pnpass'])){
				$_SESSION['ERROR_RETURN'] = "Debes rellenar ambos campos";
					header("LOCATION: ". PATH ."/account/settings?save=true&tab=1");
			}elseif(strlen($confpass) < 6 || strlen($confpass) > 32){
				$_SESSION['ERROR_RETURN'] = 'La contraseña es incorrecta';
					header("LOCATION: ". PATH ."/account/settings?save=true&tab=1");
			}elseif(strpos($_POST['changename'], 'MOD-') !== false){
				$_SESSION['ERROR_RETURN'] = "Ese nombre est&aacute; prohibido.";
					header("LOCATION: ". PATH ."/account/settings?save=true&tab=1");
			}else{
				$new = $db->query("UPDATE users SET cms_changename = '1', username = '{$changename}', password = '{$passwordchanged}' WHERE username = '{$Functions->Get('username')}' AND password = '{$_SESSION['password']}' LIMIT 1");
				$_SESSION['GOOD_RETURN'] = "Se ha cambiado tu nombre y tus respectivas salas con &eacute;xito.";
				$_SESSION['username'] = $changename;
				$_SESSION['password'] = $passwordchanged;
				unset($_SESSION['cms_changename']);
				header("LOCATION: ". PATH ."/account/settings?save=true&tab=1");
			}
		}
	//END CAMBIA NOMBRE
	
	
	
	
	//PLACA DE REGALO
		if(isset($_POST['badgecode'])){
			$badgec = $Functions->FilterText($_POST['badgecode']);
			$badgel = $db->query("SELECT code,price FROM cms_badges_gift WHERE id = '{$badgec}' LIMIT 1");
			if($badgel->num_rows > 0){
				$badgef = $badgel->fetch_array();
				$cdbadge = $badgef['code'];
				$cpbadge = $badgef['price'];
				$badgen = $db->query("SELECT * FROM user_badges WHERE badge_id = '{$cdbadge}' AND user_id = '{$userid}' LIMIT 1");
				if($badgen->num_rows > 0){
					$_SESSION['ERROR_RETURN'] = "Al parecer ya posees esta placa. ¡Espera la otra Semana!";
						header("LOCATION: ". PATH ."/me?badgeaction");
				}elseif($online == 1){
					$_SESSION['ERROR_RETURN'] = "Debes estar fuera del client para evitar errores";
						header("LOCATION: ". PATH ."/me?badgeaction");
				}elseif($diamonds >= $cpbadge){
					$_SESSION['GOOD_RETURN'] = "Has reclamado tu placa con &eacute;xito.";
						header("LOCATION: ". PATH ."/me?badgeaction");
					$do1 = $db->query("UPDATE users SET vip_points = vip_points - '{$cpbadge}' WHERE username = '{$_SESSION['username']}'");
					$dbBadge= array();
					$dbBadge['user_id'] = $userid;
					$dbBadge['badge_id'] = $cdbadge;
					$query = $db->insertInto('user_badges', $dbBadge);
				}else{
					$_SESSION['ERROR_RETURN'] = "Ha ocurrido un error inesperado.";
						header("LOCATION: ". PATH ."/me?badgeaction");
				}
			}else{
				$_SESSION['ERROR_RETURN'] = "Esa placa no est&aacute; disponible.";
					header("LOCATION: ". PATH ."/me?badgeaction");
			}
		}
	//END PLACA DE REGALO
	
	
	
	
	//BUSCAR USUARIO
		if(isset($_POST['search'])){
			$buscar = $Functions->FilterText($_POST['search']);
			if(empty($buscar)){
				$_SESSION['ERROR_RETURN'] = "Debes insertar un nombre de usuario";
					header("LOCATION: ". PATH ."/me?buscar");
			}else{
				$con=mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);
				$sql = "SELECT * FROM users WHERE username like '%$buscar%' ORDER BY id DESC";
				mysql_select_db(DB_DATABASE, $con);
				$result = mysql_query($sql, $con);
				$total = mysql_num_rows($result);
				if ($row = mysql_fetch_array($result)){
						header("LOCATION: ". PATH ."/home/".$row['id']."");
				}else{
					$_SESSION['ERROR_RETURN'] = " <b style='margin-left: 60px; margin-right: 10px;'>No se encontro resultados para $buscar</b>";
						header("LOCATION: ". PATH ."/buscador.php");
				}
			}
		}
	//END BUSCAR USUARIO



	//COMPRAR PLACAS
		if(isset($_POST['buybadge'])){
			$badgec = $Functions->FilterText($_POST['buybadgecode']);
			$badgel = $db->query("SELECT code,price FROM cms_badges WHERE id = '{$badgec}' LIMIT 1");
			if($badgel->num_rows > 0){
				$badgef = $badgel->fetch_array();
				$cdbadge = $badgef['code'];
				$cpbadge = $badgef['price'];
				$badgen = $db->query("SELECT * FROM user_badges WHERE badge_id = '{$cdbadge}' AND user_id = '{$userid}' LIMIT 1");
				if($badgen->num_rows > 0){
					$_SESSION['ERROR_RETURN'] = "Al parecer ya posees esta placa.";
						header("LOCATION: ". PATH ."/shop/placas?badgeaction");
				}elseif($online == 1){
					$_SESSION['ERROR_RETURN'] = "Debes estar fuera del client para evitar errores";
						header("LOCATION: ". PATH ."/shop/placas?badgeaction");
				}elseif($diamonds >= $cpbadge){
					$_SESSION['GOOD_RETURN'] = "Has comprado la placa con &eacute;xito.";
						header("LOCATION: ". PATH ."/shop/placas?badgeaction");
					$do1 = $db->query("UPDATE users SET vip_points = vip_points - '{$cpbadge}' WHERE username = '{$_SESSION['username']}'");
					$dbBadge= array();
					$dbBadge['user_id'] = $userid;
					$dbBadge['badge_id'] = $cdbadge;
					$query = $db->insertInto('user_badges', $dbBadge);
				}else{
					$_SESSION['ERROR_RETURN'] = "Ha ocurrido un error inesperado.";
						header("LOCATION: ". PATH ."/shop/placas?badgeaction");
					}
			}else{
				$_SESSION['ERROR_RETURN'] = "Esa placa no est&aacute; disponible.";
						header("LOCATION: ". PATH ."/shop/placas?badgeaction");
			}
		}
	//END COMPRAR PLACAS
	
	
	
	
	//COMPRAR RARES
		if(isset($_POST['buyrare'])){
		$rarec = $Functions->FilterText($_POST['rarecode']);
		$rarel = $db->query("SELECT code,price,item_name FROM cms_rares WHERE id = '{$rarec}' LIMIT 1");
			if($rarel->num_rows > 0){
				$raref = $rarel->fetch_array();
				$cdrare = $raref['code'];
				$cprare = $raref['price'];
				if($online == 1){
					$_SESSION['ERROR_RETURN'] = "Debes estar fuera del client para evitar errores";
						header("LOCATION: ". PATH ."/shop/rares?rareaction");
				}elseif($diamonds >= $cprare){
					$_SESSION['GOOD_RETURN'] = "Rare comprado con &eacute;xito";
						header("LOCATION: ". PATH ."/shop/rares?rareaction");
					$do1 = $db->query("UPDATE users SET vip_points = vip_points - '{$cprare}' WHERE username = '{$_SESSION['username']}'");
					$dbrare= array();
					$dbrare['user_id'] = $userid;
					$dbrare['room_id'] = 0;
					$dbrare['base_item'] = $cdrare;
					$dbrare['extra_data'] = '';
					$dbrare['x'] = 0;
					$dbrare['y'] = 0;
					$dbrare['z'] = 0.000;
					$dbrare['rot'] = 0;
					$dbrare['wall_pos'] = '';
					$dbrare['limited_number'] = 0;
					$dbrare['limited_stack'] = 0;
					$query = $db->insertInto('items', $dbrare);
				}else{
					$_SESSION['ERROR_RETURN'] = "No tienes lo suficiente para comprar este rare";
					header("LOCATION: ". PATH ."/shop/rares?rareaction");
				}
			}else{
				$_SESSION['ERROR_RETURN'] = "Ese rare no est&aacute; en venta";
					header("LOCATION: ". PATH ."/shop/rares?rareaction");
			}
		}
	//END CAMBIAR RARES
	
	
	
	//BUG
		if(isset($_POST['BugReporter']) AND isset($_POST['trata'])){
			$text = $Functions->FilterText($_POST['BugReporter']);
						$trata = $Functions->FilterText($_POST['trata']);

			$security = $db->query("SELECT * FROM cms_comments WHERE username = '{$_SESSION['username']}' && type = 'bug' ORDER by id DESC LIMIT 1");
			$sec = $security->fetch_array();
			if($security->num_rows > 0){
				if($sec['time'] >= time() - 300){
					$_SESSION['ERROR_RETURN'] = "&iexcl;No puedes mandar reportes seguidos! Debes esperar 5 minutos para enviar otro";
						header("LOCATION: ". PATH ."/bug");
				}else{
					$db->query("INSERT INTO cms_comments (username, comentario, type, time, posted_on, posted_in) VALUES ('". $_SESSION['username'] ."', '{$_POST['trata']} - {$_POST['BugReporter']}', 'bug', '".time()."', '".date("Y-m-d ")."', '0')");
					$_SESSION['GOOD_RETURN'] = "&iexcl;Reporte enviado! Gracias por tu apoyo, esto se hace para mejorar el hotel y disfrutes mejor de &eacute;l";
						header("LOCATION: ". PATH ."/home");
				}
			}else{
					$db->query("INSERT INTO cms_comments (username, comentario, type, time, posted_on, posted_in) VALUES ('". $_SESSION['username'] ."', '{$_POST['trata']} - {$_POST['BugReporter']}', 'bug', '".time()."', '".date("Y-m-d ")."', '0')");
					$_SESSION['GOOD_RETURN'] = "&iexcl;Reporte enviado! Gracias por tu apoyo, esto se hace para mejorar el hotel y disfrutes mejor de &eacute;l";
						header("LOCATION: ". PATH ."/home");
			}
		}
	//END BUG
	
	ob_end_flush();
?>
