<?php
/* ♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛\
██╗   ██╗███████╗███████╗███████╗    ███████╗███████╗██████╗ ██╗   ██╗███████╗██████╗ 
╚██╗ ██╔╝██╔════╝╚══███╔╝╚══███╔╝    ██╔════╝██╔════╝██╔══██╗██║   ██║██╔════╝██╔══██╗
 ╚████╔╝ █████╗    ███╔╝   ███╔╝     ███████╗█████╗  ██████╔╝██║   ██║█████╗  ██████╔╝
  ╚██╔╝  ██╔══╝   ███╔╝   ███╔╝      ╚════██║██╔══╝  ██╔══██╗╚██╗ ██╔╝██╔══╝  ██╔══██╗
   ██║   ███████╗███████╗███████╗    ███████║███████╗██║  ██║ ╚████╔╝ ███████╗██║  ██║
   ╚═╝   ╚══════╝╚══════╝╚══════╝    ╚══════╝╚══════╝╚═╝  ╚═╝  ╚═══╝  ╚══════╝╚═╝  ╚═╝
   ────────────────────────CMS de Uso Privado 2018  by Forbi───────────────────────────
\ ♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛♛*/

ob_start();
require_once '../../global.php';

$q = $Functions->FilterText($_POST[q]);

$sql = $db->query("SELECT * FROM users WHERE username = '$q'");

if($sql->num_rows == 0){

echo '<img draggable="false" oncontextmenu="return false" src="/app/assets/img/index/hey.png"></img>';

}else{

while($fila = $sql->fetch_array()){

echo '<img draggable="false" oncontextmenu="return false" src="'.AVATARIMAGE.''.$fila['look'].'&action=std&gesture=std&direction=2&head_direction=2&size=l" />';

}

}

?>