<html lang="en">
<head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
   <meta http-equiv="x-ua-compatible" content="ie=edge">
   <title><?php echo $SHORTNAME; ?> > Administraci&oacute;n - <?php echo $title; ?></title>
   <!-- Font Awesome -->
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
   <!-- Bootstrap core CSS -->
   <link rel="stylesheet" href="<?php echo HK; ?>previews/templates/css/bootstrap.min.css">
   <!-- Material Design Bootstrap -->
   <script type="text/javascript" src="<?php echo HK; ?>ckeditor/ckeditor.js"></script>
   <link rel="stylesheet" href="<?php echo HK; ?>previews/templates/css/mdb.min.css">
   <link rel="stylesheet" type="text/css" href="<?php echo PATH ?>/app/assets/css/animate.css" media="screen" />
   <link rel="shortcut icon" href="<?php echo PATH; ?>/app/assets/img/favicon.ico" type="image/vnd.microsoft.icon" />

   <!-- Your custom styles (optional) -->
   <style>
   </style>
</head>
<body class="fixed-sn white-skin">
   <!--Main Navigation-->
   <header>
      <!-- Sidebar navigation -->
      <ul id="slide-out" class="side-nav fixed custom-scrollbar">
         <!-- Logo -->
         <li class="logo-sn waves-effect">
            <div class=" text-center">
               <img class="pl-0" draggable="false" oncontextmenu="return false" src="<?php echo HK; ?>previews/templates/img/logo.png" >
            </div>
         </li>
         <!--/. Logo -->
         <!--Search Form-->
         <li>
            <form class="search-form" role="search">
               <div class="form-group waves-effect">
                  <input type="text" class="form-control" placeholder="Search" value="<?php echo $_SESSION['username']; ?>" disabled>
               </div>
            </form>
         </li>
         <!--/.Search Form-->
         <!-- Side navigation links -->
         <li>
            <ul class="collapsible collapsible-accordion">
               <li><a href="<?php echo HK; ?>" class="collapsible-header waves-effect"><i class="fa fa-home"></i> Principal</a></li>
<li><a href="https://www.hlatino.net/" class="collapsible-header waves-effect"><i class="fa fa-home"></i>Salas MPU y mas</a></li>
<li><a href="https://www.youtube.com/flavioroller1" class="collapsible-header waves-effect"><i class="fa fa-home"></i>Canal de Youtube</a></li>
               <li><a href="<?php echo HK; ?>reports" class="collapsible-header waves-effect"><i class="fa fa-bug"></i> Reportes</a></li>
               <li><a href="<?php echo HK; ?>config" class="collapsible-header waves-effect"><i class="fa fa-home"></i> Sala de bienvenida</a></li>
               <li><a href="<?php echo HK; ?>config-hotel" class="collapsible-header waves-effect"><i class="fa fa-cogs"></i> Configuraci&oacute;n del Hotel</a></li>
               <li>
                  <a class="collapsible-header waves-effect arrow-r"><i class="fa fa-users"></i> Gesti&oacute;n de Usuarios<i class="fa fa-angle-down rotate-icon"></i></a>
                  <div class="collapsible-body">
                     <ul>
                        <li><a href="<?php echo HK; ?>management-bans" class="waves-effect"> Gesti&oacute;n de bans</a></li>
                        <li><a href="<?php echo HK; ?>management-clones" class="waves-effect"> Gesti&oacute;n de clones</a></li>
                        <li><a href="<?php echo HK; ?>management-badges" class="waves-effect"> Gesti&oacute;n de placas</a></li>
                        <li><a href="<?php echo HK; ?>management-ranks" class="waves-effect"> Gesti&oacute;n de rangos</a></li>
                        <li><a href="<?php echo HK; ?>management-users" class="waves-effect"> Gesti&oacute;n de ususarios</a></li>
                     </ul>
                  </div>
               </li>
               <li>
                  <a class="collapsible-header waves-effect arrow-r"><i class="fa fa-wrench"></i> Acciones<i class="fa fa-angle-down rotate-icon"></i></a>
                  <div class="collapsible-body">
                     <ul>
                        <li><a href="<?php echo HK; ?>upload-bad" class="waves-effect"> Subir Placas</a></li>
						<li><a href="<?php echo HK; ?>management-salas" class="waves-effect"> Agregar salas públicas</a></li>
                        <li><a href="<?php echo HK; ?>upload-background" class="waves-effect"> Subir Fondos (PARA BG)</a></li>
                        <li><a href="<?php echo HK; ?>commands" class="waves-effect"> Agregar comando</a></li>
                     </ul>
                  </div>
               </li>
               <li>
                  <a class="collapsible-header waves-effect arrow-r"><i class="fa fa-shopping-cart"></i> Tienda virtual<i class="fa fa-angle-down rotate-icon"></i></a>
                  <div class="collapsible-body">
                     <ul>
                        <li><a href="<?php echo HK; ?>shop-badge" class="waves-effect"> Agregar Placas</a></li>
						<li><a href="<?php echo HK; ?>shop-news" class="waves-effect"> Novedades en la tienda</a></li>
                        <li><a href="<?php echo HK; ?>shop-logs" class="waves-effect"> Logs</a></li>
                        <li><a href="<?php echo HK; ?>diamonds-logs" class="waves-effect"> Logs de las transferencia</a></li>
                        <li><a href="<?php echo HK; ?>logs-vip" class="waves-effect"> Usuarios VIP</a></li>


                     </ul>
                  </div>
               </li>
               <li>
                  <a class="collapsible-header waves-effect arrow-r"><i class="fa fa-shopping-cart"></i> Tienda del Hotel<i class="fa fa-angle-down rotate-icon"></i></a>
                  <div class="collapsible-body">
                     <ul>
                        <li><a href="<?php echo HK; ?>store" class="waves-effect"> Tienda</a></li>
                        <li><a href="<?php echo HK; ?>LTD" class="waves-effect"> Agregar LTD</a></li>
                        <li><a href="<?php echo HK; ?>furniture.php" class="waves-effect"> Furniture</a></li>
                        <li><a href="<?php echo HK; ?>mega-oferta" class="waves-effect"> Mega oferta /Oferta relampago</a></li>

                     </ul>
                  </div>
               </li>
               <li>
                  <a class="collapsible-header waves-effect arrow-r"><i class="fa fa-calendar"></i> Noticias y eventos<i class="fa fa-angle-down rotate-icon"></i></a>
                  <div class="collapsible-body">
                     <ul>
                        <li><a href="<?php echo HK; ?>news" class="waves-effect"> Noticias</a></li>
                        <li><a href="<?php echo HK; ?>events" class="waves-effect"> Eventos</a></li>
                     </ul>
                  </div>
               </li>
               <li>
                  <a class="collapsible-header waves-effect arrow-r"><i class="fa fa-tasks"></i> Logs<i class="fa fa-angle-down rotate-icon"></i></a>
                  <div class="collapsible-body">
                     <ul>
                        <li><a href="<?php echo HK; ?>logs-cms" class="waves-effect"> CMS</a></li>
                        <li><a href="<?php echo HK; ?>logs-emu-staff" class="waves-effect"> Emulador (Staff)</a></li>
                        <li><a href="<?php echo HK; ?>logs-adm" class="waves-effect"> Panel de administración</a></li>
                     </ul>
                  </div>
               </li>
            </ul>
         </li>
         <!--/. Side navigation links -->
         <div class="sidenav-bg mask-strong"></div>
      </ul>
      <!--/. Sidebar navigation -->
      <!-- Navbar -->
      <nav class="navbar fixed-top navbar-toggleable-md navbar-expand-lg scrolling-navbar double-nav">
         <!-- SideNav slide-out button -->
         <div class="float-left">
            <a href="#" data-activates="slide-out" class="button-collapse black-text"><i class="fa fa-bars"></i></a>
         </div>
         <!-- Breadcrumb-->
         <div class="breadcrumb-dn mr-auto">
            <p>Panel de administración de <?php echo $SHORTNAME; ?> by <b>HLATINO.NET</b> &nbsp;&nbsp;&nbsp;&nbsp;—&nbsp;&nbsp;&nbsp;&nbsp; <?php echo $title; ?></p>
         </div>
         <!--Navbar links-->
         <ul class="nav navbar-nav nav-flex-icons ml-auto">
            <!-- Dropdown -->
            <li class="nav-item dropdown notifications-nav">
               <a class="nav-link dropdown-toggle waves-effect" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true"
                  aria-expanded="false">
               <?php global $db; $consulta = $db->query("SELECT * FROM cms_tickets WHERE type = 'ticket' AND visto = '0'"); ?>
               <?php if($consulta->num_rows > 0){ ?>
               <span class="badge red tada animated infinite"><?php echo $consulta->num_rows; ?></span><?php } ?> <i class="fa fa-bell"></i>
               <span class="d-none d-md-inline-block">Notifications</span>
               </a>
               <div class="dropdown-menu dropdown-info" aria-labelledby="navbarDropdownMenuLink">
                  <?php global $db; 
                     if($consulta->num_rows > 0){
                     while($lista = $consulta->fetch_array()){
                     ?>
                  <a class="dropdown-item" href="/PrivateFolder/reports-view?id=<?php echo $lista['id']; ?>">
                  <i class="fa fa-question-circle-o mr-2" aria-hidden="true"></i>
                  <span style="width:100%; word-break: break-all; word-wrap: break-word;"><?php echo $lista['title']; ?></span>
                  <span class="float-right"><i class="fa fa-clock-o" aria-hidden="true"></i> <?php setlocale(LC_TIME,"spanish"); echo utf8_encode(strftime("%b %d, %Y", $lista['time'])); ?></span>
                  </a>
                  <?php }}else{ echo '<a class="dropdown-item"><span>No hay reportes</span></a>';} ?>
               </div>
            </li>
            <li class="nav-item">
               <a class="nav-link waves-effect" data-toggle="modal" data-target="#modalSubmitProject"><i class="fa fa-user-times"></i> <span class="clearfix d-none d-sm-inline-block">Ausentarme</span></a>
            </li>
            <li class="nav-item">
               <a class="nav-link waves-effect" href="<?php echo PATH; ?>"><i class="fa fa-long-arrow-left"></i> <span class="clearfix d-none d-sm-inline-block">Regresar a la home</span></a>
            </li>
         </ul>
         <!--/Navbar links-->
      </nav>
      <!-- /.Navbar -->
      <!-- Fixed button -->
      <div class="fixed-action-btn clearfix d-none d-xl-block" style="bottom: 45px; right: 24px;">
         <a class="btn-floating btn-lg red">
         <i class="fa fa-pencil"></i>
         </a>
         <ul>
            <li><a class="btn-floating red"><i class="fa fa-star"></i></a></li>
            <li><a class="btn-floating yellow darken-1"><i class="fa fa-user"></i></a></li>
            <li><a class="btn-floating green"><i class="fa fa-envelope"></i></a></li>
            <li><a class="btn-floating blue"><i class="fa fa-shopping-cart"></i></a></li>
         </ul>
      </div>
      <!-- Fixed button -->
   </header>
   <!--Main Navigation-->
   <?php global $db;
   	$users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
   	$user = $users->fetch_array();
   	if($_POST['ausentarme']){
        
          if(isset($_POST['dia']) && isset($_POST['mes']) && isset($_POST['ano']) && isset($_POST['dia2']) && isset($_POST['mes2']) && isset($_POST['ano2']) && isset($_POST['motivo'])){
              $dia = $_POST['dia'];
              $mes = $_POST['mes'];
              $ano = $_POST['ano'];
              $dia2 = $_POST['dia2'];
              $mes2 = $_POST['mes2'];
              $ano2 = $_POST['ano2'];
              $motivo = $_POST['motivo'];
              if(empty($dia) || empty($mes) || empty($ano) || empty($dia2) || empty($mes2) || empty($ano2) || empty($motivo)){
                  $_SESSION['ERROR_RETURN'] = "Has dejado campos vac&iacute;os";
                  header("LOCATION: ". HK ."");
              }else{
                  $dbQuery= array();
                  $dbQuery['username'] = $_SESSION['username'];
                  $dbQuery['reason'] = $motivo;
                  $dbQuery['desde'] = $dia.'-'.$mes.'-'.$ano;
                  $dbQuery['hasta'] = $dia2.'-'.$mes2.'-'.$ano2;
                  $dbQuery['time'] = time();
                  $query = $db->insertInto('cms_aus', $dbQuery);
                  $db->query("INSERT INTO cms_stafflogs (username, action, message, rank, userid, timestamp) VALUES ('". $user['username'] ."','Ausencias del Equipo', 'Ha decidido ausentarse desde el ".$dia.'/'.$mes.'/'.$ano." al ".$dia2.'/'.$mes2.'/'.$ano2."', '". $user['rank'] ."', '". $user['id'] ."', '".date("Y-m-d ")."')");
                  $_SESSION['GOOD_RETURN'] = "Ausencia agregada correctamente";
                  header("LOCATION: ". HK ."");
              }
          }
        }
      ?>
   <!--Modal: modalSubmitProject-->
   <div class="modal fade" id="modalSubmitProject" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
      <div class="modal-dialog cascading-modal" role="document">
         <!--Content-->
         <div class="modal-content">
            <form action="" method="post">
               <!--Header-->
               <div class="modal-header light-blue darken-3 white-text">
                  <h4 class=""><i class="fa fa-user-times"></i> Ausentarme</h4>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
               </div>
               <!--Body-->
               <div class="modal-body mb-0">
                  <!--Name-->
                  <center>
                     <p class="lead"><span class="badge info-color p-2">¿Cu&aacute;ndo te vas?</span></p>
                  </center>
                  <center>
                     <p class="help-block">D&iacute;a/Mes/Año</p>
                  </center>
                  <div class="row">
                     <div class="md-form form-sm" style="width:23%;margin-right:50px;">
                        <select class="mdb-select colorful-select dropdown-info" name="dia">
                           <option value="" disabled selected></option>
                           <?php
                              for ($i=1; $i<=31; $i++) {
                                  if ($i == date('j'))
                                      echo '<option value="'.$i.'" selected>'.$i.'</option>';
                                  else
                                      echo '<option value="'.$i.'">'.$i.'</option>';
                              }?>
                        </select>
                     </div>
                     <div class="md-form form-sm" style="width:30%;margin-right:50px;">
                        <select class="mdb-select colorful-select dropdown-info" name="mes">
                           <option value="" disabled selected></option>
                           <?php
                              for ($i=1; $i<=12; $i++) {
                                  if ($i == date('m'))
                                      echo '<option value="'.$i.'" selected>'.$i.'</option>';
                                  else
                                      echo '<option value="'.$i.'">'.$i.'</option>';
                              }?>
                        </select>
                     </div>
                     <div class="md-form form-sm" style="width:23%;">
                        <select class="mdb-select colorful-select dropdown-info" name="ano">
                           <option value="" disabled selected></option>
                           <?php
                              for($i=date('o'); $i>=2018; $i--){
                                  if ($i == date('o'))
                                      echo '<option value="'.$i.'" selected>'.$i.'</option>';
                                  else
                                      echo '<option value="'.$i.'">'.$i.'</option>';
                              }?>
                        </select>
                     </div>
                  </div>
                  <center>
                     <p class="lead"><span class="badge info-color p-2">¿Cu&aacute;ndo regresas?</span></p>
                  </center>
                  <center>
                     <p class="help-block">D&iacute;a/Mes/Año</p>
                  </center>
                  <div class="row">
                     <div class="md-form form-sm" style="width:23%;margin-right:50px;">
                        <select class="mdb-select colorful-select dropdown-info" name="dia2">
                           <option value="" disabled selected></option>
                           <?php
                              for ($i=1; $i<=31; $i++) {
                                  if ($i == date('j'))
                                      echo '<option value="'.$i.'" selected>'.$i.'</option>';
                                  else
                                      echo '<option value="'.$i.'">'.$i.'</option>';
                              }?>
                        </select>
                     </div>
                     <div class="md-form form-sm" style="width:30%;margin-right:50px;">
                        <select class="mdb-select colorful-select dropdown-info" name="mes2">
                           <option value="" disabled selected></option>
                           <?php
                              for ($i=1; $i<=12; $i++) {
                                  if ($i == date('m'))
                                      echo '<option value="'.$i.'" selected>'.$i.'</option>';
                                  else
                                      echo '<option value="'.$i.'">'.$i.'</option>';
                              }?>
                        </select>
                     </div>
                     <div class="md-form form-sm" style="width:23%;">
                        <select class="mdb-select colorful-select dropdown-info" name="ano2">
                           <option value="" disabled selected></option>
                           <?php
                              for($i=date('o'); $i>=2018; $i--){
                                  if ($i == date('o'))
                                      echo '<option value="'.$i.'" selected>'.$i.'</option>';
                                  else
                                      echo '<option value="'.$i.'">'.$i.'</option>';
                              }?>
                        </select>
                     </div>
                  </div>
                  <!--Description-->
                  <div class="md-form">
                     <textarea type="text" id="newProject4" name="motivo" class="md-textarea"></textarea>
                     <label for="newProject4">Motivo</label>
                  </div>
               </div>
               <!--Footer-->
               <div class="modal-footer justify-content-center">
                  <button type="button" class="btn btn-outline-primary" data-dismiss="modal">Close</button>
                  <input name="ausentarme" type="submit" class="btn btn-primary" value="Enviar">
               </div>
            </form>
         </div>
         <!--/.Content-->
      </div>
   </div>
   <!--Modal: modalSubmitProject-->