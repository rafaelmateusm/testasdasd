    <!--Footer-->
    <footer class="page-footer center-on-small-only pt-0 mt-5 rgba-stylish-light">

        <!--Copyright-->
        <div class="footer-copyright">
            <div class="container-fluid">
                &copy; 2017 Copyright - by HLatino.net / FORBI

            </div>
        </div>
        <!--/.Copyright-->

    </footer>
    <!--/.Footer-->


    <!-- SCRIPTS -->
    <!-- JQuery -->
    <script src="<?php echo HK; ?>previews/templates/js/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap tooltips -->
    <script type="text/javascript" src="<?php echo HK; ?>previews/templates/js/popper.min.js"></script>
    <!-- Bootstrap core JavaScript -->
    <script type="text/javascript" src="<?php echo HK; ?>previews/templates/js/bootstrap.js"></script>
    <!-- MDB core JavaScript -->
    <script type="text/javascript" src="<?php echo HK; ?>previews/templates/js/mdb.min.js"></script>
        <!-- DataTables.net -->
        <script type="text/javascript" src="<?php echo HK; ?>previews/templates/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="<?php echo HK; ?>previews/templates/js/dataTables.bootstrap4.min.js"></script>
	 <script data-cfasync="false" src="<?php echo HK; ?>previews/templates/js/jquery.shop.js" charset="utf-8"></script>
    <!--Initializations-->
    <script>
        // SideNav Initialization
        $(".button-collapse").sideNav();

        var container = document.getElementById('slide-out');
        Ps.initialize(container, {
            wheelSpeed: 2,
            wheelPropagation: true,
            minScrollbarLength: 20
        });

        // Data Picker Initialization
        $('.datepicker').pickadate();

        // Material Select Initialization
        $(document).ready(function () {
            $('.mdb-select').material_select();
        });

        // Tooltips Initialization
        $(function () {
            $('[data-toggle="tooltip"]').tooltip()
        })
    </script>

    <!-- Charts -->
    {ERROR}

</body>

</html>
