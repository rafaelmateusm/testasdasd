<?php
ob_start();
	require_once '../global.php';
	$TplClass->SetParam('title', 'Configuraci&oacute;n Inicial');
	$TplClass->SetParam('zone', 'Configuraci&oacute;n Inicial');
	$Functions->LoggedHk("true");
	$Functions->LoggedHkADMIN("true");
	
	$users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
	$user = $users->fetch_array();

	$TplClass->SetAll();
	if( $_SESSION['ERROR_RETURN'] ){
		$TplClass->SetParam('error', '<script>toastr.error(\''.$_SESSION['ERROR_RETURN'].'\');</script>');
		unset($_SESSION['ERROR_RETURN']);
	}
	if( $_SESSION['GOOD_RETURN'] ){
		$TplClass->SetParam('error', '<script>toastr.success(\''.$_SESSION['GOOD_RETURN'].'\');</script>');
		unset($_SESSION['GOOD_RETURN']);
	}
	$result = $db->query("SELECT * FROM cms_settings WHERE id = 1 LIMIT 1");
	while($data = $result->fetch_array()){
		$SHORTNAME = $data['hotelname'];
		$FACE = $data['facebook'];
		$LOGO = $data['logo'];
	}
	if(isset($_POST['iconfig'])){
		if(empty($_POST['id_room'])){
			$_SESSION['ERROR_RETURN'] = "Has dejado campos vac&iacute;os";
			header("LOCATION: ". HK ."config");
		}else{
			$db->query("ALTER TABLE `users` CHANGE `home_room` `home_room` INT(10) UNSIGNED NOT NULL DEFAULT '". $Functions->FilterText($_POST['id_room']) ."'");
			$db->query("UPDATE users SET home_room = '". $Functions->FilterText($_POST['id_room']) ."'");
			$db->query("INSERT INTO cms_stafflogs (username, action, message, rank, userid, timestamp) VALUES ('". $user['username'] ."','Configuraci&oacute;n del Hotel', 'Ha Actualizado la configuraci&oacute;n incial del Hotel', '". $user['rank'] ."', '". $user['id'] ."', '".date("Y-m-d ")."')");
			
				$_SESSION['GOOD_RETURN'] = "La Configuraci&oacute;n Incial ha sido Actualizada Correctamente";
				header("LOCATION: ". HK ."config");
		}
	}
	$TplClass->AddTemplateHK("templates", "menu");
	ob_end_flush(); 
?>

 <!--Main layout-->
 <main>
 <div class="container-fluid">

     <!--Section: Inputs-->
     <section class="section card mb-5">

     <div class="card-body"><br><br>
         <div class="form-header blue accent-1">
                                    <h3><i class="fa fa-home"></i> Sala de bienvenida</h3>
                                </div>


             <form action="" method="post">
             

                          <!--Grid row-->
                          <div class="row text-left">


                 <!--Grid column-->
                 <div class="col-md-6 mb-r">

                     <!--Email validation-->
                     <div class="md-form">
                         <i class="fa fa-home prefix"></i>
                         <input type="text" id="form9" class="form-control validate" name="id_room">
                         <label for="form9" data-error="wrong" data-success="right">Sala central (de bienvenida)</label>
                     </div>

                 </div>
                 <!--Grid column-->

             </div>
             <!--Grid row-->

             
             <!--Grid row-->
             <center><input type="submit" name="iconfig" class="btn btn-primary waves-effect waves-light" style="width:100%;"></center>
          </div>
          </form>
     </section>
     <!--Section: Inputs-->

     
 </div>
</main>
<!--Main layout-->

   <?php
   //COLUMNA FOOTER
   $TplClass->AddTemplateHK("templates", "footer");
   ?>
