<?php
   ob_start();
   	require_once '../global.php';
   	$TplClass->SetParam('title', 'Gesti&oacute;n de rango');
   	$TplClass->SetParam('zone', 'Gesti&oacute;n de rango');
       $Functions->LoggedHk("true");
       $Functions->LoggedHkADMINMEDIO("true");
          
   	$users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
   	$user = $users->fetch_array();
   	$action = $Functions->FilterText($_GET['action']);
    $id = $Functions->FilterText($_GET['id']);
   
   
   	$TplClass->SetAll();
       if( $_SESSION['ERROR_RETURN'] ){
   $TplClass->SetParam('error', '<script>toastr.error(\''.$_SESSION['ERROR_RETURN'].'\');</script>');
   unset($_SESSION['ERROR_RETURN']);
   }
   if( $_SESSION['GOOD_RETURN'] ){
   $TplClass->SetParam('error', '<script>toastr.success(\''.$_SESSION['GOOD_RETURN'].'\');</script>');
   unset($_SESSION['GOOD_RETURN']);
    }
   	$result = $db->query("SELECT * FROM cms_settings WHERE id = 1 LIMIT 1");
   	$data = $result->fetch_array();
   	$SHORTNAME = $data['hotelname'];
   	$FACE = $data['facebook'];
       $LOGO = $data['logo'];
       
       if($_POST['giverank']){
   $check = $db->query("SELECT * FROM rooms WHERE id = '".$_POST['pin']."'");
   $row = $check->fetch_array();
   
   $c = $db->query("SELECT * FROM navigator_publics WHERE id = '".$id."'");
   $ni = $c->fetch_array();
   
   if(empty($_POST['role']) || empty($_POST['rankid']) || empty($_POST['pin'])){
   $_SESSION['ERROR_RETURN'] = "Has dejado campos vac&iacute;os";
   header("LOCATION: ". HK ."management-salas");
   }elseif($repeat->num_rows > 0){
   $_SESSION['ERROR_RETURN'] = "El Usuario ya cuenta con la Placa ingresada";
   header("LOCATION: ". HK ."management-salas");
   }else{
   if($check->num_rows > 0){
    $result22 = $db->query("SELECT * FROM navigator_categories WHERE id = '".$Functions->FilterText($_POST['rankid'])."'");
    $rankinfo = $result22->fetch_array();
	if($c->num_rows > 0){
		
   $db->query("UPDATE navigator_publics SET room_id = '{$Functions->FilterText($_POST['pin'])}', caption = '{$row['caption']}', description = '{$row['description']}',order_num = '{$Functions->FilterText($_POST['role'])}', category_id = '{$Functions->FilterText($_POST['rankid'])}', `image_url` = '../../newfoto/thumbnail/{$Functions->FilterText($_POST['pin'])}.png' WHERE id = '{$id}'");

		}else{
			$dbQuery= array();
            $dbQuery['room_id'] = $Functions->FilterText($_POST['pin']);
            $dbQuery['caption'] = $Functions->FilterText($row['caption']);
            $dbQuery['description'] = $Functions->FilterText($row['description']);
            $dbQuery['image_url'] = '../../newfoto/thumbnail/'.$Functions->FilterText($_POST['pin']).'.png';
			$dbQuery['order_num'] = $Functions->FilterText($_POST['role']);
			$dbQuery['category_id'] = $Functions->FilterText($_POST['rankid']);
            $query = $db->insertInto('navigator_publics', $dbQuery);
   	}
	$_SESSION['GOOD_RETURN'] = "Sala agregada correctamente";
   	header("LOCATION: ". HK ."management-salas");
   }else {
   	$_SESSION['ERROR_RETURN'] = "Sala no ex&iacute;ste";
   	header("LOCATION: ". HK ."management-salas");
   }
   }
   }
  

   if($action == "dele" && !empty($id)){
    $deleuserrank = $Functions->FilterText($_POST['deleuserrank']);
    
   	$db->query("DELETE FROM navigator_publics WHERE id='{$id}'");
       $_SESSION['GOOD_RETURN'] = "Ha borrado una sala con id: ".$id." correctamente";
           header("LOCATION: ". HK ."management-salas");						
}

   	$TplClass->AddTemplateHK("templates", "menu");
   	ob_end_flush(); 
   ?>
<!--Main layout-->
<main>
   <div class="container-fluid">
   <div style="height: 5px"></div>
   <section class="mb-5" style="width:50%;float:right;margin-right:-85px;">
      <!--Card-->
      <div class="card card-cascade narrower">
         <!--Section: Table-->
         <br>
         <div class="table-ui p-2 mb-3 mx-4 mb-5">
            <div class="view gradient-card-header light-blue lighten-1">
               <h2 class="h2-responsive mb-0">Agregar sala publicas</h2>
            </div>
            <!--Grid row-->
            <!--Grid column-->
            <?php 
            $que2 = $db->query("SELECT * FROM navigator_publics WHERE id = '".$id."'"); 
            $info = $que2->fetch_array();
                ?>
            <form action="" method="post">
               <p class="text-light margin-bottom-20">Rellena todos los campos para agregar sala</p>
			   
			   <center>
                  <p class="lead"><span class="badge info-color p-2">ID DE LA SALA</span></p>
               </center>
               <div class="col-md-6">
                  <input type="number" class="form-control" id="input-text" name="pin" placeholder="ID de la sala" value="<?php echo $info['room_id']; ?>" style="width:213%;">
               </div>
               <center>
                  <p class="lead"><span class="badge info-color p-2">Categoria</span></p>
               </center>
               <center>
                  <select class="mdb-select colorful-select dropdown-info mx-2" name="rankid" style="width:513%;">
                     <option value="" disabled selected>Categoria</option>
                     <?php $que = $db->query("SELECT * FROM navigator_categories WHERE id = 1 || id >= 38 ORDER BY id DESC"); while($qued = $que->fetch_array()){
                        
                             ?>
                     <option value="<?php echo $qued['id']; ?>" <?php echo $skere; ?>><?php echo $qued['public_name']; ?></option>
                     <?php } ?>
                  </select>
               </center>
               <center>
                  <p class="lead"><span class="badge info-color p-2">ORDEN DE LA SALA</span></p>
               </center>
               <div class="col-md-6">
                  <input type="number" class="form-control" id="input-text" name="role" placeholder="Numero de orden" value="<?php echo $info['order_num']; ?>" style="width:213%;">
               </div>
              
               <center><input name="giverank" type="submit" class="btn btn-dark bg-blue-grey-800 color-white margin-left-10" value="Enviar"></center>
            </form>
            <!--Grid column-->
            <!--Grid row-->
         </div>
      </div>
   </section>
   <section class="mb-5" style="width:64%;float:left;margin-left:-80px;margin-top:22px;">


   <div class="row">
                            <div class="col-md-12 mb-1">
                                <!-- Tabs -->
                                <!-- Nav tabs -->
                                <div class="tabs-wrapper">
                                    <ul class="nav classic-tabs tabs-primary primary-color" role="tablist">
                                        <li class="nav-item">
                                            <a class="nav-link waves-light waves-effect waves-light active" data-toggle="tab" href="#panel83" role="tab" aria-selected="true">SALAS PUBLICAS</a>
                                        </li>
                                    </ul>
                                </div>
                                <!-- Tab panels -->
                                <div class="tab-content card">
                                    <!--Panel 1-->
                                    <div class="tab-pane fade active show" id="panel83" role="tabpanel">
                                        <div class="table-responsive">
                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th>ORDEN</th>
                                                        <th>Foto</th>
                                                        <th>Nombre sala</th>
                                                        <th>Categoria de sala</th>
                                                        <th>ID de sala</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
										
                                                <?php $result = $db->query("SELECT * FROM navigator_publics WHERE category_id = 1 || category_id >= 38 ORDER BY order_num ASC");
                                                  if($result->num_rows > 0){
                        	                       while($data = $result->fetch_array()){
													   $que = $db->query("SELECT * FROM navigator_categories WHERE id = '".$data['category_id']."' ORDER BY id DESC"); 
													   $qued = $que->fetch_array();
													   
													   $que2 = $db->query("SELECT * FROM rooms WHERE id = '".$data['room_id']."' ORDER BY id DESC"); 
													   $room = $que2->fetch_array();
                        
                                                        ?>  
                                                             <tr>
                                                        <th scope="row"><?php echo $data['order_num']; ?></th>
                                                        <td><img draggable="false" oncontextmenu="return false" src="<?php echo $data['image_url']; ?>"></td>
                                                        <td><?php echo $room['caption']; ?></td>
                                                        <td><?php echo $qued['public_name']; ?></td>
                                                        <td><?php echo $data['room_id']; ?></td>
                                                        <td>
														    <a class="teal-text" data-toggle="tooltip" data-placement="top" title="Editar" href="<?php echo HK ?>management-salas?id=<?php echo $data['id']; ?>"><i class="fa fa-pencil"></i></a>
                                                            <a href="<?php echo HK ?>management-salas?action=dele&id=<?php echo $data['id']; ?>" class="red-text" data-toggle="tooltip" data-placement="top" title="Remove"><i class="fa fa-times"></i></a>
                                                        </td>
                                                    </tr>                                   
                                                                                                
                                                <?php }} ?>  

												
                                              </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <!--/.Panel 1-->
 
                                </div>
                                <!-- /.Tabs -->
                            </div>
							
						
                        </div>

   </section>
   <!--Section: Table-->
   </div>
   <!--/.Card-->
   <!--Section: Main panel-->
</main>
<!--Main layout-->
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<?php
   //COLUMNA FOOTER
   $TplClass->AddTemplateHK("templates", "footer");
   ?>