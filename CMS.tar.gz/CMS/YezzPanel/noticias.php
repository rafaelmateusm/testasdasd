<?php
   ob_start();
   	require_once '../global.php';
   	$TplClass->SetParam('title', 'Noticias');
   	$TplClass->SetParam('zone', 'Noticias');
    $Functions->LoggedHk("true");
          
   	$users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
   	$user = $users->fetch_array();
   	$action = $Functions->FilterText($_GET['action']);
    $id = $Functions->FilterText($_GET['id']);
   
   
   	$TplClass->SetAll();
   if( $_SESSION['ERROR_RETURN'] ){
   $TplClass->SetParam('error', '<script>toastr.error(\''.$_SESSION['ERROR_RETURN'].'\');</script>');
   unset($_SESSION['ERROR_RETURN']);
   }
   if( $_SESSION['GOOD_RETURN'] ){
   $TplClass->SetParam('error', '<script>toastr.success(\''.$_SESSION['GOOD_RETURN'].'\');</script>');
   unset($_SESSION['GOOD_RETURN']);
    }
   	$result = $db->query("SELECT * FROM cms_settings WHERE id = 1 LIMIT 1");
   	$data = $result->fetch_array();
   	$SHORTNAME = $data['hotelname'];
   	$FACE = $data['facebook'];
    $LOGO = $data['logo'];
   
    function generarCodigo($longitud) {
        $key = '';
        $pattern = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $max = strlen($pattern)-1;
        for($i=0;$i < $longitud;$i++) $key .= $pattern{mt_rand(0,$max)};
        return $key;
       }
       
       if($_POST['addpromo']){
       if(isset($_POST['title']) && isset($_POST['content']) && isset($_POST['longcontent']) && isset($_POST['image']) && isset($_POST['category'])){
        $title = $Functions->FilterText($_POST['title']);
        $content = $_POST['content'];
        $longcontent = $_POST['longcontent'];
        $image = $Functions->FilterText($_POST['image']);
        $category = $Functions->FilterText($_POST['category']);
    
        $cadena = $image;
        $tutorial = explode('.',$cadena);
        $alecode = generarCodigo(10);
        if(empty($title) || empty($image) || empty($content)){
            $_SESSION['ERROR_RETURN'] = "Has dejado campos vac&iacute;os";
            header("LOCATION: ". HK ."news");
        }else{
            $dbQuery= array();
            $dbQuery['title'] = $title;
            $dbQuery['image'] = $image;                
            $dbQuery['story'] = $content;
            $dbQuery['longstory'] = $longcontent;
            $dbQuery['author'] = $user['username'];
            $dbQuery['time'] = time();
            $dbQuery['category'] = $category;
            $dbQuery['sobre'] = 'Leer más';
            $dbQuery['link'] = $Functions->FilterTextLink($title);
            $query = $db->insertInto('cms_slider', $dbQuery);
            $db->query("INSERT INTO cms_stafflogs (username, action, message, rank, userid, timestamp) VALUES ('". $user['username'] ."','Noticias', 'Ha creado la noticia ".$title."', '". $user['rank'] ."', '". $user['id'] ."', '".date("Y-m-d ")."')");
            $_SESSION['GOOD_RETURN'] = "Promo creado correctamente";
            header("LOCATION: ". HK ."news");
        }
    }
}

	if($_POST['editpromo']){
    if(isset($_POST['title']) && isset($_POST['content']) && isset($_POST['longcontent']) && isset($_POST['image'])){
        $title = $Functions->FilterText($_POST['title']);
        $content = $_POST['content'];
        $longcontent = $_POST['longcontent'];
        $image = $Functions->FilterText($_POST['image']);
        if(empty($_POST['title']) || empty($_POST['content']) || empty($_POST['image'])){
            $_SESSION['ERROR_RETURN'] = "Has dejado campos vac&iacute;os";
            header("LOCATION: ". HK ."news?action=edit&id=".$id."");
        }else{
            $db->query("UPDATE cms_slider SET title = '{$title}', story = '{$content}', image = '{$image}', longstory = '{$longcontent}', time = '".time()."', link = '{$Functions->FilterTextLink($title)}' WHERE id = '{$id}' LIMIT 1");
            $db->query("INSERT INTO cms_stafflogs (username, action, message, rank, userid, timestamp) VALUES ('". $user['username'] ."','Noticias', 'Ha editado la noticia ".$title."', '". $user['rank'] ."', '". $user['id'] ."', '".date("Y-m-d ")."')");
            $_SESSION['GOOD_RETURN'] = "Promo editado correctamente";
            header("LOCATION: ". HK ."news?action=edit&id=".$id."");
        }
    }
}

    if($action == "err" && !empty($id)){
   $db->query("INSERT INTO cms_stafflogs (username, action, message, rank, userid, timestamp) VALUES ('". $user['username'] ."','Noticias', 'Ha borrado una noticia', '". $user['rank'] ."', '". $user['id'] ."', '".date("Y-m-d ")."')");
   $db->query("DELETE FROM cms_slider WHERE id = '{$id}' LIMIT 1");
   $_SESSION['GOOD_RETURN'] = "Promo borrado correctamente";
   header("LOCATION: ". HK ."news");
    }
    
   	$TplClass->AddTemplateHK("templates", "menu");
   	ob_end_flush(); 
   ?>
<!--Main layout-->
<main>
   <div class="container">
      <?php global $db;
         if($action == "edit" && !empty($id)){
         $hj = $db->query("SELECT * FROM cms_slider WHERE id = '". $id ."'");
         $h_edit = $hj->fetch_array();
         ?>
      <form action="" method="post">
         <!-- Section: Create Page -->
         <section class="section mt-5">
            <!-- First row -->
            <div class="row">
               <!-- First col -->
               <div class="col-lg-8">
                  <!-- First card -->
                  <div class="card mb-r post-title-panel">
                     <div class="card-body">
                        <div class="md-form mt-1 mb-0">
                           <input type="text" id="form1" class="form-control" name="title"  value="<?php echo $h_edit['title']; ?>">
                           <label for="form1" class="">T&iacute;tulo de la noticia</label>
                        </div>
                     </div>
                  </div>
                  <!-- /.First card -->
                  <!-- Third Card -->
                  <div class="card mb-r">
                     <div class="card-body">
                        <div class="md-form mb-0">
                           <textarea type="text" id="form447" class="md-textarea" name="content"><?php echo $h_edit['story']; ?></textarea>
                           <label for="form447">¿De qué habla la noticia?</label>
                        </div>
                     </div>
                  </div>
                  <!-- /.Third Card -->
                  <!-- First card -->
                  <div class="card mb-r post-title-panel">
                     <div class="card-body">
                        <div class="md-form mt-1 mb-0">
                           <input type="text" id="fform1" class="form-control" name="image" placeholder="Imagen de 160x60 px" value="<?php echo $h_edit['image']; ?>">
                           <label for="fform1" class="">Imagen</label>
                        </div>
                     </div>
                  </div>
                  <!-- /.First card -->
                  <!-- Second card -->
                  <div class="card mb-r">
                     <textarea cols="80" id="editor1" name="longcontent" rows="10" class="md-textarea"><?php echo $h_edit['longstory']; ?></textarea>
                  </div>
                  <!-- /.Second card -->
               </div>
               <!-- /.First col -->
               <!-- Second col -->
               <div class="col-lg-4">
                  <!--Card-->
                  <div class="card card-cascade narrower mb-r">
                     <!--Card image-->
                     <div class="view gradient-card-header blue-gradient">
                        <h4 class="mb-0">Editar</h4>
                     </div>
                     <!--/Card image-->
                     <!--Card content-->
                     <div class="card-body">
                        <p><i class="fa fa-flag mr-1" aria-hidden="true"></i> Estado: <strong>Editando</strong></p>
                        <p><i class="fa fa-eye mr-1" aria-hidden="true"></i> Visibilidad <strong>Publico</strong></p>
                        <p><i class="fa fa-archive mr-1 mr-1" aria-hidden="true"></i> Revisiones: <strong>skere</strong></p>
                        <p><i class="fa fa-calendar mr-1" aria-hidden="true"></i> Publicar: <strong>Inmediatamente</strong></p>
                        <div class="text-right">
                           <button type="button" class="btn-flat waves-effect">Cancelar</button>
                           <input name="editpromo" type="submit"  class="btn btn-primary" value="Publicar">
                        </div>
                     </div>
                     <!--/.Card content-->
                  </div>
                  <!--/.Card-->
                  <!--Card-->
                  <div class="card card-cascade narrower mb-r">
                     <!--Card image-->
                     <div class="view gradient-card-header blue-gradient">
                        <h4 class="mb-0">Noticias creadas</h4>
                     </div>
                     <!--/Card image-->
                     <!--Card content-->
                     <div class="card-body">
                        <div class="panel-body" style="max-height:800px;display: block;overflow: auto;">
                           <?php global $db;
                              $result = $db->query("SELECT * FROM cms_slider ORDER BY id DESC");
                              if($result->num_rows > 0){
                              	while($data = $result->fetch_array()){
                              		echo '<li style="font-size:13px;">&#9758; '.$data['title'].' &#187; <div style="float:right;"><a href="'. HK .'news?action=edit&id='.$data['id'].'"><b><i class="fa fa-pencil-square-o"></i> Editar</b></a> | <a href="'. HK .'news?action=err&id='.$data['id'].'"><b><i class="fa fa-trash-o"></i> Borrar</b></a></div></li><p><b>Autor:</b> '.$data['author'].'<hr>';
                              		unset($k);
                              	}
                              	echo '</ul>';
                              
                              }else{
                              	echo '<b style="color:red;">No hay Promos creados</i>';
                              }
                              ?>
                        </div>
                     </div>
                     <!--/.Card content-->
                  </div>
                  <!--/.Card-->
               </div>
               <!-- /.Second col -->
            </div>
            <!-- /.First row -->
         </section>
         <!-- /.Section: Create Page -->
      </form>
      <?php }else{ ?>
      <form action="" method="post">
         <!-- Section: Create Page -->
         <section class="section mt-5">
            <!-- First row -->
            <div class="row">
               <!-- First col -->
               <div class="col-lg-8">
                  <!-- First card -->
                  <div class="card mb-r post-title-panel">
                     <div class="card-body">
                        <div class="md-form mt-1 mb-0">
                           <input type="text" id="form1" class="form-control" name="title">
                           <label for="form1" class="">T&iacute;tulo de la noticia</label>
                        </div>
                     </div>
                  </div>
                  <!-- /.First card -->
                  <!-- Third Card -->
                  <div class="card mb-r">
                     <div class="card-body">
                        <div class="md-form mb-0">
                           <textarea type="text" id="form447" class="md-textarea" name="content"></textarea>
                           <label for="form447">¿De qué habla la noticia?</label>
                        </div>
                     </div>
                  </div>
                  <!-- /.Third Card -->
                  <!-- First card -->
                  <div class="card mb-r post-title-panel">
                     <div class="card-body">
                        <div class="md-form mt-1 mb-0">
                           <input type="text" id="fform1" class="form-control" name="image" placeholder="Imagen de 160x60 px">
                           <label for="fform1" class="">Imagen</label>
                        </div>
                     </div>
                  </div>
                  <!-- /.First card -->
                  <!-- Second card -->
                  <div class="card mb-r">
                     <textarea cols="80" id="editor1" name="longcontent" rows="10" class="md-textarea"></textarea>
                  </div>
                  <!-- /.Second card -->
               </div>
               <!-- /.First col -->
               <!-- Second col -->
               <div class="col-lg-4">
                  <!--Card-->
                  <div class="card card-cascade narrower mb-r">
                     <!--Card image-->
                     <div class="view gradient-card-header blue-gradient">
                        <h4 class="mb-0">Publicar</h4>
                     </div>
                     <!--/Card image-->
                     <!--Card content-->
                     <div class="card-body">
                        <p><i class="fa fa-flag mr-1" aria-hidden="true"></i> Estado: <strong>Crear</strong></p>
                        <p><i class="fa fa-eye mr-1" aria-hidden="true"></i> Visibilidad <strong>Publico</strong></p>
                        <p><i class="fa fa-archive mr-1 mr-1" aria-hidden="true"></i> Revisiones: <strong>skere</strong></p>
                        <p><i class="fa fa-calendar mr-1" aria-hidden="true"></i> Publicar: <strong>Inmediatamente</strong></p>
                        <div class="text-right">
                           <button type="button" class="btn-flat waves-effect">Cancelar</button>
                           <input name="addpromo" type="submit" class="btn btn-primary" value="Publicar">
                        </div>
                     </div>
                     <!--/.Card content-->
                  </div>
                  <!--/.Card-->
                  <!--Card-->
                  <div class="card card-cascade narrower mb-r">
                     <!--Card image-->
                     <div class="view gradient-card-header blue-gradient">
                        <h4 class="mb-0">Categorías</h4>
                     </div>
                     <!--/Card image-->
                     <!--Card content-->
                     <div class="card-body">
                     <select class="mdb-select colorful-select dropdown-info mx-2" name="category">
                     <option value="General" selected>General</option>
										<option value="Actualizaciones">Actualizaciones</option>
										<option value="Competiciones">Competiciones</option>
										<option value="Concursos">Concursos</option>
										<option value="Encuestas">Encuestas</option>
										<option value="Informativo">Informativo</option>
										<option value="Radio">Radio</option>
										<option value="Soporte">Soporte</option>                     
                  </select>
                        
                     </div>
                     <!--/.Card content-->
                  </div>
                  <!--/.Card-->
                  <!--Card-->
                  <div class="card card-cascade narrower mb-r">
                     <!--Card image-->
                     <div class="view gradient-card-header blue-gradient">
                        <h4 class="mb-0">Noticias creadas</h4>
                     </div>
                     <!--/Card image-->
                     <!--Card content-->
                     <div class="card-body">
                        <div class="panel-body" style="max-height:800px;display: block;overflow: auto;">
                           <?php global $db;
                              $result = $db->query("SELECT * FROM cms_slider ORDER BY id DESC");
                              if($result->num_rows > 0){
                              	while($data = $result->fetch_array()){
                              		echo '<li style="font-size:13px;">&#9758; '.$data['title'].' &#187; <div style="float:right;"><a href="'. HK .'news?action=edit&id='.$data['id'].'"><b><i class="fa fa-pencil-square-o"></i> Editar</b></a> | <a href="'. HK .'news?action=err&id='.$data['id'].'"><b><i class="fa fa-trash-o"></i> Borrar</b></a></div></li><p><b>Autor:</b> '.$data['author'].'<hr>';
                              		unset($k);
                              	}
                              	echo '</ul>';
                              
                              }else{
                              	echo '<b style="color:red;">No hay Promos creados</i>';
                              }
                              ?>
                        </div>
                     </div>
                     <!--/.Card content-->
                  </div>
                  <!--/.Card-->
               </div>
               <!-- /.Second col -->
            </div>
            <!-- /.First row -->
         </section>
         <!-- /.Section: Create Page -->
      </form>
      <?php } ?>
   </div>
</main>
<!--Main layout-->
<?php
   //COLUMNA FOOTER
   $TplClass->AddTemplateHK("templates", "footer");
   ?>
<script type="text/javascript">
   CKEDITOR.replace ("editor1");
</script>