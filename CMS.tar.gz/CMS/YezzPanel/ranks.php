<?php
   ob_start();
   	require_once '../global.php';
   	$TplClass->SetParam('title', 'Gesti&oacute;n de rango');
   	$TplClass->SetParam('zone', 'Gesti&oacute;n de rango');
       $Functions->LoggedHk("true");
       $Functions->LoggedHkADMINMEDIO("true");
          
   	$users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
   	$user = $users->fetch_array();
   	$action = $Functions->FilterText($_GET['action']);
    $id = $Functions->FilterText($_GET['id']);
   
   
   	$TplClass->SetAll();
       if( $_SESSION['ERROR_RETURN'] ){
   $TplClass->SetParam('error', '<script>toastr.error(\''.$_SESSION['ERROR_RETURN'].'\');</script>');
   unset($_SESSION['ERROR_RETURN']);
   }
   if( $_SESSION['GOOD_RETURN'] ){
   $TplClass->SetParam('error', '<script>toastr.success(\''.$_SESSION['GOOD_RETURN'].'\');</script>');
   unset($_SESSION['GOOD_RETURN']);
    }
   	$result = $db->query("SELECT * FROM cms_settings WHERE id = 1 LIMIT 1");
   	$data = $result->fetch_array();
   	$SHORTNAME = $data['hotelname'];
   	$FACE = $data['facebook'];
       $LOGO = $data['logo'];
       
       if($_POST['giverank']){
   $check = $db->query("SELECT * FROM users WHERE username = '".$Functions->FilterText($_POST['name'])."' LIMIT 1");
   $row = $check->fetch_array();
   
   if(empty($_POST['name']) || empty($_POST['role']) || empty($_POST['cms_rank']) || empty($_POST['rankid']) || empty($_POST['pin'])){
   $_SESSION['ERROR_RETURN'] = "Has dejado campos vac&iacute;os";
   header("LOCATION: ". HK ."management-ranks");
   }elseif($repeat->num_rows > 0){
   $_SESSION['ERROR_RETURN'] = "El Usuario ya cuenta con la Placa ingresada";
   header("LOCATION: ". HK ."management-ranks");
   }else{
   if($check->num_rows > 0){
    $result22 = $db->query("SELECT * FROM ranks WHERE id = '".$Functions->FilterText($_POST['rankid'])."'");
    $rankinfo = $result22->fetch_array();
   	$db->query("UPDATE users SET cms_rank = '{$Functions->FilterText($_POST['cms_rank'])}', cms_role = '{$Functions->FilterText($_POST['role'])}', rank = '{$Functions->FilterText($_POST['rankid'])}', pin_client = '{$Functions->FilterText($_POST['pin'])}', cms_staffocult = '{$Functions->FilterText($_POST['ocult'])}', user_rank = '{$Functions->FilterText($_POST['user_rank'])}', tag = '®', guia = '{$Functions->FilterText($_POST['helper_level'])}', respetos = '5' WHERE username = '{$_POST['name']}'");
   	$db->query("INSERT INTO cms_stafflogs (username, action, message, rank, userid, timestamp) VALUES ('". $user['username'] ."','Dar Rango', 'Le ha dado rango ".$_POST['rankid']." a ".$_POST['name']."', '". $user['rank'] ."', '". $user['id'] ."', '".date("Y-m-d ")."')");
   	
   	$_SESSION['GOOD_RETURN'] = "Rango entregado correctamente";
   	header("LOCATION: ". HK ."management-ranks");
   }else {
   	$_SESSION['ERROR_RETURN'] = "El usuario no ex&iacute;ste";
   	header("LOCATION: ". HK ."management-ranks");
   }
   }
   }

   if($action == "dele" && !empty($id)){
    $deleuserrank = $Functions->FilterText($_POST['deleuserrank']);
    
       $db->query("INSERT INTO cms_stafflogs (username, action, message, rank, userid, timestamp) VALUES ('". $user['username'] ."','Quitar rango', 'Le ha quitado el rango a el ususario con id: ".$id."', '".date("Y-m-d ")."')");
   	$db->query("UPDATE users SET cms_role = '', rank = '1', pin_client = '0', user_rank = '1', tag = '', tagcolor = '', guia = '0', respetos = '3' WHERE id = '{$id}'");
       $_SESSION['GOOD_RETURN'] = "Le ha quitado rank a el ususario con id: ".$id." correctamente";
           header("LOCATION: ". HK ."management-ranks");						
}
   	$TplClass->AddTemplateHK("templates", "menu");
   	ob_end_flush(); 
   ?>
<!--Main layout-->
<main>
   <div class="container-fluid">
   <div style="height: 5px"></div>
   <section class="mb-5" style="width:50%;float:right;margin-right:-85px;">
      <!--Card-->
      <div class="card card-cascade narrower">
         <!--Section: Table-->
         <br>
         <div class="table-ui p-2 mb-3 mx-4 mb-5">
            <div class="view gradient-card-header light-blue lighten-1">
               <h2 class="h2-responsive mb-0">Dar Rango</h2>
            </div>
            <!--Grid row-->
            <!--Grid column-->
            <?php 
            $que2 = $db->query("SELECT * FROM users WHERE id = '".$id."'"); 
            $info = $que2->fetch_array();
                ?>
            <form action="" method="post">
               <p class="text-light margin-bottom-20">Rellena todos los campos para dar una Placa</p>
               <center>
                  <p class="lead"><span class="badge info-color p-2">Ususario</span></p>
               </center>
               <div class="col-md-6">
                  <input type="text" class="form-control" id="input-text" name="name" placeholder="Usuario a dar el rango" value="<?php echo $info['username']; ?>" style="width:213%;">
               </div>
			   
			   <center>
                  <p class="lead"><span class="badge info-color p-2">Posición. EJ: Fundador</span></p>
               </center>
               <div class="col-md-6">
                  <input type="text" class="form-control" id="input-text" name="cms_rank" placeholder="Posición" value="<?php echo $info['cms_rank']; ?>" style="width:213%;">
               </div>
			   
               <center>
                  <p class="lead"><span class="badge info-color p-2">Rango</span></p>
               </center>
               <center>
                  <select class="mdb-select colorful-select dropdown-info mx-2" name="rankid" style="width:513%;">
                     <option value="" disabled selected>Rango</option>
                     <?php if($user['rank'] > 16){ 
                         $que = $db->query("SELECT * FROM ranks ORDER BY id DESC");
                          }else{
                         $que = $db->query("SELECT * FROM ranks WHERE id < 13 ORDER BY id DESC"); 
                        }
                        while($qued = $que->fetch_array()){
                         if($qued['id'] == $info['rank']){
                             $skere = 'selected';
                            }else{
                             $skere = '';}
                             ?>
                     <option value="<?php echo $qued['id']; ?>" <?php echo $skere; ?>><?php echo $qued['name']; ?></option>
                     <?php } ?>
                  </select>
               </center>
               <center>
                  <p class="lead"><span class="badge info-color p-2">PIN</span></p>
               </center>
               <div class="col-md-6">
                  <input type="text" class="form-control" id="input-text" name="pin" placeholder="Pin de Acceso" value="<?php echo $info['pin_client']; ?>" style="width:213%;">
               </div>
               <center>
                  <p class="lead"><span class="badge info-color p-2">Trabajo a realizar</span></p>
               </center>
               <div class="col-md-6">
                  <input type="text" class="form-control" id="input-text" name="role" placeholder="Trabajo a realizar" value="<?php echo $info['cms_role']; ?>" style="width:213%;">
               </div>
               <center>
                  <p class="lead"><span class="badge info-color p-2">¿Encargado de?</span></p>
               </center>
               <center>
                  <select class="mdb-select colorful-select dropdown-info mx-2" name="user_rank" style="width:513%;">
                  <?php 
                         if($info['user_rank'] == 8){
                             $skere2 = 'selected';
                            }else{
                                $skere2 = '';}

                                if($info['user_rank'] == 11){
                                    $skere22 = 'selected';
                                   }else{
                                       $skere22 = '';}
									   
									   if($info['user_rank'] == 12){
                                    $skere222 = 'selected';
                                   }else{
                                       $skere222 = '';}
 
                             ?>
                     <option value="0" disabled selected>¿Encargado de?</option>
                     <option value="8" <?php echo $skere2; ?>>Embajador</option>
                     <option value="11" <?php echo $skere22; ?>>Moderador</option>
					 <option value="12" <?php echo $skere222; ?>>Animación (GM)</option>
                  </select>
               </center>
               <center>
                  <p class="lead"><span class="badge info-color p-2">¿Es guía? nivel</span></p>
               </center>
               <center>
                  <select class="mdb-select colorful-select dropdown-info mx-2" name="helper_level" style="width:513%;">
                  <?php if($info['guia'] == 0){$guia = 'selected';}else{$guia = '';}
                  if($info['guia'] == 1){$guia1 = 'selected';}else{$guia1 = '';}
                  if($info['guia'] == 2){$guia2 = 'selected';}else{$guia2 = '';}
                  if($info['guia'] == 3){$guia2 = 'selected';}else{$guia3 = '';}
                  if($info['guia'] == 4){$guia4 = 'selected';}else{$guia4 = '';}

                                
                                       ?>
                     <option value="0" disabled selected>Guía Nivel</option>
                     <option value="0" <?php echo $guia; ?>>No</option>
                     <option value="1" <?php echo $guia1; ?>>Nivel 1</option>
                     <option value="2" <?php echo $guia2; ?>>Nivel 2</option>
                     <option value="3" <?php echo $guia3; ?>>Nivel 3</option>
                     <option value="4" <?php echo $guia4; ?>>Nivel 4</option>
                  </select>
               </center>
               <center>
                  <p class="lead"><span class="badge info-color p-2">Rango Oculto</span></p>
               </center>
               <center>
                  <select class="mdb-select colorful-select dropdown-info mx-2" name="ocult" style="width:513%;">
                  <?php if($info['cms_staffocult'] == 0){
                             $oculto = 'selected';
                            }else{
                                $oculto = '';}

                                if($info['cms_staffocult'] == 1){
                                    $oculto1 = 'selected';
                                   }else{
                                    $oculto1 = '';}
 
                             ?>
                     <option value="0" disabled selected>Rango Oculto</option>
                     <option value="0" <?php echo $oculto; ?>>No</option>
                     <option value="1" <?php echo $oculto1; ?>>S&iacute;</option>
                  </select>
               </center>
               <center><input name="giverank" type="submit" class="btn btn-dark bg-blue-grey-800 color-white margin-left-10" value="Enviar"></center>
            </form>
            <!--Grid column-->
            <!--Grid row-->
         </div>
      </div>
   </section>
   <section class="mb-5" style="width:64%;float:left;margin-left:-80px;margin-top:22px;">


   <div class="row">
                            <div class="col-md-12 mb-1">
                                <!-- Tabs -->
                                <!-- Nav tabs -->
                                <div class="tabs-wrapper">
                                    <ul class="nav classic-tabs tabs-primary primary-color" role="tablist">
                                        <li class="nav-item">
                                            <a class="nav-link waves-light waves-effect waves-light active" data-toggle="tab" href="#panel83" role="tab" aria-selected="true">Usuarios con rango</a>
                                        </li>
                                    </ul>
                                </div>
                                <!-- Tab panels -->
                                <div class="tab-content card">
                                    <!--Panel 1-->
                                    <div class="tab-pane fade active show" id="panel83" role="tabpanel">
                                        <div class="table-responsive">
                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Look</th>
                                                        <th>Usuario</th>
                                                        <th>Rango</th>
                                                        <th>IP</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                <?php $result = $db->query("SELECT * FROM users WHERE rank >= 3 ORDER BY rank DESC");
                                                  if($result->num_rows > 0){
                        	                       while($data = $result->fetch_array()){
                        
                                                        $result2 = $db->query("SELECT * FROM ranks WHERE id = '".$data['rank']."'");
                                                        $data2 = $result2->fetch_array(); ?>  
                                                             <tr>
                                                        <th scope="row"><?php echo $data['id']; ?></th>
                                                        <td><img draggable="false" oncontextmenu="return false" src="https://www.habbo.nl/habbo-imaging/avatarimage?figure=<?php echo $data['look']; ?>&amp;gesture=sml&headonly=1"></td>
                                                        <td><?php echo $data['username']; ?></td>
                                                        <td><?php echo $data2['name']; ?></td>
                                                        <td><?php echo $data['ip_last']; ?></td>
                                                        <td>
                                                            <a class="blue-text" data-toggle="tooltip" data-placement="top" title="Ver perfil" href="<?php echo PATH ?>/profile/<?php echo $data['username']; ?>" target="_blank"><i class="fa fa-user"></i></a>
                                                            <a class="teal-text" data-toggle="tooltip" data-placement="top" title="Editar" href="<?php echo HK ?>management-ranks?id=<?php echo $data['id']; ?>"><i class="fa fa-pencil"></i></a>
                                                            <a href="<?php echo HK ?>management-ranks?action=dele&id=<?php echo $data['id']; ?>" class="red-text" data-toggle="tooltip" data-placement="top" title="Remove"><i class="fa fa-times"></i></a>
                                                        </td>
                                                    </tr>                                   
                                                                                                
                                                <?php }} ?>                                
                                              </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <!--/.Panel 1-->
 
                                </div>
                                <!-- /.Tabs -->
                            </div>
                        </div>

   </section>
   <!--Section: Table-->
   </div>
   <!--/.Card-->
   <!--Section: Main panel-->
</main>
<!--Main layout-->
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<?php
   //COLUMNA FOOTER
   $TplClass->AddTemplateHK("templates", "footer");
   ?>