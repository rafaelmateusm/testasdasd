<?php
ob_start();
	require_once '../global.php';
	$TplClass->SetParam('title', 'Atención de reportes');
	$TplClass->SetParam('zone', 'Reportes');
	$Functions->LoggedHk("true");
	
	$users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
	$user = $users->fetch_array();
	$do = $Functions->FilterText($_GET['do']);
	$key = $Functions->FilterText($_GET['key']);

	$TplClass->SetAll();
	if( $_SESSION['ERROR_RETURN'] ){
		$TplClass->SetParam('error', '<script>toastr.error(\''.$_SESSION['ERROR_RETURN'].'\');</script>');
		unset($_SESSION['ERROR_RETURN']);
	}
	if( $_SESSION['GOOD_RETURN'] ){
		$TplClass->SetParam('error', '<script> toastr.success(\''.$_SESSION['GOOD_RETURN'].'\'); </script>');
		unset($_SESSION['GOOD_RETURN']);
	}
	$result = $db->query("SELECT * FROM cms_settings WHERE id = 1 LIMIT 1");
	while($data = $result->fetch_array()){
		$SHORTNAME = $data['hotelname'];
		$FACE = $data['facebook'];
		$LOGO = $data['logo'];
    }
    
    $id = $Functions->FilterText($_GET['id']);
    
    $result4 = $db->query("SELECT * FROM cms_tickets WHERE id = '".$id."'");
    $tickets = $result4->fetch_array();

    if($_POST['rticket']){
        if(isset($_POST['content2'])){
          $content2 = $Functions->FilterText($_POST['content2']);
          $dbQuery= array();
            $dbQuery['username'] = $_SESSION['username'];
            $dbQuery['content'] = $content2;
            $dbQuery['category'] = $tickets['category'];
            $dbQuery['time'] = time();
            $dbQuery['type'] = "respuestaticket";
            $dbQuery['priority'] = $tickets['priority'];
            $dbQuery['title'] = $tickets['title'];
            $dbQuery['posted_in'] = $id;
            $query = $db->insertInto('cms_tickets', $dbQuery);
            $db->query("UPDATE cms_tickets SET visto = '1' WHERE id = '{$id}'");  
            $db->query("INSERT INTO cms_stafflogs (username, action, message, rank, userid, timestamp) VALUES ('". $user['username'] ."','Tickets', 'Le ha respondido el ticket a ".$tickets['username']." (".$tickets['title'].")', '". $user['rank'] ."', '". $user['id'] ."', '".date("Y-m-d ")."')");
            $_SESSION['GOOD_RETURN'] = "Ticket respondido corectamente";                    
            header("LOCATION: ". HK ."/reports-view?id=".$id."");
          }
        }

	$TplClass->AddTemplateHK("templates", "menu");
	ob_end_flush(); 
?>

<script> toastr.success('sdfsdf'); </script>
 <!--Main layout-->
 <main>
 <div class="container-fluid">

     <!--Section: Chat-->
     <section class="section">

         <!--Grid row-->
         <div class="row">

             <!--Grid column-->
             <div class="col-md-4">

                 <!--Name-->
                 <div class="md-form form-sm">
                     <i class="fa fa-search prefix"></i>
                     <input type="text" id="searchConv" class="form-control">
                     <label for="searchConv" class="">Search Message</label>
                 </div>


                 <!-- Messages -->
                 <div class="list-group">

                 <?php global $db;
                $resultticket = $db->query("SELECT * FROM cms_tickets WHERE type = 'ticket' && visto = '0' ORDER BY id DESC");
                if($resultticket->num_rows > 0){
                  while($ticket = $resultticket->fetch_array()){
                    $resultuser = $db->query("SELECT * FROM users WHERE username = '".$ticket['username']."' ORDER BY id DESC");
                    $userinfo = $resultuser->fetch_array();

                    $resultticket2 = $db->query("SELECT * FROM cms_tickets WHERE posted_in = '".$ticket['id']."' OR id = '".$ticket['id']."' ORDER BY id DESC LIMIT 1");
                    $ticketinfo2 = $resultticket2->fetch_array();

                    if($ticket['id'] == $id){
                        $active = 'active';
                         }else{
                         $active = '';
                     }

                     if($userinfo['gender'] == 'M'){
                        $gender = 'El';
                         }else{
                         $gender = 'Ella';
                     }
                     
                     ?>

                     <!-- Single message -->
                     <a href="<?php echo HK; ?>reports-view?id=<?php echo $ticket['id']; ?>" class="list-group-item list-group-item-action media <?php echo $active; ?>">
                         <!-- Avatar -->

                         <img draggable="false" oncontextmenu="return false" class="mr-3 avatar-sm float-left" src="<?php echo AVATARIMAGE . $userinfo['look']; ?>&head_direction=1">

                         <!-- Author -->
                         <div class="d-flex justify-content-between mb-1 ">
                             <hp class="mb-1"><strong><?php echo $userinfo['username']; ?></strong></hp>
                             <small><?php echo $Functions->GetLast2($ticketinfo2['time']); ?></small>
                         </div>

                         <!-- Message -->
                         <p class="text-truncate"><strong><?php echo $gender; ?>: </strong><?php echo $Functions->FilterText($ticketinfo2['content']); ?></p>
                     </a>
                     <?php }} ?>


                 </div>
                 <!-- Messages -->

             </div>
             <!--Grid column-->

             <!--Grid column-->
             <div class="col-md-8">

                 <!-- Conversation -->
                 <div class="border border-dark p-4">

             <!-- Your Message -->
                <div class="text-center"><small>Recibido <?php echo $Functions->GetLast2($tickets['time']); ?></small></div>
                     <div class="d-flex justify-content-start media">
                         <!-- Avatar -->
                         <img draggable="false" oncontextmenu="return false" class="mr-3 avatar-sm float-left" src="<?php echo AVATARIMAGE . $userinfo['look']; ?>&head_direction=2&headonly=1">

                         <p class="grey lighten-3 rounded p-3 w-75"><?php echo $Functions->FilterTexForum($tickets['content']); ?></p>
                     </div>
                 <?php global $db;
							$comentarios2 = $db->query("SELECT * FROM cms_tickets WHERE posted_in = '".$id."' ORDER BY id ASC");
							if($comentarios2->num_rows > 0){
								while($coment = $comentarios2->fetch_array()){
									$userinfo = $db->query("SELECT * FROM users WHERE username = '".$coment['username']."'");
									$userrinf = $userinfo->fetch_array();
                    $mensaje2 = $Functions->FilterTexForum($coment['content']);

                    if($coment['type'] == "respuestaticket"){
                                        
                    ?>

                     <!-- My Message -->
                     <div class="text-center"><small>Enviado <?php echo $Functions->GetLast2($coment['time']); ?></small></div>
                     <div class="d-flex justify-content-end">
                         <p class="primary-color rounded p-3 text-white w-75 "><?php echo $mensaje2; ?> </p>
                     </div>

                     <?php }else{ ?>

                     <!-- Your Message -->
                     <div class="text-center"><small>Recibido <?php echo $Functions->GetLast2($coment['time']); ?></small></div>
                     <div class="d-flex justify-content-start media">
                         <!-- Avatar -->
                         <img draggable="false" oncontextmenu="return false" class="mr-3 avatar-sm float-left" src="<?php echo AVATARIMAGE . $userrinf['look']; ?>&head_direction=2&headonly=1">
                         
                         <p class="grey lighten-3 rounded p-3 w-75"><?php echo $mensaje2; ?></p>
                     </div>

                     <?php }}} ?>
                     <!-- New message -->
              <form action="" method="POST">
                     <div class="row">
                         <div class="col-md-12">
                             
                             <div class="form-inline">
                                <div class="md-form form-group chat-message-type">
                                     <textarea name="content2" type="text" id="form7" class="md-textarea"></textarea>
                                     <label for="form7">Responda el ticket</label>
                                 </div>

                                 <div class="md-form form-group">
                                 <input class="btn btn-primary btn-lg" type="submit" name="rticket" />
                                 </div>
                                 
                             </div>

                         </div>

                     </div>
                     </form>
                     <!-- /.New message -->

                 </div>
                 <!-- Conversation -->

             </div>
             <!--Grid column-->

         </div>
         <!--/.Grid row-->

     </section>
     <!--Section: Chat-->

 </div>
</main>
<!--Main layout-->


   <?php
   //COLUMNA FOOTER
   $TplClass->AddTemplateHK("templates", "footer");
   ?>
