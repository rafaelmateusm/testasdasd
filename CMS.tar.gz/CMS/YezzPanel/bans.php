<?php
   ob_start();
   	require_once '../global.php';
   	$TplClass->SetParam('title', 'Gesti&oacute;n de bans');
   	$TplClass->SetParam('zone', 'Gesti&oacute;n de bans');
   	$Functions->LoggedHk("true");
   	
   	$users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
   	$user = $users->fetch_array();
   	$action = $Functions->FilterText($_GET['action']);
   	$id = $Functions->FilterText($_GET['id']);
   	
   
   	$TplClass->SetAll();
       if( $_SESSION['ERROR_RETURN'] ){
		$TplClass->SetParam('error', '<script>toastr.error(\''.$_SESSION['ERROR_RETURN'].'\');</script>');
		unset($_SESSION['ERROR_RETURN']);
	}
	if( $_SESSION['GOOD_RETURN'] ){
		$TplClass->SetParam('error', '<script>toastr.success(\''.$_SESSION['GOOD_RETURN'].'\');</script>');
		unset($_SESSION['GOOD_RETURN']);
    }
   	$result = $db->query("SELECT * FROM cms_settings WHERE id = 1 LIMIT 1");
   	$data = $result->fetch_array();
   	$SHORTNAME = $data['hotelname'];
   	$FACE = $data['facebook'];
       $LOGO = $data['logo'];
       
   	if($_POST['addban']){
   		$check = $db->query("SELECT * FROM users WHERE username = '".$Functions->FilterText($_POST['user'])."' LIMIT 1");
   		$row = $check->fetch_array();
   		$checkb = $db->query("SELECT * FROM bans WHERE value = '".$Functions->FilterText($_POST['user'])."' || '".$Functions->FilterText($row['ip_last'])."' LIMIT 1");
           $actv = $checkb->fetch_array();
           
   		if(isset($_POST['user']) && isset($_POST['time']) && isset($_POST['tipo']) && isset($_POST['razon'])){
   			$time = $Functions->FilterText($_POST['time']);
               $razon = $Functions->FilterText($_POST['razon']);
               

   				if($actv['expire'] > time()){
   					$_SESSION['ERROR_RETURN'] = "El usuario ya se encuentra Baneado";
   					header("LOCATION: ". HK ."management-bans");
   				}else{
   					if($check->num_rows > 0){
   						$db->query("DELETE FROM bans WHERE value = '".$Functions->FilterText($_POST['user'])."' || '".$Functions->FilterText($row['ip_last'])."' LIMIT 1");
   						if($row['rank'] >= $Functions->Get('rank')){
   							$_SESSION['ERROR_RETURN'] = "No puedes banear a un superior o a ti mismo";
   							header("LOCATION: ". HK ."management-bans");
   						}else{
   							$db->query("INSERT INTO cms_stafflogs (username, action, message, rank, userid, timestamp) VALUES ('". $_SESSION['username'] ."','Baneos', 'Baneo a ". $row['username'] .", Raz&oacute;n: ".$razon."', '". $user['rank'] ."', '". $user['id'] ."', '".date("Y-m-d ")."')");
   							if($_POST['tipo'] == "2"){
   								$banuuu = $row['ip_last'];
   								$baneee = "machine";
   							}else{
   								$banuuu = $Functions->FilterText($_POST['user']);
   								$baneee = "user";
   							}	
   							$dbAdd= array();
   							$dbAdd['id'] = NULL;
   							$dbAdd['bantype'] = $baneee;
   							$dbAdd['value'] = $banuuu;
   							$dbAdd['reason'] = $razon;
   							$dbAdd['expire'] = time() + $time;
   							$dbAdd['added_by'] = $_SESSION['username'];
   							$dbAdd['added_date'] = time();
   							$query = $db->insertInto('bans', $dbAdd);
   							//$db->query("INSERT INTO bans_access (user_id, ip, attempts) VALUES ('". $row['id'] ."', '". $row['ip_last'] ."', '1')");
   							$_SESSION['GOOD_RETURN'] = "Usuario Baneado correctamente";
   							header("LOCATION: ". HK ."management-bans");		
   						}
   					}else{
   						$_SESSION['ERROR_RETURN'] = "No puedes banear a este usuario";
   						header("LOCATION: ". HK ."management-bans");	
   					
   					}
   				}
   			}
           }
           if(isset($_POST['deleban'])){
            $deleban = $Functions->FilterText($_POST['deleban']);
            
   			$db->query("INSERT INTO cms_stafflogs (username, action, message, rank, userid, timestamp) VALUES ('". $user['username'] ."','Desbaneos', 'Ha desbaneado a el usuario/ip ".$deleban."', '". $user['rank'] ."', '". $user['id'] ."', '".date("Y-m-d ")."')");
   			$db->query("DELETE FROM bans WHERE value = '{$deleban}' LIMIT 1");
   			$_SESSION['GOOD_RETURN'] = "Baneo borrado correctamente";
   				header("LOCATION: ". HK ."management-bans");						
       }
       
   	$TplClass->AddTemplateHK("templates", "menu");
   	ob_end_flush(); 
   ?>

<!--Main layout-->
<main>
<div class="container-fluid">

    <div style="height: 5px"></div>

    <!--Section: Main panel-->
    <section class="mb-5">

        <!--Card-->
        <div class="card card-cascade narrower">

            <!--Section: Chart-->
            <section>

                <!--Grid row-->
                <div class="row">
                    <!--Grid column-->
                    <div class="col-xl-5 col-lg-12 mr-0">

                        <!--Card image-->
                        <div class="view gradient-card-header light-blue lighten-1">
                            <h2 class="h2-responsive mb-0">Dar ban</h2>
                        </div>
                        <!--/Card image-->
                        <form action="" method="post">

                        <!--Card content-->
                        <div class="card-body pb-0">

                            <!--Panel data-->
                            <div class="row card-body pt-3">

                                <!--First column-->
                                <div class="col-md-6">

                                    <!--Date select-->
                                    <p class="lead"><span class="badge info-color p-2">Ususario</span></p>
                                    <input class="form-control my-0 py-0" type="text" style="width:110%;" name="user" placeholder="Usuario a Banear" >
                                    <select class="mdb-select colorful-select dropdown-info mx-2" name="tipo" style="margin-top:1px;">
                                <option value="" disabled selected>Banear por IP o User</option>
                                <option value="1">Banear por nombre</option>
                                <option value="2">Banear tambi&eacute;n por IP</option>
                             </select>
                                </div>
                                <!--/First column-->

                                <!--First column-->
                                <div class="col-md-6">

                                    <!--Date select-->
                                    <p class="lead"><span class="badge info-color p-2">Duraci&oacute;n</span></p>
                            <!--Name-->
                            <select class="mdb-select colorful-select dropdown-info mx-2" name="time" style="margin-top:1px;">
                                <option value="" disabled selected>Tiempo</option>
                                <option value="3600">1 hora</option>
                                <option value="7200">2 horas</option>
                                <option value="10800">3 horas</option>
                                <option value="14400">4 horas</option>
                                <option value="43200">12 horas</option>
                                <option value="86400">1 dia</option>
                                <option value="259200">3 dias</option>
                                <option value="604800">1 semana</option>
                                <option value="1209600">2 semanas</option>
                                <option value="2592000">1 mes</option>
                                <option value="7776000">3 meses</option>
                                <option value="1314000">1 a&ntilde;o</option>
                                <option value="2628000">2 a&ntilde;os</option>
                                <option value="360000000"> 10 a&ntilde;os</option>
                            </select>


                                </div>
                                <!--/First column-->
                                <div></div>

                                    <!--Date select-->
                                    
 
                                 
                            </div>
                            <center><p class="lead"><span class="badge info-color p-2">Raz&oacute;n</span></p>
                                    <input class="form-control my-0 py-0" type="text" style="width:115%;" name="razon" placeholder="Raz&oacute;n del Baneo">
                                    </center><br>
                            <!--/Panel data-->
                            <center><input name="addban" type="submit" class="btn btn-dark-green waves-effect waves-light" value="Banear"></center>
							</form>
                        </div>
                        <!--/.Card content-->

                    </div>
                    <!--Grid column-->
                    
                    <!--Grid column-->
                    <div class="col-xl-7 col-lg-12 mb-r">

                        <!--Card image-->
                        <div class="view gradient-card-header blue-gradient">

                            <!-- Chart -->
                            <canvas id="lineChart" height="175"></canvas>

                        </div>
                        <!--/Card image-->

                    </div>
                    <!--Grid column-->

                </div>
                <!--Grid row-->

            </section>
            <!--Section: Chart-->

            <!--Section: Table-->
            <section>

                <div class="card card-cascade narrower z-depth-0">

                    <!--Card image-->
                    <div class="view gradient-card-header blue-gradient narrower py-2 mx-4 mb-3 d-flex justify-content-between align-items-center">

                        <div>
                            <button type="button" class="btn btn-outline-white btn-rounded btn-sm px-2"><i class="fa fa-th-large mt-0"></i></button>
                            <button type="button" class="btn btn-outline-white btn-rounded btn-sm px-2"><i class="fa fa-columns mt-0"></i></button>
                        </div>

                        <a href="" class="white-text mx-3">Baneos del Hotel</a>

                        <div>
                        <script type="text/javascript">function banPreset(val){document.getElementById('banlength').value = val;}</script>
                        <form action="" method="post">
                            <button name="deleban" id="banlength" value="" class="btn btn-outline-white btn-rounded btn-sm px-2"><i class="fa fa-remove mt-0"></i></button>
                            </form>
                        </div>

                    </div>
                    <!--/Card image-->

                    <div class="px-4">

                        <div class="table-responsive">
                            <!--Table-->
                            <table class="table table-hover mb-0">

                                <!--Table head-->
                                <thead>
                                    <tr>
                                        <th>
                                            <input type="checkbox" id="checkbox">
                                            <label for="checkbox" class="mr-2 label-table"></label>
                                        </th>
                                        <th class="th-lg"><a>Usuario <i class="fa fa-sort ml-1"></i></th>
                                        <th class="th-lg">Estado<i class="fa fa-sort ml-1"></i></th>
                                        <th class="th-lg">Raz&oacute;n<i class="fa fa-sort ml-1"></i></th>
                                        <th class="th-lg">Baneado por<i class="fa fa-sort ml-1"></i></th>
                                        <th class="th-lg">IP<i class="fa fa-sort ml-1"></i></th>
                                        <th class="th-lg">Desde<i class="fa fa-sort ml-1"></i></th>
                                        <th class="th-lg">Hasta<i class="fa fa-sort ml-1"></i></th>
                                    </tr>
                                </thead>
                                <!--Table head-->

                                <!--Table body-->
                                <tbody>
                                <?php global $db;	
										$get_bans = $db->query("SELECT * FROM bans ORDER BY id DESC");
										if($get_bans->num_rows > 0){
											while($row = $get_bans->fetch_array()){
												if($row['bantype'] == 'user'){
													$userdata = $db->query("SELECT * FROM users WHERE username = '".$row['value']."'");
													$users = $userdata->fetch_array();
													$ip_last = $users['ip_last'];
													$ip = 'No';
												}else{
													$ip_last = $row['value'];
													$ip = 'S&iacute;';
												}
												$minuten = $row['expire'] - time();
												if(time() >= $row['expire']){
													$stat = "Expirado";
													$color="green";
												}elseif(time() + 3600 >= $row['expire']){
													if(date('i', $minuten) > 0){
														$stat = "(Le restan ".date('i', $minuten)." minutos)";
														$color="red";
													}else{
														$stat = "(Le restan ".date('s', $minuten)." segundos)";
														$color="red";
													} 
												}else{
													$stat = "Activo";
													$color="red";
												} ?>
                                    <tr>
                                        <th scope="row">
                                            <input type="checkbox" id="<?php echo $row['value']; ?>" onclick="banPreset('<?php echo $row['value']; ?>');">
                                            <label for="<?php echo $row['value']; ?>" class="label-table"></label>
                                        </th>
                                        <td><?php echo $row['value']; ?></td>
                                        <td><b style="color:<?php echo $color; ?>"><?php echo $stat; ?></b></td>
                                        <td><?php echo $row['reason']; ?></td>
                                        <td><?php echo $row['added_by']; ?></td>
                                        <td><?php echo $ip_last; ?></td>
                                        <td><?php setlocale(LC_TIME,"spanish"); echo utf8_encode(strftime("%A %d de %B del %Y", $row['added_date'])); ?></td>
                                        <td><?php setlocale(LC_TIME,"spanish"); echo utf8_encode(strftime("%A %d de %B del %Y", $row['expire'])); ?></td>
                                    </tr>
                                    <?php } } ?>
                                </tbody>
                                <!--Table body-->
                            </table>
                            <!--Table-->
                        </div>

                        <hr class="my-0">

                        <!--Bottom Table UI-->
                        <div class="d-flex justify-content-between">

                            <!--Pagination -->
                            <nav class="my-4">
                                <ul class="pagination pagination-circle pg-blue mb-0">

                                    <!--First-->
                                    <li class="page-item disabled clearfix d-none d-md-block"><a class="page-link">First</a></li>

                                    <!--Arrow left-->
                                    <li class="page-item disabled">
                                        <a class="page-link" aria-label="Previous">
                                        <span aria-hidden="true">&laquo;</span>
                                        <span class="sr-only">Previous</span>
                                    </a>
                                    </li>

                                    <!--Numbers-->
                                    <li class="page-item active"><a class="page-link">1</a></li>
                                    <li class="page-item"><a class="page-link">2</a></li>

                                    <!--Arrow right-->
                                    <li class="page-item">
                                        <a class="page-link" aria-label="Next">
                                            <span aria-hidden="true">&raquo;</span>
                                            <span class="sr-only">Next</span>
                                        </a>
                                    </li>

                                    <!--First-->
                                    <li class="page-item clearfix d-none d-md-block"><a class="page-link">Last</a></li>

                                </ul>
                            </nav>
                            <!--/Pagination -->

                        </div>
                        <!--Bottom Table UI-->

                    </div>
                </div>

            </section>
            <!--Section: Table-->

        </div>
        <!--/.Card-->

    </section>
    <!--Section: Main panel-->


    </div>
</main>
<!--Main layout-->

<?php
   //COLUMNA FOOTER
   $TplClass->AddTemplateHK("templates", "footer");
   ?>
<?php
$hoyMax = time();
$hoyMin = time() - 86400;

$ayerMax = time() - 86400;
$ayerMin = time() - 172800;

$thissMax = time() - 172800;
$thissMin = time() - 604800;

$seanMax = time() - 604800;
$seanMin = time() - 1209600;

$mesMax = time() - 1209600;
$mesMin = time() - 2592000;

$result = $db->query("SELECT * FROM bans WHERE added_date >= '".$hoyMin."' AND added_date <= '".$hoyMax."' ORDER BY added_date");
$result2 = $db->query("SELECT * FROM bans WHERE added_date >= '".$ayerMin."' AND added_date <= '".$ayerMax."' ORDER BY added_date");
$result3 = $db->query("SELECT * FROM bans WHERE added_date >= '".$thissMin."' AND added_date <= '".$thissMax."' ORDER BY added_date");
$result4 = $db->query("SELECT * FROM bans WHERE added_date >= '".$seanMin."' AND added_date <= '".$seanMax."' ORDER BY added_date");
$result5 = $db->query("SELECT * FROM bans WHERE added_date >= '".$mesMin."' AND added_date <= '".$mesMax."' ORDER BY added_date");

?>
<script>
        // Small chart
        $(function () {
            $('.min-chart#chart-sales').easyPieChart({
                barColor: "#FF5252",
                onStep: function (from, to, percent) {
                    $(this.el).find('.percent').text(Math.round(percent));
                }
            });
        });

        //Main chart
        var ctxL = document.getElementById("lineChart").getContext('2d');
        var myLineChart = new Chart(ctxL, {
            type: 'line',
            data: {
                labels: ["Hoy", "Ayer", "Esta semana", "Semana anterior", "Este mes"],
                datasets: [{
                    label: "Baneados",
                    fillColor: "#fff",
                    backgroundColor: 'rgba(255, 255, 255, .3)',
                    borderColor: 'rgba(255, 99, 132)',
                    data: ['<?php echo $result->num_rows; ?>', '<?php echo $result2->num_rows; ?>', '<?php echo $result3->num_rows; ?>', '<?php echo $result4->num_rows; ?>', '<?php echo $result5->num_rows; ?>'],
                }]
            },
            options: {
                legend: {
                    labels: {
                        fontColor: "#fff",
                    }
                },
                scales: {
                    xAxes: [{
                        gridLines: {
                            display: true,
                            color: "rgba(255,255,255,.25)"
                        },
                        ticks: {
                            fontColor: "#fff",
                        },
                    }],
                    yAxes: [{
                        display: true,
                        gridLines: {
                            display: true,
                            color: "rgba(255,255,255,.25)"
                        },
                        ticks: {
                            fontColor: "#fff",
                        },
                    }],
                }
            }
        });
    </script>