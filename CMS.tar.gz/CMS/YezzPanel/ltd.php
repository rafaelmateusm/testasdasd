<?php
   ob_start();
   	require_once '../global.php';
   	$TplClass->SetParam('title', 'Agregar LTD');
   	$TplClass->SetParam('zone', 'Agregar LTD');
    $Functions->LoggedHk("true");
    $Functions->LoggedHkADMIN("true");
          
   	$users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
   	$user = $users->fetch_array();
   	$action = $Functions->FilterText($_GET['action']);
    $id = $Functions->FilterText($_GET['id']);
    $do = $Functions->FilterText($_GET['do']);
   $key = $Functions->FilterText($_GET['key']);
   
   
   	$TplClass->SetAll();
       if( $_SESSION['ERROR_RETURN'] ){
   $TplClass->SetParam('error', '<script>toastr.error(\''.$_SESSION['ERROR_RETURN'].'\');</script>');
   unset($_SESSION['ERROR_RETURN']);
   }
   if( $_SESSION['GOOD_RETURN'] ){
   $TplClass->SetParam('error', '<script>toastr.success(\''.$_SESSION['GOOD_RETURN'].'\');</script>');
   unset($_SESSION['GOOD_RETURN']);
    }
   	$result = $db->query("SELECT * FROM cms_settings WHERE id = 1 LIMIT 1");
   	$data = $result->fetch_array();
   	$SHORTNAME = $data['hotelname'];
   	$FACE = $data['facebook'];
    $LOGO = $data['logo'];
       

   if(isset($_POST['addraro'])){
   $id_furni = $Functions->FilterText($_POST['id_furni']);
   $limited_sells = $Functions->FilterText($_POST['limited_sells']);
   $limited_stack = $Functions->FilterText($_POST['limited_stack']);
   $badge = $Functions->FilterText($_POST['badge']);
   $cost_diamonds = $Functions->FilterText($_POST['cost_diamonds']);
   $page_id = $Functions->FilterText($_POST['page_id']);
   $catalog_name = $Functions->FilterText($_POST['catalog_name']);
if(empty($_POST['id_furni']) || empty($_POST['cost_diamonds'])){
   $_SESSION['ERROR_RETURN'] = "Has dejado campos vac&iacute;os";
   header("LOCATION: ". HK ."LTD");
   }else{
   $db->query("INSERT INTO cms_stafflogs (username, action, message, rank, userid, timestamp) VALUES ('". $user['username'] ."','Agrego un raro LTD', 'Ha agregado el raro ".$id_furni." a ".$cost_diamonds." Diamantes', '". $user['rank'] ."', '". $user['id'] ."', '".date("Y-m-d ")."')");
   $db->query("INSERT INTO catalog_items (page_id, item_id, catalog_name, cost_diamonds, limited_sells, limited_stack, badge) VALUES ('".$page_id."', '".$id_furni."', '".$catalog_name."', '".$cost_diamonds."', '0', '".$limited_stack."', '".$badge."')");
   $_SESSION['GOOD_RETURN'] = "Placa agregada correctamente";
   header("LOCATION: ". HK ."LTD");
   }
   }


   if($_POST['editraro']){
   if(isset($_POST['id_furni']) && isset($_POST['cost_diamonds'])){
            $id_furni = $Functions->FilterText($_POST['id_furni']);
            $limited_sells = $Functions->FilterText($_POST['limited_sells']);
            $limited_stack = $Functions->FilterText($_POST['limited_stack']);
            $badge = $Functions->FilterText($_POST['badge']);
            $cost_diamonds = $Functions->FilterText($_POST['cost_diamonds']);
            $page_id = $Functions->FilterText($_POST['page_id']);
            $catalog_name = $Functions->FilterText($_POST['catalog_name']);
   if(empty($_POST['id_furni']) || empty($_POST['cost_diamonds'])){
   	$_SESSION['ERROR_RETURN'] = "Has dejado campos vac&iacute;os";
   	header("LOCATION: ". HK ."LTD");
   }else{
   	$db->query("UPDATE catalog_items SET page_id = '{$page_id}', item_id = '{$catalog_name}', item_id = '{$id_furni}', limited_sells = '{$limited_sells}', limited_stack = '{$limited_stack}', cost_diamonds = '{$cost_diamonds}', badge = '{$badge}' WHERE id = '{$id}' LIMIT 1");	
   	$db->query("INSERT INTO cms_stafflogs (username, action, message, rank, userid, timestamp) VALUES ('". $user['username'] ."','Edito un raro LTD', 'Ha editado un raro LTD', '". $user['rank'] ."', '". $user['id'] ."', '".date("Y-m-d ")."')");
   	$_SESSION['GOOD_RETURN'] = "Placa editada correctamente";
   	header("LOCATION: ". HK ."LTD");	
   }				
   }
   }

   if($do == "dele" && !empty($key)){
   $db->query("INSERT INTO cms_stafflogs (username, action, message, rank, userid, timestamp) VALUES ('". $user['username'] ."','Borro un Raro LTD', 'Ha retirado un raro de la tienda', '". $user['rank'] ."', '". $user['id'] ."', '".date("Y-m-d ")."')");
   $db->query("UPDATE catalog_items SET page_id = '423423559' WHERE id = '{$key}' LIMIT 1");	
   $_SESSION['GOOD_RETURN'] = "Raro removido correctamente";
   header("LOCATION: ". HK ."LTD");					
   }
   
   	$TplClass->AddTemplateHK("templates", "menu");
   	ob_end_flush(); 
   ?>
<!--Main layout-->
<main>
   <div class="container-fluid">
      <div style="height: 5px"></div>
      <?php global $db;
         if($action == "edit" && !empty($id)){ 
         $hj = $db->query("SELECT * FROM catalog_items WHERE id = '". $id ."'");
         $h_edit = $hj->fetch_array();		

         $disponiblessells = '';
         $disponiblesstack = $h_edit['limited_stack'] - $h_edit['limited_sells'];
         $disponiblestotal = $disponiblesstack;
         ?>
      <section class="mb-5" style="width:50%;float:right;margin-right:-85px;">
         <!--Card-->
         <div class="card card-cascade narrower">
            <!--Section: Table-->
            <br>
            <div class="table-ui p-2 mb-3 mx-4 mb-5">
               <div class="view gradient-card-header light-blue lighten-1">
                  <h2 class="h2-responsive mb-0">Editar raro LTD</h2>
               </div>
               <form action="" method="post">
                  <p class="text-light margin-bottom-20">Rellena todos los campos para editar un raro LTD</p>
                  <center>
                     <p class="lead"><span class="badge info-color p-2">Página sección</span></p>
                  </center>
                  <div class="md-form">
                 <select class="mdb-select colorful-select dropdown-info mx-2" name="page_id" style="width:513%;">
                     <option value="" disabled>Pagina</option>
                     <?php if($h_edit['page_id'] == '16'){
                             $selected = 'selected';
                            }else{
                                $selected = '';}

                                if($h_edit['page_id'] == '3255231'){
                                    $selected2 = 'selected';
                                   }else{
                                       $selected2 = '';}

                                       if($h_edit['page_id'] == '7857850'){
                                        $selected3 = 'selected';
                                       }else{
                                           $selected3 = '';}
                             ?>
                     <option value="16" <?php echo $selected; ?>>LTD Semanal</option>
                     <option value="3255231" <?php echo $selected2; ?>>LTD Mensual</option>
                     <option value="7857850" <?php echo $selected3; ?>>LTD Agotado</option>
                  </select>

                     <!--Password validation-->
                     
                         
                     </div>

                     <center>
                     <p class="lead"><span class="badge info-color p-2">Explicación mínima del furni </span></p>
                  </center>
                  <input type="text" class="form-control" id="input-text" name="catalog_name" placeholder="Titulo" value="<?php echo $h_edit['catalog_name']; ?>" style="width:100%;">

                  <center>
                  <p class="lead"><span class="badge info-color p-2">ID del Furni <a href="<?php echo HK ?>furniture.php" target="_blank">(ID EN FURNITURE) CLICK AQUÍ PARA LOS IDS</a> </span></p>
                  </center>
                  <input type="number" class="form-control" id="input-text" name="id_furni" placeholder="ID del furni" value="<?php echo $h_edit['item_id']; ?>" style="width:100%;">
                  <div class="row">
                     <!--Grid column-->
                     <div class="col-md-6 mb-r">
                        <p class="lead"><span class="badge info-color p-2">Actualmente hay: <?php echo $disponiblestotal; ?><br> copias disponibles</span></p>
                        <div class="md-form">
                           <input type="number" id="form6" class="form-control" value="<?php echo $h_edit['limited_stack']; ?>" name="limited_stack">
                           <label class="active" for="form6">Limite:</label>
                        </div>
                     </div>
                     <!--Grid column-->
                     <!--Grid column-->
                     <div class="col-md-6 mb-r">
                        <p class="lead"><span class="badge info-color p-2">Precio</span></p>
                        <div class="md-form">
                           <input type="number" id="form11" class="form-control" value="<?php echo $h_edit['cost_diamonds']; ?>" name="cost_diamonds">
                           <label for="form11" class="active">Precio en diamantes</label>
                        </div>
                     </div>
                     <!--Grid column-->
                  </div>

                  <div class="row">
                     <!--Grid column-->
                     <div class="col-md-6 mb-r">
                        <p class="lead"><span class="badge info-color p-2">Copias vendidas</span></p>
                        <div class="md-form">
                           <input type="number" id="form6" class="form-control" value="<?php echo $h_edit['limited_sells']; ?>" name="limited_sells">
                           <label class="active" for="form6">Copias vendidas:</label>
                        </div>
                     </div>
                     <!--Grid column-->
                     <!--Grid column-->
                     <div class="col-md-6 mb-r">
                        <p class="lead"><span class="badge info-color p-2">Placa</span></p>
                        <div class="md-form">
                           <input type="text" id="form11" class="form-control" value="<?php echo $h_edit['badge']; ?>" name="badge">
                           <label for="form11" class="active">Placa</label>
                        </div>
                     </div>
                     <!--Grid column-->
                  </div>
                  <center><input name="editraro" type="submit" class="btn btn-dark bg-blue-grey-800 color-white margin-left-10" value="Enviar"></center>
               </form>
               <!--Grid column-->
               <!--Grid row-->
            </div>
         </div>
      </section>
      <?php }else{ ?>
      <section class="mb-5" style="width:50%;float:right;margin-right:-85px;">
         <!--Card-->
         <div class="card card-cascade narrower">
            <!--Section: Table-->
            <br>
            <div class="table-ui p-2 mb-3 mx-4 mb-5">
               <div class="view gradient-card-header light-blue lighten-1">
                  <h2 class="h2-responsive mb-0">Agregar un raro LTD</h2>
               </div>
               <form action="" method="post">
                  <p class="text-light margin-bottom-20">Rellena todos los campos para agregar un raro LTD</p>

                  <center>
                     <p class="lead"><span class="badge info-color p-2">Página sección</span></p>
                  </center>
                  <div class="md-form">
                 <select class="mdb-select colorful-select dropdown-info mx-2" name="page_id" style="width:513%;">
                     <option value="" disabled>Pagina</option>
                     <option value="16" selected>LTD Semanal</option>
                     <option value="3255231">LTD Mensual</option>
                     <option value="7857850">LTD Agotado</option>
                  </select>

                     <!--Password validation-->
                     
                         
                     </div>

                     <center>
                     <p class="lead"><span class="badge info-color p-2">Explicación mínima del furni </span></p>
                  </center>
                  <input type="text" class="form-control" id="input-text" name="catalog_name" placeholder="Titulo" value="" style="width:100%;">

                  <center>
                     <p class="lead"><span class="badge info-color p-2">ID del Furni <a href="<?php echo HK ?>furniture.php" target="_blank">(ID EN FURNITURE) CLICK AQUÍ PARA LOS IDS</a> </span></p>
                  </center>
                  <input type="number" class="form-control" id="input-text" name="id_furni" placeholder="Id del Furni" value="" style="width:100%;">
                  <div class="row">
                     <!--Grid column-->
                     <div class="col-md-6 mb-r">
                        <p class="lead"><span class="badge info-color p-2">Limite</span></p>
                        <div class="md-form">
                           <input type="number" id="form6" class="form-control" value="100" name="limited_stack">
                           <label class="active" for="form6">¿Cuántas copias disponibles?</label>
                        </div>
                     </div>
                     <!--Grid column-->
                     <!--Grid column-->
                     <div class="col-md-6 mb-r">
                        <p class="lead"><span class="badge info-color p-2">Precio</span></p>
                        <div class="md-form">
                           <input type="number" id="form11" class="form-control" value="" name="cost_diamonds">
                           <label for="form11" class="active">Precio en diamantes</label>
                        </div>
                     </div>
                     <!--Grid column-->
                  </div>
                  <center>
                     <p class="lead"><span class="badge info-color p-2">Rellenar este campo solo si se pondrá una placa, en caso de que se<br> ponga una placa, Deberás poner el code de la placa  </span></p>
                  </center>                 
                  
                  <input type="text" class="form-control" id="input-text" name="badge" placeholder="Placa" value="" style="width:100%;">

                  <center><input name="addraro" type="submit" class="btn btn-dark bg-blue-grey-800 color-white margin-left-10" value="Enviar"></center>
               </form>
               <!--Grid column-->
               <!--Grid row-->
            </div>
         </div>
      </section>
      <?php } ?>
      <section class="section team-section" style="width:64%;margin-left:-80px;margin-top:22px;">

                <!-- First row -->
                <div class="row">
                    <!-- First column -->
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-12 mb-1">
                                <!-- Tabs -->
                                <!-- Nav tabs -->
                                <div class="tabs-wrapper">
                                    <ul class="nav classic-tabs tabs-primary primary-color" role="tablist">

                                        <li class="nav-item">
                                            <a class="nav-link waves-light waves-effect waves-light active" data-toggle="tab" href="#panel83" role="tab" aria-selected="true">LTD Agotados</a>
                                        </li>

                                        <li class="nav-item">
                                            <a class="nav-link waves-light waves-effect waves-light" data-toggle="tab" href="#panel84" role="tab" aria-selected="false">LTD Mensual</a>
                                        </li>

                                        <li class="nav-item">
                                            <a class="nav-link waves-light waves-effect waves-light" data-toggle="tab" href="#panel85" role="tab" aria-selected="false">LTD Semanales</a>
                                        </li>

                                    </ul>
                                </div>
                                <!-- Tab panels -->
                                <div class="tab-content card">
                                    <!--Panel 1-->
                                    <div class="tab-pane fade active show" id="panel83" role="tabpanel">
                                        <div class="table-responsive">
                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th>Ico</th>
                                                        <th>Public name</th>
                                                        <th>Category</th>
                                                        <th>Price</th>
                                                        <th>Faltante</th>
                                                    </tr>
                                                </thead>


                                                <tbody>



                                                <?php $result = $db->query("SELECT * FROM catalog_items WHERE page_id = '7857850' ORDER BY id DESC");
                                                while($data = $result->fetch_array()){ 
                                                   $result2 = $db->query("SELECT * FROM furniture WHERE id = '".$data['item_id']."' ORDER BY id DESC");
                                                   while($furniture = $result2->fetch_array()){ 
                                                    
                                                    ?> 
                                                <tr>
                                                                       <th scope="row"><img draggable="false" oncontextmenu="return false" src="<?php echo PATH ?>/game/dcr/hof_furni/icon/<?php echo $furniture['item_name'] ?>_icon.png"></th>
                                                                       <td><?php echo $data['catalog_name'] ?></td>
                                                                       <td>Agotados</td>
                                                                       <td><?php echo $data['cost_diamonds'] ?></td>
                                                                       <td><?php echo $data['limited_sells'] ?> / <?php echo $data['limited_stack'] ?></td>
                                                                       <td>
                                                                           <a href="<?php echo HK ?>LTD?action=edit&id=<?php echo $data['id']; ?>" class="teal-text" data-toggle="tooltip" data-placement="top" title="Edit"><i class="fa fa-pencil"></i></a>
                                                                           <a href="<?php echo HK ?>LTD?do=dele&key=<?php echo $data['id']; ?>" class="red-text" data-toggle="tooltip" data-placement="top" title="Remove"><i class="fa fa-times"></i></a>
                                                                       </td>
                                                </tr>
                                                <?php }} ?> 



                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <!--/.Panel 1-->
                                    <!--Panel 2-->
                                    <div class="tab-pane fade" id="panel84" role="tabpanel">
                                        <div class="table-responsive">
                                            <table class="table">

                                                <thead>
                                                    <tr>
                                                    <th>Ico</th>
                                                    <th>Public name</th>
                                                    <th>Category</th>
                                                    <th>Price</th>
                                                    <th>Faltante</th>
                                                    </tr>
                                                </thead>

                                                <tbody>
                                                    
                                                <?php $result = $db->query("SELECT * FROM catalog_items WHERE page_id = '3255231' ORDER BY id DESC");
                                                    while($data = $result->fetch_array()){ 
                                                       $result2 = $db->query("SELECT * FROM furniture WHERE id = '".$data['item_id']."' ORDER BY id DESC");
                                                       while($furniture = $result2->fetch_array()){ 
                                                        
                                                        ?> 
                                                    <tr>
                                                                           <th scope="row"><img draggable="false" oncontextmenu="return false" src="<?php echo PATH ?>/game/dcr/hof_furni/icon/<?php echo $furniture['item_name'] ?>_icon.png"></th>
                                                                           <td><?php echo $data['catalog_name'] ?></td>
                                                                           <td>Mensual</td>
                                                                           <td><?php echo $data['cost_diamonds'] ?></td>
                                                                           <td><?php echo $data['limited_sells'] ?> / <?php echo $data['limited_stack'] ?></td>
                                                                           <td>
                                                                               <a href="<?php echo HK ?>LTD?action=edit&id=<?php echo $data['id']; ?>" class="teal-text" data-toggle="tooltip" data-placement="top" title="Edit"><i class="fa fa-pencil"></i></a>
                                                                               <a href="<?php echo HK ?>LTD?do=dele&key=<?php echo $data['id']; ?>" class="red-text" data-toggle="tooltip" data-placement="top" title="Remove"><i class="fa fa-times"></i></a>
                                                                           </td>
                                                    </tr>
                                                    <?php }} ?> 

                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <!--/.Panel 2-->


                                    <div class="tab-pane fade" id="panel85" role="tabpanel">
                                        <div class="table-responsive">
                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                    <th>Ico</th>
                                                    <th>Public name</th>
                                                    <th>Category</th>
                                                    <th>Price</th>
                                                    <th>Faltante</th>
                                                    </tr>
                                                </thead>


                                                <tbody>


                                                <?php $result = $db->query("SELECT * FROM catalog_items WHERE page_id = '16' ORDER BY id DESC");
                                 while($data = $result->fetch_array()){ 
                                    $result2 = $db->query("SELECT * FROM furniture WHERE id = '".$data['item_id']."' ORDER BY id DESC");
                                    while($furniture = $result2->fetch_array()){ 
                                     
                                     ?> 
                                                    <tr>
                                                        <th scope="row"><img draggable="false" oncontextmenu="return false" src="<?php echo PATH ?>/game/dcr/hof_furni/icon/<?php echo $furniture['item_name'] ?>_icon.png"></th>
                                                        <td><?php echo $data['catalog_name'] ?></td>
                                                        <td>Semanales</td>
                                                        <td><?php echo $data['cost_diamonds'] ?></td>
                                                        <td><?php echo $data['limited_sells'] ?> / <?php echo $data['limited_stack'] ?></td>
                                                        <td>
                                                            <a href="<?php echo HK ?>LTD?action=edit&id=<?php echo $data['id']; ?>" class="teal-text" data-toggle="tooltip" data-placement="top" title="Edit"><i class="fa fa-pencil"></i></a>
                                                            <a href="<?php echo HK ?>LTD?do=dele&key=<?php echo $data['id']; ?>" class="red-text" data-toggle="tooltip" data-placement="top" title="Remove"><i class="fa fa-times"></i></a>
                                                        </td>
                                                    </tr>
                                                    <?php }} ?> 


                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <!-- /.Tabs -->
                            </div>
                        </div>
                    </div>
                    <!-- /.First column -->
                </div>
                <!-- /.Second column -->
        </section>
      <!--Section: Table-->

   </div>
</main>
<!--Main layout-->

<?php
   //COLUMNA FOOTER
   $TplClass->AddTemplateHK("templates", "footer");
   ?>      <script data-cfasync="false" src="/app/assets/js/jquery.shop.js" charset="utf-8"></script>