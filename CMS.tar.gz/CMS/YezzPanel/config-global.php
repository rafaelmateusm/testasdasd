<?php
ob_start();
	require_once '../global.php';
	$TplClass->SetParam('title', 'Configuraci&oacute;n del Hotel');
	$TplClass->SetParam('zone', 'Configuraci&oacute;n del Hotel');
	$Functions->LoggedHk("true");
	$Functions->LoggedHkADMIN("true");
	
	$users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
	$user = $users->fetch_array();

	$TplClass->SetAll();
	if( $_SESSION['ERROR_RETURN'] ){
		$TplClass->SetParam('error', '<script>toastr.error(\''.$_SESSION['ERROR_RETURN'].'\');</script>');
		unset($_SESSION['ERROR_RETURN']);
	}
	if( $_SESSION['GOOD_RETURN'] ){
		$TplClass->SetParam('error', '<script>toastr.success(\''.$_SESSION['GOOD_RETURN'].'\');</script>');
		unset($_SESSION['GOOD_RETURN']);
    }
    
//HOTEL CONFIG
$result2 = $db->query("SELECT * FROM cms_settings WHERE id = 1 LIMIT 1");
$yezz = $result2->fetch_array();
//END HOTEL CONFIG

	
	if(isset($_POST['gconfig'])){
		$db->query("UPDATE cms_settings SET hotelname = '". $Functions->FilterText($_POST['hotelname']) ."', facebook = '". $Functions->FilterText($_POST['fb']) ."', logo = '". $Functions->FilterText($_POST['logo']) ."', host = '". $Functions->FilterText($_POST['host']) ."', port = '". $Functions->FilterText($_POST['port']) ."', external_variables = '". $Functions->FilterText($_POST['extvar']) ."', external_texts = '". $Functions->FilterText($_POST['exttext']) ."', productdata = '". $Functions->FilterText($_POST['prod']) ."', furnidata = '". $Functions->FilterText($_POST['furn']) ."', figuredata = '". $Functions->FilterText($_POST['figuredata']) ."', figuremap = '". $Functions->FilterText($_POST['figuremap']) ."', external_Texts_Override = '". $Functions->FilterText($_POST['external_Texts_Override']) ."', external_Variables_Override = '". $Functions->FilterText($_POST['external_Variables_Override']) ."', flash_client_url = '". $Functions->FilterText($_POST['flash']) ."', habbo_swf = '". $Functions->FilterText($_POST['habboswf']) ."', id_paygol = '". $Functions->FilterText($_POST['pay']) ."', twitter = '". $Functions->FilterText($_POST['tw']) ."' WHERE id = '1'");
		$db->query("INSERT INTO cms_stafflogs (username, action, message, rank, userid, timestamp) VALUES ('". $user['username'] ."','Configuraci&oacute;n global del Hotel', 'Ha Actualizado la Configuraci&oacute;n global del Hotel', '". $user['rank'] ."', '". $user['id'] ."', '".date("Y-m-d ")."')");
		$_SESSION['GOOD_RETURN'] = "La Configuraci&oacute;n global ha sido Actualizada Correctamente";
		header("LOCATION: ". HK ."config-hotel");
    }
    
   /* if(isset($_POST['Reinicio_emulador'])){
        $totix->Mus('reinicio_remoto');
        $_SESSION['GOOD_RETURN'] = "Acabas de reiniciar Yezz Server";
        header("LOCATION: ". HK ."config-hotel");

     }*/
	 
	
	if(isset($_POST['REG'])){
		if($yezz['registros'] == 1){
			$var = 0;
		}else{$var = 1;}
		$action = $db->query("UPDATE cms_settings SET registros = '{$var}' WHERE id = '1' LIMIT 1");
		$db->query("INSERT INTO cms_stafflogs (username, action, message, rank, userid, timestamp) VALUES ('". $user['username'] ."','Configuraci&oacute;n global del Hotel', 'Ha Cambiado la configuraci&oacute;n de los Reg&iacute;stros', '". $user['rank'] ."', '". $user['id'] ."', '".date("Y-m-d ")."')");
		if($action){
			$_SESSION['GOOD_RETURN'] = "Registros modificados Correctamente";
			header("LOCATION: ". HK ."config-hotel");
		}else{
			$_SESSION['ERROR_RETURN'] = "Ha ocurrido un error indeterminado";
			header("LOCATION: ". HK ."config-hotel");
		}
	}
	if(isset($_POST['MOD'])){
		if($yezz['reg_mod'] == 1){
			$var = 0;
		}else{$var = 1;}
		$action = $db->query("UPDATE cms_settings SET reg_mod = '{$var}' WHERE id = '1' LIMIT 1");
		$db->query("INSERT INTO cms_stafflogs (username, action, message, rank, userid, timestamp) VALUES ('". $user['username'] ."','Configuraci&oacute;n global del Hotel', 'Ha Cambiado la configuraci&oacute;n de los Reg&iacute;stros con Prefijo MOD', '". $user['rank'] ."', '". $user['id'] ."', '".date("Y-m-d ")."')");
		if($action){
			$_SESSION['GOOD_RETURN'] = "Registros con Prefijo MOD modificados Correctamente";
			header("LOCATION: ". HK ."config-hotel");
		}else{
			$_SESSION['ERROR_RETURN'] = "Ha ocurrido un error indeterminado";
			header("LOCATION: ". HK ."config-hotel");
		}
	}
	if(isset($_POST['IP'])){
		if($yezz['reg_ip'] == 1){
			$var = 0;
		}else{$var = 1;}
		$action = $db->query("UPDATE cms_settings SET reg_ip = '{$var}' WHERE id = '1' LIMIT 1");
		$db->query("INSERT INTO cms_stafflogs (username, action, message, rank, userid, timestamp) VALUES ('". $user['username'] ."','Configuraci&oacute;n global del Hotel', 'Ha Cambiado la configuraci&oacute;n de los Reg&iacute;stros por IP', '". $user['rank'] ."', '". $user['id'] ."', '".date("Y-m-d ")."')");
		if($action){
			$_SESSION['GOOD_RETURN'] = "Registros por IP modificados Correctamente";
			header("LOCATION: ". HK ."config-hotel");
		}else{
			$_SESSION['ERROR_RETURN'] = "Ha ocurrido un error indeterminado";
			header("LOCATION: ". HK ."config-hotel");
		}
	}
	if(isset($_POST['MANT'])){
		if($yezz['mantenimiento'] == 1){
			$var = 0;
		}else{$var = 1;}
		$action = $db->query("UPDATE cms_settings SET mantenimiento = '{$var}' WHERE id = '1' LIMIT 1");
		$db->query("INSERT INTO cms_stafflogs (username, action, message, rank, userid, timestamp) VALUES ('". $user['username'] ."','Configuraci&oacute;n global del Hotel', 'Ha puesto un Mantenimiento', '". $user['rank'] ."', '". $user['id'] ."', '".date("Y-m-d ")."')");
		if($action){
			$_SESSION['GOOD_RETURN'] = "Mantenimiento modificado Correctamente";
			header("LOCATION: ". HK ."config-hotel");
		}else{
			$_SESSION['ERROR_RETURN'] = "Ha ocurrido un error indeterminado";
			header("LOCATION: ". HK ."config-hotel");
		}
    }
    
	$TplClass->AddTemplateHK("templates", "menu");
	ob_end_flush(); 
?>

	 <?php
 
if(isset($_POST['Reinicio_emulador'])){

   $totix->Mus('reinicio_remoto');
}
?>


 <!--Main layout-->
 <main>
 <br> <br>
      <div class="row">

                    <!--Grid column-->
                    <div class="col-lg-5 mb-4">

                        <!--Form with header-->
                        <div class="card" style="width:110%;">

                            <div class="card-body">
                                <!--Header-->
                                <div class="form-header blue accent-1">
                                    <h3><i class="fa fa-cogs"></i> Configuraci&oacute;n del Hotel</h3>
                                </div>

                                <p>Edita los datos de tu Hotel</p>
                                <br>
                                <form action="" method="post">
                                <div class="md-form">
                                <h4>Reg&iacute;stros
									<?php if($yezz['registros'] == 1){ echo '<input type="submit" name="REG" class="btn btn-danger waves-effect waves-light" style="margin-left: 185px;" value="Desactivar" />';}else{ echo '<input type="submit" name="REG" class="btn btn-success waves-effect waves-light" style="margin-left: 210px;" value="Activar" />';} ?>
                                    </h4></div>
								<div class="form-group">
                                <h4>Reg&iacute;stros con Prefijo MOD
									<?php if($yezz['reg_mod'] == 1){ echo '<input type="submit" name="MOD" class="btn btn-danger waves-effect waves-light" style="margin-left: 5px;" value="Desactivar" />';}else{ echo '<input type="submit" name="MOD" class="btn btn-success waves-effect waves-light" style="margin-left: 30px;" value="Activar" />';} ?>
                                    </h4></div>
								<div class="form-group">
                                <h4>Reg&iacute;stros con la misma IP
									<?php if($yezz['reg_ip'] == 1){ echo '<input type="submit" name="IP" class="btn btn-danger waves-effect waves-light" style="margin-left: 5px;" value="Desactivar" />';}else{ echo '<input type="submit" name="IP" class="btn btn-success waves-effect waves-light" style="margin-left: 30px;" value="Activar" />';} ?>
                                    </h4></div>
								<div class="form-group">
                                <h4>Mantenimiento
									<?php if($yezz['mantenimiento'] == 1){ echo '<input type="submit" name="MANT" class="btn btn-danger waves-effect waves-light" style="margin-left: 120px;" value="Desactivar" />';}else{ echo '<input type="submit" name="MANT" class="btn btn-success waves-effect waves-light" style="margin-left: 148px;" value="Activar" />';} ?>
                                    </h4></div>

                                    <div class="form-group">
                                <h4>Reiniciar Emulador
									<input type="submit" name="Reinicio_emulador" class="btn btn-danger waves-effect waves-light" style="margin-left: 105px;" value="Reiniciar" />
                                    </h4></div>



                                <!--Body-->
                                <div class="md-form">
                                    <i class="fa fa-heart prefix grey-text"></i>
                                    <input type="text" class="form-control" name="hotelname" value="<?php echo $yezz['hotelname']; ?>">
                                </div>

                                <div class="md-form">
                                    <i class="fa fa-facebook-official prefix grey-text"></i>
                                    <input type="text" class="form-control" placeholder="Facebook del Hotel" name="fb" value="<?php echo $yezz['facebook']; ?>">
                                </div>

                                <div class="md-form">
                                    <i class="fa fa-twitter prefix grey-text"></i>
                                    <input type="text" class="form-control" placeholder="Twitter del Hotel" name="tw" value="<?php echo $yezz['twitter']; ?>">
                                </div>


                                <div class="md-form">
                                    <i class="fa fa-tag prefix grey-text"></i>
                                    <input type="text" class="form-control" placeholder="Logo del Hotel" name="logo" value="<?php echo $yezz['logo']; ?>">
                                </div>

                                <div class="md-form">
                                    <i class="fa fa-tag prefix grey-text"></i>
                                    <input type="text" class="form-control" placeholder="ID de tu Servicio PayGol" name="pay" value="<?php echo $yezz['id_paygol']; ?>">
                                </div>

                                <div class="md-form">
                                    <i class="fa fa-tag prefix grey-text"></i>
                                    <input type="text" class="form-control" placeholder="Host" name="host" value="<?php echo $yezz['host']; ?>">
                                </div>

                                <div class="md-form">
                                    <i class="fa fa-tag prefix grey-text"></i>
                                    <input type="text" class="form-control" placeholder="Puerto del Client" name="port" value="<?php echo $yezz['port']; ?>">
                                </div>

                                <div class="md-form">
                                    <i class="fa fa-tag prefix grey-text"></i>
                                    <input type="text" class="form-control" placeholder="External Variables" name="extvar" value="<?php echo $yezz['external_variables']; ?>">
                                </div>

                                <div class="md-form">
                                    <i class="fa fa-tag prefix grey-text"></i>
                                    <input type="text" class="form-control" placeholder="External Texts" name="exttext" value="<?php echo $yezz['external_texts']; ?>">
                                </div>

                                <div class="md-form">
                                    <i class="fa fa-tag prefix grey-text"></i>
                                    <input type="text" class="form-control" placeholder="Productdata" name="prod" value="<?php echo $yezz['productdata']; ?>">
                                </div>

                                <div class="md-form">
                                    <i class="fa fa-tag prefix grey-text"></i>
                                    <input type="text" class="form-control" placeholder="Furnidata" name="furn" value="<?php echo $yezz['furnidata']; ?>">
                                </div>

                                <div class="md-form">
                                    <i class="fa fa-tag prefix grey-text"></i>
                                    <input type="text" class="form-control" placeholder="Flash Client" name="flash" value="<?php echo $yezz['flash_client_url']; ?>">
                                </div>

                                <div class="md-form">
                                    <i class="fa fa-tag prefix grey-text"></i>
                                    <input type="text" class="form-control" placeholder="Habbo.SWF" name="habboswf" value="<?php echo $yezz['habbo_swf']; ?>">
                                </div>

                                <div class="md-form">
                                    <i class="fa fa-tag prefix grey-text"></i>
                                    <input type="text" class="form-control" placeholder="figuredata" name="figuredata" value="<?php echo $yezz['figuredata']; ?>">
                                </div>

                                <div class="md-form">
                                    <i class="fa fa-tag prefix grey-text"></i>
                                    <input type="text" class="form-control" placeholder="figuremap" name="figuremap" value="<?php echo $yezz['figuremap']; ?>">
                                </div>

                                <div class="md-form">
                                    <i class="fa fa-tag prefix grey-text"></i>
                                    <input type="text" class="form-control" placeholder="external_Texts_Override" name="external_Texts_Override" value="<?php echo $yezz['external_Texts_Override']; ?>">
                                </div>

                                <div class="md-form">
                                    <i class="fa fa-tag prefix grey-text"></i>
                                    <input type="text" class="form-control" placeholder="external_Variables_Override" name="external_Variables_Override" value="<?php echo $yezz['external_Variables_Override']; ?>">
                                </div>


                                <div class="text-center">
                                    <button name="gconfig" class="btn btn-light-blue">Guardar cambio</button>
                                </div>
                                </form>
                            </div>

                        </div>
                        <!--Form with header-->

                    </div>
                    <!--Grid column-->

                    <!--Grid column-->
                    <div class="col-lg-7">

                        <!--Google map-->
                        <script>(function(d, s, id) {
                     var js, fjs = d.getElementsByTagName(s)[0];
                     if (d.getElementById(id)) return;
                     js = d.createElement(s); js.id = id;
                     js.src = 'https://connect.facebook.net/es_ES/sdk.js#xfbml=1&version=v2.11';
                     fjs.parentNode.insertBefore(js, fjs);
                     }(document, 'script', 'facebook-jssdk'));
                  </script>
                        <div class="z-depth-1-half map-container" style="width:75%;margin-left:80px;">
                        <div class="fb-page" data-width="800" data-href="<?php echo $yezz['facebook']; ?>" data-tabs="timeline" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true">
                           <blockquote cite="<?php echo $yezz['facebook']; ?>" class="fb-xfbml-parse-ignore"><a href="<?php echo $yezz['facebook']; ?>">Familia <?php echo $yezz['hotelname']; ?></a></blockquote>
                        </div>                       
                        </div>

                        
                    </div>
                    <!--Grid column-->

                </div>



</main>
<!--Main layout-->

   <?php
   //COLUMNA FOOTER
   $TplClass->AddTemplateHK("templates", "footer");
   ?>
