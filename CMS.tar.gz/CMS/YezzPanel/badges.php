<?php
   ob_start();
   	require_once '../global.php';
   	$TplClass->SetParam('title', 'Gesti&oacute;n de placas');
   	$TplClass->SetParam('zone', 'Gesti&oacute;n de placas');
   	$Functions->LoggedHk("true");
   	
   	$users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
   	$user = $users->fetch_array();
   	$action = $Functions->FilterText($_GET['action']);
    $id = $Functions->FilterText($_GET['id']);

   
   	$TplClass->SetAll();
       if( $_SESSION['ERROR_RETURN'] ){
		$TplClass->SetParam('error', '<script>toastr.error(\''.$_SESSION['ERROR_RETURN'].'\');</script>');
		unset($_SESSION['ERROR_RETURN']);
	}
	if( $_SESSION['GOOD_RETURN'] ){
		$TplClass->SetParam('error', '<script>toastr.success(\''.$_SESSION['GOOD_RETURN'].'\');</script>');
		unset($_SESSION['GOOD_RETURN']);
    }
   	$result = $db->query("SELECT * FROM cms_settings WHERE id = 1 LIMIT 1");
   	$data = $result->fetch_array();
   	$SHORTNAME = $data['hotelname'];
   	$FACE = $data['facebook'];
       $LOGO = $data['logo'];
       
       if(isset($_POST['givebadge'])){
		$check = $db->query("SELECT * FROM users WHERE username = '".$Functions->FilterText($_POST['name'])."' LIMIT 1");
		$row = $check->fetch_array();
		$repeat = $db->query("SELECT * FROM user_badges WHERE user_id = '". $row['id'] ."' && badge_id = '".$Functions->FilterText($_POST['badge'])."' LIMIT 1");
		if(empty($_POST['name']) || empty($_POST['badge'])){
			$_SESSION['ERROR_RETURN'] = "Has dejado campos vac&iacute;os";
			header("LOCATION: ". HK ."management-badges");
		}elseif($repeat->num_rows > 0){
			$_SESSION['ERROR_RETURN'] = "El Usuario ya cuenta con la Placa";
			header("LOCATION: ". HK ."management-badges");
		}else{
			if($check->num_rows > 0){
				$db->query("INSERT INTO cms_stafflogs (username, action, message, rank, userid, timestamp) VALUES ('". $user['username'] ."','Dar Placa', 'Le ha dado la placa ".$Functions->FilterText($_POST['badge'])." a ".$Functions->FilterText($_POST['name'])."', '". $user['rank'] ."', '". $user['id'] ."', '".date("Y-m-d ")."')");
				$db->query("INSERT INTO user_badges (user_id, badge_id) VALUES ('". $row['id'] ."', '{$Functions->FilterText($_POST['badge'])}')");
				$_SESSION['GOOD_RETURN'] = "Placa entregada correctamente";
				header("LOCATION: ". HK ."management-badges");
			}else {
				$_SESSION['ERROR_RETURN'] = "El usuario no ex&iacute;ste";
				header("LOCATION: ". HK ."management-badges");
			}
		}
	}
	if(isset($_POST['nameq'])){ 
		$buscar = $Functions->FilterText($_POST['nameq']);
		$db->query("INSERT INTO cms_stafflogs (username, action, message, rank, userid, timestamp) VALUES ('". $user['username'] ."','Quitar Placas', 'Ha escaneado a ".$buscar."', '". $user['rank'] ."', '". $user['id'] ."', '".date("Y-m-d ")."')");
		if(empty($buscar)){
			$_SESSION['ERROR_RETURN'] = "Debes insertar un nombre de usuario";
				header("LOCATION: ". HK ."management-badges");
		}
	}
	if(isset($_POST['delebadge'])){
        $delebadge = $Functions->FilterText($_POST['delebadge']);

		$buscar = $Functions->FilterText($_POST['nameq']);
		$db->query("INSERT INTO cms_stafflogs (username, action, message, rank, userid, timestamp) VALUES ('". $user['username'] ."','Quitar Placas', 'Le ha retirado una placa a ".$buscar."', '". $user['rank'] ."', '". $user['id'] ."', '".date("Y-m-d ")."')");
		$db->query("DELETE FROM user_badges WHERE id = '{$delebadge}' LIMIT 1");
        $_SESSION['GOOD_RETURN'] = "Placa retirada correctamente";
        header("LOCATION: ". HK ."management-badges");
        
	}
   	$TplClass->AddTemplateHK("templates", "menu");
   	ob_end_flush(); 
   ?>

<!--Main layout-->
<main>
<div class="container-fluid">

    <div style="height: 5px"></div>




    <section class="mb-5" style="width:50%;float:right;">
        <!--Card-->
        <div class="card card-cascade narrower">


            <!--Section: Table-->
<br>
            <div class="table-ui p-2 mb-3 mx-4 mb-5">
            <div class="view gradient-card-header light-blue lighten-1">
                            <h2 class="h2-responsive mb-0">Dar placa</h2>
                        </div>
                            <!--Grid row-->

                                                           <!--Grid column-->
                                <form action="" method="post">
								<p class="text-light margin-bottom-20">Rellena todos los campos para dar una Placa</p>
                                <center><p class="lead"><span class="badge info-color p-2">Ususario</span></p></center>

                                <div class="col-md-6">
									<input type="text" class="form-control" id="input-text" name="name" placeholder="Usuario a dar la Placa" value="" style="width:213%;">
                                    </div>

                                    <center><p class="lead"><span class="badge info-color p-2">Placa</span></p></center>
                                    <div class="col-md-6">
									<input type="text" class="form-control" id="input-text" name="badge" placeholder="C&oacute;digo de la Placa a recibir" value="" style="width:213%;">
                                    </div>

                                    <center><input name="givebadge" type="submit" class="btn btn-dark bg-blue-grey-800 color-white margin-left-10" value="Enviar"></center>
							</form>

                                <!--Grid column-->

                            <!--Grid row-->

                        </div>



            </div>
            
            </section>














      <section class="mb-5" style="width:50%;float:left;margin-left:-20px;">
        <!--Card-->
        <div class="card card-cascade narrower">


            <!--Section: Table-->
<br>
            <div class="table-ui p-2 mb-3 mx-4 mb-5">
            <div class="view gradient-card-header light-blue lighten-1">
                            <h2 class="h2-responsive mb-0">Quitar placa</h2>
                        </div><br>
                            <!--Grid row-->
                            <div class="row">

                                                           <!--Grid column-->
                                    <div class="col-md-6">
                                    <form action="" method="post" > 

									<input name="nameq" class="form-control my-0 py-0" type="text" placeholder="Search" value="" style="width:213%;">
                                    </form>
                                    </div>                                    
                                    

                                <!--Grid column-->

                            </div>
                            <!--Grid row-->

                        </div>

                <div class="card card-cascade narrower z-depth-0">

                    <!--Card image-->
                    <div class="view gradient-card-header blue-gradient narrower py-2 mx-4 mb-3 d-flex justify-content-between align-items-center">

                        <div>
                            <button type="button" class="btn btn-outline-white btn-rounded btn-sm px-2"><i class="fa fa-th-large mt-0"></i></button>
                            <button type="button" class="btn btn-outline-white btn-rounded btn-sm px-2"><i class="fa fa-columns mt-0"></i></button>
                        </div>

                        <a href="" class="white-text mx-3">Placas</a>

                        <script type="text/javascript">function banPreset(val){document.getElementById('banlength').value = val;}</script>
                        <div>
                        <form action="" method="post">
                            <button name="delebadge" id="banlength" value="" class="btn btn-outline-white btn-rounded btn-sm px-2"><i class="fa fa-remove mt-0"></i></button>
                            </form>
                        </div>

                    </div>
                    <!--/Card image-->

                    <div class="px-4">

                        <div class="table-responsive">
                            <!--Table-->
                            <table class="table table-hover mb-0">

                                <!--Table head-->
                                <thead>
                                    <tr>
                                        <th>
                                            <input type="checkbox" id="checkbox">
                                            <label for="checkbox" class="mr-2 label-table"></label>
                                        </th>
                                        <th class="th-lg"><a>Placa <i class="fa fa-sort ml-1"></i></th>
                                        <th class="th-lg">Usuario<i class="fa fa-sort ml-1"></i></th>
                                        <th class="th-lg">¿La tiene puesta?<i class="fa fa-sort ml-1"></i></th>

                                    </tr>
                                </thead>
                                <!--Table head-->

                                <!--Table body-->
                                <tbody>
                                <?php	if(isset($_POST['nameq'])){ 
										$buscar = $Functions->FilterText($_POST['nameq']);
										$busc = $db->query("SELECT * FROM users WHERE username = '".$buscar."'");
										if($busc->num_rows > 0){
											if($user['rank'] >= 7){
                                                
                                                
                                                while($inf = $busc->fetch_array()){
                                                    $find = $db->query("SELECT * FROM user_badges WHERE user_id = '$inf[id]' ORDER by id DESC");
                                                    while($us = $find->fetch_array()){
                                                        if($us['badge_slot'] == 0){
                                                            $slot = 'No';
                                                        }else{
                                                        $slot = 'Sí';}
                                                        ?>
                                    <tr>
                                        <th scope="row">
                                            <input type="checkbox" id="<?php echo $us['badge_id']; ?>" onclick="banPreset('<?php echo $us['id']; ?>');">
                                            <label for="<?php echo $us['badge_id']; ?>" class="label-table"></label>
                                        </th>
                                        <td><img class="media-object" draggable="false" oncontextmenu="return false" src="<?php echo BADGEURL . $us['badge_id']; ?>.gif"></td>
                                        <td><?php echo $inf['username']; ?></td>
                                        <td><?php echo $slot; ?></td>
                                         </tr>
                                    <?php }}}}else{ echo '<br><b style="color:red">No se encontraron resultados para <i style="color:black;">'.$buscar.'</i></b><br>';  }} ?>
                                </tbody>
                                <!--Table body-->
                            </table>
                            <!--Table-->
                        </div>

                        <hr class="my-0">

                        <!--Bottom Table UI-->
                        <div class="d-flex justify-content-between">

                            <!--Pagination -->
                            <nav class="my-4">
                                <ul class="pagination pagination-circle pg-blue mb-0">

                                    <!--First-->
                                    <li class="page-item disabled clearfix d-none d-md-block"><a class="page-link">First</a></li>

                                    <!--Arrow left-->
                                    <li class="page-item disabled">
                                        <a class="page-link" aria-label="Previous">
                                        <span aria-hidden="true">&laquo;</span>
                                        <span class="sr-only">Previous</span>
                                    </a>
                                    </li>

                                    <!--Numbers-->
                                    <li class="page-item active"><a class="page-link">1</a></li>
                                    <li class="page-item"><a class="page-link">2</a></li>

                                    <!--Arrow right-->
                                    <li class="page-item">
                                        <a class="page-link" aria-label="Next">
                                            <span aria-hidden="true">&raquo;</span>
                                            <span class="sr-only">Next</span>
                                        </a>
                                    </li>

                                    <!--First-->
                                    <li class="page-item clearfix d-none d-md-block"><a class="page-link">Last</a></li>

                                </ul>
                            </nav>
                            <!--/Pagination -->

                        </div>
                        <!--Bottom Table UI-->

                    </div>
                </div>

            </section>
            <!--Section: Table-->

        </div>
        <!--/.Card-->

    <!--Section: Main panel-->
</main>
<!--Main layout-->
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<?php
//COLUMNA FOOTER
$TplClass->AddTemplateHK("templates", "footer");
?>