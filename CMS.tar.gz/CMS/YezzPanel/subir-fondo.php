<?php
   ob_start();
   	require_once '../global.php';
   	$TplClass->SetParam('title', 'Subir Fondo para bg');
   	$TplClass->SetParam('zone', 'Subir Fondo para bg');
    $Functions->LoggedHk("true");
          
   	$users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
   	$user = $users->fetch_array();
   	$action = $Functions->FilterText($_GET['action']);
    $id = $Functions->FilterText($_GET['id']);
   
   
   	$TplClass->SetAll();
       if( $_SESSION['ERROR_RETURN'] ){
   $TplClass->SetParam('error', '<script>toastr.error(\''.$_SESSION['ERROR_RETURN'].'\');</script>');
   unset($_SESSION['ERROR_RETURN']);
   }
   if( $_SESSION['GOOD_RETURN'] ){
   $TplClass->SetParam('error', '<script>toastr.success(\''.$_SESSION['GOOD_RETURN'].'\');</script>');
   unset($_SESSION['GOOD_RETURN']);
    }
   	$result = $db->query("SELECT * FROM cms_settings WHERE id = 1 LIMIT 1");
   	$data = $result->fetch_array();
   	$SHORTNAME = $data['hotelname'];
   	$FACE = $data['facebook'];
    $LOGO = $data['logo'];
       
   
    $nombre_img = $_FILES['imagen']['name'];
    $tipo = $_FILES['imagen']['type'];
    $tamano = $_FILES['imagen']['size'];

    if (($nombre_img == !NULL) && ($_FILES['imagen']['size'] <= 500000)) 
    {
        if (($_FILES["imagen"]["type"] == "image/gif")
        || ($_FILES["imagen"]["type"] == "image/jpeg")
        || ($_FILES["imagen"]["type"] == "image/jpg")
        || ($_FILES["imagen"]["type"] == "image/png"))
       {
          $directorio = $_SERVER['DOCUMENT_ROOT'].'/game/fondos/';
          move_uploaded_file($_FILES['imagen']['tmp_name'],$directorio.$nombre_img);
          header("LOCATION: ". HK ."upload-background");
        } 
        
    } 
    else 
    {
       if($nombre_img == !NULL) $_SESSION['ERROR_RETURN'] = "La imagen es demasiado grande "; 
    }


    if(isset($_POST['subirColor'])){
            $db->query("INSERT INTO cms_logs_upbadges (username, url, type, time) VALUES ('". $user['username'] ."', '/game/fondos/".$nombre_img."', 'fondo', '". time() ."')");            
			$db->query("INSERT INTO cms_stafflogs (username, action, message, rank, userid, timestamp) VALUES ('". $user['username'] ."','Agrego un fonfo', 'Agrego un fondo', '". $user['rank'] ."', '". $user['id'] ."', '".date("Y-m-d ")."')");
			$_SESSION['GOOD_RETURN'] = "Fondo agregado correctamente";
			header("LOCATION: ". HK ."upload-background");
		}

   	$TplClass->AddTemplateHK("templates", "menu");
   	ob_end_flush(); 
   ?>
<!--Main layout-->
<main>
   <div class="container-fluid">
      <!--Panel-->
      <div class="card text-center" style="width:50%;float:right;margin-right:-10px;">
         <h3 class="card-header primary-color white-text">Fondos subidos por mi</h3>
         <div class="card-body">
            <p class="card-text">Para copiar el link de un fondo, haga click en la imagen (se requiere javascript).</p>
            <?php 	global $db;
          $badge = $db->query("SELECT * FROM cms_logs_upbadges WHERE username = '".$user['username'] ."' AND type = 'fondo'");
           while($badgess = $badge->fetch_array()){

               ?>


                        <!--Zoom effect-->
                        <div class="view overlay hm-zoom badge clipboard" style="height:10%;margin-top:10px;" code="<?php echo PATH . $badgess['url']; ?>">
                            <a href="<?php echo PATH . $badgess['url']; ?>"><img draggable="false" oncontextmenu="return false" src="<?php echo PATH . $badgess['url']; ?>" class="img-fluid " alt=""></a>
                            <div class="mask flex-center waves-effect waves-light">
                                <p class="black-text"><h3 style="color:#000">Copiar</h3></p>
                            </div>
                        </div>
            <?php } ?>
         </div>
      </div>
      <!--/.Panel-->
      <!--Section: Inputs-->
      <section class="section card mb-5" style="width:50%;">
         <h3 class="card-header primary-color white-text">Subir bg</h3>
         <div class="card-body">
            <form action="" method="post" enctype="multipart/form-data">
            <div class="row">
               <div class="col-md-6 mb-r" style="margin-top:20px;">
                     <div class="file-field" style="width:208%;">
                        <div class="btn btn-primary btn-sm waves-effect waves-light">
                           <span>FONDO</span>
                           <input type="file" name="imagen" accept="image/png">
                        </div>
                        <div class="file-path-wrapper">
                           <input class="file-path validate" type="text" placeholder="Upload your file" disabled style="width:150%;">
                        </div>
                     </div>
               </div>
            <!--Grid column-->
            <button style="margin-top: -20px;width:100%;" name="subirColor" type="submit" class="btn btn-success waves-effect waves-light">Success</button>
            </form>
            </div>
   </section>
   <!--Section: Inputs-->
   </div>
</main><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<!--Main layout-->
<?php
   //COLUMNA FOOTER
   $TplClass->AddTemplateHK("templates", "footer");
   ?>
      <script data-cfasync="false" src="/app/assets/js/jquery.shop.js" charset="utf-8"></script>
