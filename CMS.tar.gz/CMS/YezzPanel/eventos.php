<?php
   ob_start();
   	require_once '../global.php';
   	$TplClass->SetParam('title', 'Eventos');
   	$TplClass->SetParam('zone', 'Eventos');
    $Functions->LoggedHk("true");
          
   	$users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
   	$user = $users->fetch_array();
   	$action = $Functions->FilterText($_GET['action']);
    $id = $Functions->FilterText($_GET['id']);
   
   
   	$TplClass->SetAll();
   if( $_SESSION['ERROR_RETURN'] ){
   $TplClass->SetParam('error', '<script>toastr.error(\''.$_SESSION['ERROR_RETURN'].'\');</script>');
   unset($_SESSION['ERROR_RETURN']);
   }
   if( $_SESSION['GOOD_RETURN'] ){
   $TplClass->SetParam('error', '<script>toastr.success(\''.$_SESSION['GOOD_RETURN'].'\');</script>');
   unset($_SESSION['GOOD_RETURN']);
    }
   	$result = $db->query("SELECT * FROM cms_settings WHERE id = 1 LIMIT 1");
   	$data = $result->fetch_array();
   	$SHORTNAME = $data['hotelname'];
   	$FACE = $data['facebook'];
    $LOGO = $data['logo'];
   
    function generarCodigo($longitud) {
        $key = '';
        $pattern = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $max = strlen($pattern)-1;
        for($i=0;$i < $longitud;$i++) $key .= $pattern{mt_rand(0,$max)};
        return $key;
       }
       
       if($action == "err" && !empty($id)){
        $db->query("INSERT INTO cms_stafflogs (username, action, message, rank, userid, timestamp) VALUES ('". $user['username'] ."','Eventos', 'Ha borrado un Evento', '". $user['rank'] ."', '". $user['id'] ."', '".date("Y-m-d ")."')");
        $db->query("DELETE FROM cms_eventos WHERE id = '{$id}' LIMIT 1");
        $_SESSION['GOOD_RETURN'] = "Evento borrado correctamente";
            header("LOCATION: ". HK ."events");
   }

   if($_POST['addpromo']){
    if(isset($_POST['title']) && isset($_POST['id_sala']) && isset($_POST['desc'])){
        $title = $Functions->FilterText($_POST['title']);
        $id_sala = $Functions->FilterText($_POST['id_sala']);
        $fecha = $Functions->FilterText($_POST['fecha']);
        $desc = $_POST['desc'];
        if(empty($title) || empty($desc)){
            $_SESSION['ERROR_RETURN'] = "Has dejado campos vac&iacute;os";
            header("LOCATION: ". HK ."events");
        }else{
            $dbQuery= array();
            $dbQuery['title'] = $title;
            $dbQuery['id_sala'] = $id_sala;
            $dbQuery['fecha'] = $fecha;
            $dbQuery['desc'] = $desc;
            $query = $db->insertInto('cms_eventos', $dbQuery);
            $db->query("INSERT INTO cms_stafflogs (username, action, message, rank, userid, timestamp) VALUES ('". $user['username'] ."','Eventos', 'Ha creado el Evento ".$title."', '". $user['rank'] ."', '". $user['id'] ."', '".date("Y-m-d ")."')");
            $_SESSION['GOOD_RETURN'] = "Evento agregado correctamente";
            header("LOCATION: ". HK ."events");
        }
    }
   }

   if($_POST['editpromo']){
    if(isset($_POST['title']) && isset($_POST['id_sala']) && isset($_POST['desc'])){
        $title = $Functions->FilterText($_POST['title']);
        $id_sala = $Functions->FilterText($_POST['id_sala']);
        $fecha = $Functions->FilterText($_POST['fecha']);
        $desc = $_POST['desc'];
            $db->query("UPDATE cms_eventos SET title = '{$title}', id_sala = '{$id_sala}', fecha = '{$fecha}', `desc` = '{$desc}' WHERE id = '{$id}' LIMIT 1");
            $db->query("INSERT INTO cms_stafflogs (username, action, message, rank, userid, timestamp) VALUES ('". $user['username'] ."','Eventos', 'Ha editado el Evento ".$title."', '". $user['rank'] ."', '". $user['id'] ."', '".date("Y-m-d ")."')");
            $_SESSION['GOOD_RETURN'] = "Evento editado correctamente";
            header("LOCATION: ". HK ."events");
    }}

    
   	$TplClass->AddTemplateHK("templates", "menu");
   	ob_end_flush(); 
   ?>
<!--Main layout-->
<main>
   <div class="container">
      <?php global $db;
         if($action == "edit" && !empty($id)){
                            $hj = $db->query("SELECT * FROM cms_eventos WHERE id = '". $id ."'");
                            $h_edit = $hj->fetch_array();
         ?>
      <form action="" method="post">
         <!-- Section: Create Page -->
         <section class="section mt-5">
            <!-- First row -->
            <div class="row">
               <!-- First col -->
               <div class="col-lg-8">
                  <!-- First card -->
                  <div class="card mb-r post-title-panel">
                     <div class="card-body">
                        <div class="md-form mt-1 mb-0">
                           <input type="text" id="form1" class="form-control" name="title" value="<?php echo $h_edit['title']; ?>">
                           <label for="form1" class="">T&iacute;tulo del evento</label>
                        </div>
                     </div>
                  </div>
                  <!-- /.First card -->
                  <!-- Third Card -->
                  <div class="card mb-r">
                     <div class="card-body">
                        <div class="md-form mb-0">
                           <textarea type="text" id="form447" class="md-textarea" name="desc"><?php echo $h_edit['desc']; ?></textarea>
                           <label for="form447">¿De qué trata el evento?</label>
                        </div>
                     </div>
                  </div>
                  <!-- /.Third Card -->
                  <!-- First card -->
                  <div class="card mb-r post-title-panel">
                     <div class="card-body">
                        <div class="row">
                           <!--Grid column-->
                           <div class="col-md-6 mb-r">
                              <div class="md-form mt-1 mb-0">
                                 <input type="text" id="form6f" class="form-control" name="id_sala" value="<?php echo $h_edit['id_sala']; ?>">
                                 <label class="" for="form6f">ID de la sala</label>
                              </div>
                           </div>
                           <!--Grid column-->
                           <!--Grid column-->
                           <div class="col-md-6 mb-r">
                              <div class="md-form mt-1 mb-0">
                                 <input type="text" id="form11" class="form-control" name="fecha" value="<?php echo $h_edit['fecha']; ?>">
                                 <label for="form11" class="">Fecha</label>
                              </div>
                           </div>
                           <!--Grid column-->
                        </div>
                     </div>
                  </div>
                  <!-- /.First card -->
               </div>
               <!-- /.First col -->
               <!-- Second col -->
               <div class="col-lg-4">
                  <!--Card-->
                  <div class="card card-cascade narrower mb-r">
                     <!--Card image-->
                     <div class="view gradient-card-header blue-gradient">
                        <h4 class="mb-0">Publicar</h4>
                     </div>
                     <!--/Card image-->
                     <!--Card content-->
                     <div class="card-body">
                        <p><i class="fa fa-flag mr-1" aria-hidden="true"></i> Estado: <strong>Crear</strong></p>
                        <p><i class="fa fa-eye mr-1" aria-hidden="true"></i> Visibilidad <strong>Publico</strong></p>
                        <p><i class="fa fa-archive mr-1 mr-1" aria-hidden="true"></i> Revisiones: <strong>skere</strong></p>
                        <p><i class="fa fa-calendar mr-1" aria-hidden="true"></i> Publicar: <strong>Inmediatamente</strong></p>
                        <div class="text-right">
                           <button class="btn-flat waves-effect">Cancelar</button>
                           <input name="editpromo" type="submit"  class="btn btn-primary" value="Publicar">
                        </div>
                     </div>
                     <!--/.Card content-->
                  </div>
                  <!--/.Card-->
                  <!--Card-->
                  <div class="card card-cascade narrower mb-r">
                     <!--Card image-->
                     <div class="view gradient-card-header blue-gradient">
                        <h4 class="mb-0">Noticias creadas</h4>
                     </div>
                     <!--/Card image-->
                     <!--Card content-->
                     <div class="card-body">
                        <div class="panel-body" style="max-height:800px;display: block;overflow: auto;">
                           <?php global $db;
                              $result = $db->query("SELECT * FROM cms_eventos ORDER BY id DESC");
                              if($result->num_rows > 0){
                              	while($data = $result->fetch_array()){
                              		echo '<li style="font-size:13px;">&#9758; '.$data['title'].' &#187; <div style="float:right;"><a href="'. HK .'events?action=edit&id='.$data['id'].'"><b><i class="fa fa-pencil-square-o"></i> Editar</b></a> | <a href="'. HK .'events?action=err&id='.$data['id'].'"><b><i class="fa fa-trash-o"></i> Borrar</b></a></div></li><p><b>Autor:</b> '.$data['author'].'<hr>';
                              		unset($k);
                              	}
                              	echo '</ul>';
                              
                              }else{
                              	echo '<b style="color:red;">No hay Eventos creados</i>';
                              }
                              ?>
                        </div>
                     </div>
                     <!--/.Card content-->
                  </div>
                  <!--/.Card-->
               </div>
               <!-- /.Second col -->
            </div>
            <!-- /.First row -->
         </section>
         <!-- /.Section: Create Page -->
      </form>
      <?php }else{ ?>
      <form action="" method="post">
         <!-- Section: Create Page -->
         <section class="section mt-5">
            <!-- First row -->
            <div class="row">
               <!-- First col -->
               <div class="col-lg-8">
                  <!-- First card -->
                  <div class="card mb-r post-title-panel">
                     <div class="card-body">
                        <div class="md-form mt-1 mb-0">
                           <input type="text" id="form1" class="form-control" name="title">
                           <label for="form1" class="">T&iacute;tulo del evento</label>
                        </div>
                     </div>
                  </div>
                  <!-- /.First card -->
                  <!-- Third Card -->
                  <div class="card mb-r">
                     <div class="card-body">
                        <div class="md-form mb-0">
                           <textarea type="text" id="form447" class="md-textarea" name="desc"></textarea>
                           <label for="form447">¿De qué trata el evento?</label>
                        </div>
                     </div>
                  </div>
                  <!-- /.Third Card -->
                  <!-- First card -->
                  <div class="card mb-r post-title-panel">
                     <div class="card-body">
                        <div class="row">
                           <!--Grid column-->
                           <div class="col-md-6 mb-r">
                              <div class="md-form mt-1 mb-0">
                                 <input type="text" id="form6f" class="form-control" name="id_sala">
                                 <label class="" for="form6f">ID de la sala</label>
                              </div>
                           </div>
                           <!--Grid column-->
                           <!--Grid column-->
                           <div class="col-md-6 mb-r">
                              <div class="md-form mt-1 mb-0">
                                 <input type="text" id="form11" class="form-control" name="fecha">
                                 <label for="form11" class="">Fecha</label>
                              </div>
                           </div>
                           <!--Grid column-->
                        </div>
                     </div>
                  </div>
                  <!-- /.First card -->
               </div>
               <!-- /.First col -->
               <!-- Second col -->
               <div class="col-lg-4">
                  <!--Card-->
                  <div class="card card-cascade narrower mb-r">
                     <!--Card image-->
                     <div class="view gradient-card-header blue-gradient">
                        <h4 class="mb-0">Publicar</h4>
                     </div>
                     <!--/Card image-->
                     <!--Card content-->
                     <div class="card-body">
                        <p><i class="fa fa-flag mr-1" aria-hidden="true"></i> Estado: <strong>Crear</strong></p>
                        <p><i class="fa fa-eye mr-1" aria-hidden="true"></i> Visibilidad <strong>Publico</strong></p>
                        <p><i class="fa fa-archive mr-1 mr-1" aria-hidden="true"></i> Revisiones: <strong>skere</strong></p>
                        <p><i class="fa fa-calendar mr-1" aria-hidden="true"></i> Publicar: <strong>Inmediatamente</strong></p>
                        <div class="text-right">
                           <button class="btn-flat waves-effect">Cancelar</button>
                           <input name="addpromo" type="submit" class="btn btn-primary" value="Publicar">
                        </div>
                     </div>
                     <!--/.Card content-->
                  </div>
                  <!--/.Card-->
                  <!--Card-->
                  <div class="card card-cascade narrower mb-r">
                     <!--Card image-->
                     <div class="view gradient-card-header blue-gradient">
                        <h4 class="mb-0">Eventos creados</h4>
                     </div>
                     <!--/Card image-->
                     <!--Card content-->
                     <div class="card-body">
                        <div class="panel-body" style="max-height:800px;display: block;overflow: auto;">
                           <?php global $db;
                              $result = $db->query("SELECT * FROM cms_eventos ORDER BY id DESC");
                              if($result->num_rows > 0){
                              	while($data = $result->fetch_array()){
                              		echo '<li style="font-size:13px;">&#9758; '.$data['title'].' &#187; <div style="float:right;"><a href="'. HK .'events?action=edit&id='.$data['id'].'"><b><i class="fa fa-pencil-square-o"></i> Editar</b></a> | <a href="'. HK .'events?action=err&id='.$data['id'].'"><b><i class="fa fa-trash-o"></i> Borrar</b></a></div></li><p><b>Autor:</b> '.$data['author'].'<hr>';
                              		unset($k);
                              	}
                              	echo '</ul>';
                              
                              }else{
                              	echo '<b style="color:red;">No hay Eventos creados</i>';
                              }
                              ?>
                        </div>
                     </div>
                     <!--/.Card content-->
                  </div>
                  <!--/.Card-->
               </div>
               <!-- /.Second col -->
            </div>
            <!-- /.First row -->
         </section>
         <!-- /.Section: Create Page -->
      </form>
      <?php } ?>
   </div>
</main>
<!--Main layout-->
<?php
   //COLUMNA FOOTER
   $TplClass->AddTemplateHK("templates", "footer");
   ?>
<script type="text/javascript">
   CKEDITOR.replace ("editor1");
</script>