<?php
   ob_start();
   	require_once '../global.php';
   	$TplClass->SetParam('title', 'Tienda del Hotel');
   	$TplClass->SetParam('zone', 'Tienda del Hotel');
       $Functions->LoggedHk("true");
       $Functions->LoggedHkADMIN("true");
          
   	$users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
    $user = $users->fetch_array();
       

   	$action = $Functions->FilterText($_GET['action']);
    $id = $Functions->FilterText($_GET['id']);
    $do = $Functions->FilterText($_GET['do']);
    $key = $Functions->FilterText($_GET['key']);
   
   
   	$TplClass->SetAll();
       if( $_SESSION['ERROR_RETURN'] ){
   $TplClass->SetParam('error', '<script>toastr.error(\''.$_SESSION['ERROR_RETURN'].'\');</script>');
   unset($_SESSION['ERROR_RETURN']);
   }
   if( $_SESSION['GOOD_RETURN'] ){
   $TplClass->SetParam('error', '<script>toastr.success(\''.$_SESSION['GOOD_RETURN'].'\');</script>');
   unset($_SESSION['GOOD_RETURN']);
    }
   	$result = $db->query("SELECT * FROM cms_settings WHERE id = 1 LIMIT 1");
   	$data = $result->fetch_array();
   	$SHORTNAME = $data['hotelname'];
   	$FACE = $data['facebook'];
    $LOGO = $data['logo'];
       
    if($_POST['editpag']){
        if(isset($_POST['parent_id']) && isset($_POST['caption'])){
                 $parent_id = $Functions->FilterText($_POST['parent_id']);
                 $caption = $Functions->FilterText($_POST['caption']);
                 $icon_image = $Functions->FilterText($_POST['icon_image']);
                 $min_rank = $Functions->FilterText($_POST['min_rank']);
                 $order_num = $Functions->FilterText($_POST['order_num']);
                 $page_link = $Functions->FilterText($_POST['page_link']);
                 $page_layout = $Functions->FilterText($_POST['page_layout']);
                 $page_strings_1 = $Functions->FilterText($_POST['page_strings_1']);
                 $page_strings_2 = $Functions->FilterText($_POST['page_strings_2']);
        if(empty($_POST['parent_id']) || empty($_POST['caption'])){
            $_SESSION['ERROR_RETURN'] = "Has dejado campos vac&iacute;os";
            header("LOCATION: ". HK ."store?action=edit&id=".$id."");
        }else{
            $db->query("UPDATE catalog_pages SET parent_id = '{$parent_id}' WHERE id = '{$id}' LIMIT 1");	
            $db->query("UPDATE catalog_pages SET `caption` = '{$caption}' WHERE id = '{$id}' LIMIT 1");	
            $db->query("UPDATE catalog_pages SET icon_image = '{$icon_image}' WHERE id = '{$id}' LIMIT 1");	
            $db->query("UPDATE catalog_pages SET min_rank = '{$min_rank}' WHERE id = '{$id}' LIMIT 1");	
            $db->query("UPDATE catalog_pages SET order_num = '{$order_num}' WHERE id = '{$id}' LIMIT 1");	
            $db->query("UPDATE catalog_pages SET page_link = '{$page_link}' WHERE id = '{$id}' LIMIT 1");	
            $db->query("UPDATE catalog_pages SET page_layout = '{$page_layout}' WHERE id = '{$id}' LIMIT 1");	
            $db->query("UPDATE catalog_pages SET page_strings_1 = '{$page_strings_1}' WHERE id = '{$id}' LIMIT 1");	
            $db->query("UPDATE catalog_pages SET page_strings_2 = '{$page_strings_2}' WHERE id = '{$id}' LIMIT 1");	


            $db->query("INSERT INTO cms_stafflogs (username, action, message, rank, userid, timestamp) VALUES ('". $user['username'] ."','Edito una pagina del cata', 'Ha editado una pagina del cata', '". $user['rank'] ."', '". $user['id'] ."', '".date("Y-m-d ")."')");
            $_SESSION['GOOD_RETURN'] = "Placa editada correctamente";
            header("LOCATION: ". HK ."store?action=edit&id=".$id."");	
        }				
        }
        }


        if($_POST['addpag']){
            if(isset($_POST['parent_id']) && isset($_POST['caption'])){
                     $parent_id = $Functions->FilterText($_POST['parent_id']);
                     $caption = $Functions->FilterText($_POST['caption']);
                     $icon_image = $Functions->FilterText($_POST['icon_image']);
                     $min_rank = $Functions->FilterText($_POST['min_rank']);
                     $order_num = $Functions->FilterText($_POST['order_num']);
                     $page_link = $Functions->FilterText($_POST['page_link']);
                     $page_layout = $Functions->FilterText($_POST['page_layout']);
                     $page_strings_1 = $Functions->FilterText($_POST['page_strings_1']);
                     $page_strings_2 = $Functions->FilterText($_POST['page_strings_2']);
            if(empty($_POST['parent_id']) || empty($_POST['caption'])){
                $_SESSION['ERROR_RETURN'] = "Has dejado campos vac&iacute;os";
                header("LOCATION: ". HK ."store");
            }else{    
            $dbQuery= array();
            $dbQuery['parent_id'] = $parent_id;
            $dbQuery['caption'] = $caption;
            $dbQuery['icon_image'] = $icon_image;
            $dbQuery['min_rank'] = $min_rank;
            $dbQuery['order_num'] = $order_num;
            $dbQuery['page_link'] = $page_link;
            $dbQuery['page_layout'] = $page_layout;
            $dbQuery['page_strings_1'] = $page_strings_1;
            $dbQuery['page_strings_2'] = $page_strings_2;
            $query = $db->insertInto('catalog_pages', $dbQuery);
    
                $db->query("INSERT INTO cms_stafflogs (username, action, message, rank, userid, timestamp) VALUES ('". $user['username'] ."','Creo una pagina del cata', 'Ha creado una pagina del cata', '". $user['rank'] ."', '". $user['id'] ."', '".date("Y-m-d ")."')");
                $_SESSION['GOOD_RETURN'] = "Placa editada correctamente";
                header("LOCATION: ". HK ."store");	
            }				
            }
            }

   	$TplClass->AddTemplateHK("templates", "menu");
   	ob_end_flush(); 
   ?>
<!--Main layout-->
<main>
   <div class="container-fluid">
   <div style="height: 5px"></div>
   <section class="mb-5" >

   <?php if($action == "edit" && !empty($id)){
       $hj = $db->query("SELECT * FROM catalog_pages WHERE id = '". $id ."'");
       $h_edit = $hj->fetch_array();	?>




    <section class="mb-5" style="width:50%;float:right;margin-right:-85px;">
         <!--Card-->
         <div class="card card-cascade narrower">
            <!--Section: Table-->
            <br>
            <div class="table-ui p-2 mb-3 mx-4 mb-5">
               <div class="view gradient-card-header light-blue lighten-1">
                  <h2 class="h2-responsive mb-0">Editar página de la tienda</h2>
               </div>
               <form action="" method="post">
                  <p class="text-light margin-bottom-20">Rellena todos los campos para editar</p>

                  <div class="row">
                     <!--Grid column-->
                     <div class="col-md-6 mb-r">
                        <p class="lead"><span class="badge info-color p-2">Titulo</span></p>
                        <div class="md-form">
                           <input type="text" id="form6" class="form-control" value="<?php echo $h_edit['caption']; ?>" name="caption">
                           <label class="active" for="form6">Titulo:</label>
                        </div>
                     </div>
                     <!--Grid column-->
                     <!--Grid column-->
                     <div class="col-md-6 mb-r">
                        <p class="lead"><span class="badge info-color p-2">Icono</span></p>
                        <div class="md-form">
                           <input type="text" id="form11" class="form-control" value="<?php echo $h_edit['icon_image']; ?>" name="icon_image">
                           <label for="form11" class="active">icon_image</label>
                        </div>
                     </div></div>

                  <center>
                     <p class="lead"><span class="badge info-color p-2">Página sección</span></p>
                  </center>
                  <div class="md-form">
                 <select class="mdb-select colorful-select dropdown-info mx-2" name="parent_id" style="width:513%;">
                     <option value="" disabled>Paginas</option>
                     <?php $que = $db->query("SELECT * FROM catalog_pages ORDER BY id DESC"); while($qued = $que->fetch_array()){
                         if($h_edit['parent_id'] == $qued['id']){
                             $skere = 'selected';
                            }elseif($h_edit['parent_id'] == '-1'){
                             echo'<option value="-1" selected>Independiente</option>';

                            }else{
                             $skere = '';}
                             ?>
                     <option value="<?php echo $qued['id']; ?>" <?php echo $skere; ?>><?php echo $qued['caption']; ?></option>
                     <?php } ?>
                  </select>
                     </div>


                     <div class="row">
                     <!--Grid column-->
                     <div class="col-md-6 mb-r">
                        <p class="lead"><span class="badge info-color p-2">Rango minimo</span></p>
                        <div class="md-form">
                           <input type="number" id="form6" class="form-control" value="<?php echo $h_edit['min_rank']; ?>" name="min_rank">
                           <label class="active" for="form6">min_rank:</label>
                        </div>
                     </div>
                     <!--Grid column-->
                     <!--Grid column-->
                     <div class="col-md-6 mb-r">
                        <p class="lead"><span class="badge info-color p-2">Orden</span></p>
                        <div class="md-form">
                           <input type="number" id="form11" class="form-control" value="<?php echo $h_edit['order_num']; ?>" name="order_num">
                           <label for="form11" class="active">order_num</label>
                        </div>
                     </div>
                     <!--Grid column-->
                  </div>

                  <div class="row">
                     <!--Grid column-->
                     <div class="col-md-6 mb-r">
                        <p class="lead"><span class="badge info-color p-2">Link de la pagina</span></p>
                        <div class="md-form">
                           <input type="text" id="form6" class="form-control" value="<?php echo $h_edit['page_link']; ?>" name="page_link">
                           <label class="active" for="form6">page_link:</label>
                        </div>
                     </div>
                     <!--Grid column-->
                     <!--Grid column-->
                     <div class="col-md-6 mb-r">
                        <p class="lead"><span class="badge info-color p-2">Interfaz de la página </span></p>
                        <div class="md-form">
                           <input type="text" id="form11" class="form-control" value="<?php echo $h_edit['page_layout']; ?>" name="page_layout">
                           <label for="form11" class="active">page_layout</label>
                        </div>
                     </div>
                     <!--Grid column-->
                  </div>


                  <center>
                  <p class="lead"><span class="badge info-color p-2">Pagina congif 1 </span></p>
                  </center>
                  <input type="text" class="form-control" id="input-text" name="page_strings_1" placeholder="page_strings_1" value="<?php echo $h_edit['page_strings_1']; ?>" style="width:100%;">

                  <center>
                  <p class="lead"><span class="badge info-color p-2">Pagina congif 2 </span></p>
                  </center>
                  <div class="card mb-r">
                     <div class="card-body">
                        <div class="md-form mb-0">
                           <textarea type="text" id="form447" class="md-textarea" name="page_strings_2"><?php echo $h_edit['page_strings_2']; ?></textarea>
                           <label for="form447">page_strings_2</label>
                        </div>
                     </div>
                  </div>
                  <center><input name="editpag" type="submit" class="btn btn-dark bg-blue-grey-800 color-white margin-left-10" value="Enviar"></center>
               </form>
               <!--Grid column-->
               <!--Grid row-->
            </div>
         </div>
      </section>







    <?php }elseif($action == "add"){?>





        <section class="mb-5" style="width:50%;float:right;margin-right:-85px;">
         <!--Card-->
         <div class="card card-cascade narrower">
            <!--Section: Table-->
            <br>
            <div class="table-ui p-2 mb-3 mx-4 mb-5">
               <div class="view gradient-card-header light-blue lighten-1">
                  <h2 class="h2-responsive mb-0">Agregar una categoria a la tienda</h2>
               </div>
               <form action="" method="post">
                  <p class="text-light margin-bottom-20">Rellena todos los campos para editar</p>

                  <div class="row">
                     <!--Grid column-->
                     <div class="col-md-6 mb-r">
                        <p class="lead"><span class="badge info-color p-2">Titulo</span></p>
                        <div class="md-form">
                           <input type="text" id="form6" class="form-control" value="" name="caption">
                           <label class="active" for="form6">Titulo:</label>
                        </div>
                     </div>
                     <!--Grid column-->
                     <!--Grid column-->
                     <div class="col-md-6 mb-r">
                        <p class="lead"><span class="badge info-color p-2">Icono</span></p>
                        <div class="md-form">
                           <input type="text" id="form11" class="form-control" value="" name="icon_image">
                           <label for="form11" class="active">icon_image</label>
                        </div>
                     </div></div>

                  <center>
                     <p class="lead"><span class="badge info-color p-2">Página sección</span></p>
                  </center>
                  <div class="md-form">
                 <select class="mdb-select colorful-select dropdown-info mx-2" name="parent_id" style="width:513%;">
                     <option value="" disabled selected>Paginas</option>
                     <?php $que = $db->query("SELECT * FROM catalog_pages ORDER BY id DESC"); while($qued = $que->fetch_array()){
                         
                             ?>
                     <option value="-1">Independiente</option>
                     <option value="<?php echo $qued['id']; ?>"><?php echo $qued['caption']; ?></option>
                     <?php } ?>
                  </select>
                     </div>


                     <div class="row">
                     <!--Grid column-->
                     <div class="col-md-6 mb-r">
                        <p class="lead"><span class="badge info-color p-2">Rango minimo</span></p>
                        <div class="md-form">
                           <input type="number" id="form6" class="form-control" value="" name="min_rank">
                           <label class="active" for="form6">min_rank:</label>
                        </div>
                     </div>
                     <!--Grid column-->
                     <!--Grid column-->
                     <div class="col-md-6 mb-r">
                        <p class="lead"><span class="badge info-color p-2">Orden</span></p>
                        <div class="md-form">
                           <input type="number" id="form11" class="form-control" value="" name="order_num">
                           <label for="form11" class="active">order_num</label>
                        </div>
                     </div>
                     <!--Grid column-->
                  </div>

                  <div class="row">
                     <!--Grid column-->
                     <div class="col-md-6 mb-r">
                        <p class="lead"><span class="badge info-color p-2">Link de la pagina</span></p>
                        <div class="md-form">
                           <input type="text" id="form6" class="form-control" value="" name="page_link">
                           <label class="active" for="form6">page_link:</label>
                        </div>
                     </div>
                     <!--Grid column-->
                     <!--Grid column-->
                     <div class="col-md-6 mb-r">
                        <p class="lead"><span class="badge info-color p-2">Interfaz de la página </span></p>
                        <div class="md-form">
                           <input type="text" id="form11" class="form-control" value="default_3x3" name="page_layout">
                           <label for="form11" class="active">page_layout</label>
                        </div>
                     </div>
                     <!--Grid column-->
                  </div>


                  <center>
                  <p class="lead"><span class="badge info-color p-2">Pagina congif 1 </span></p>
                  </center>
                  <input type="text" class="form-control" id="input-text" name="page_strings_1" placeholder="page_strings_1" value="" style="width:100%;">

                  <center>
                  <p class="lead"><span class="badge info-color p-2">Pagina congif 2 </span></p>
                  </center>
                  <div class="card mb-r">
                     <div class="card-body">
                        <div class="md-form mb-0">
                           <textarea type="text" id="form447" class="md-textarea" name="page_strings_2"></textarea>
                           <label for="form447">page_strings_2</label>
                        </div>
                     </div>
                  </div>
                  <center><input name="addpag" type="submit" class="btn btn-dark bg-blue-grey-800 color-white margin-left-10" value="Enviar"></center>
               </form>
               <!--Grid column-->
               <!--Grid row-->
            </div>
         </div>
      </section>







<?php }else{ ?>





   <div class="row">
   <div class="col-md-12 mb-1">
                            <div class="row mb-1">
                            <div class="col-md-9">
                                <h4 class="h4-responsive mt-1">Buscar página <b>por el nombre</b></h4>
                                <a href="?action=add" data-toggle="tooltip" data-placement="top" title="Crear página" class="btn-floating btn-lg red waves-effect waves-light">
         <i class="fa fa-pencil"></i>
         </a>
                            </div>

                            <div class="col-md-3">
                                <div class="md-form">
                                <form action="" method="post" > 
									<input id="buscar" onkeyup="buscador()" class="form-control" type="text" placeholder="Buscar furni" style="width:130%;margin-left:-85px;">
                                    </form>
                                </div>
                            </div>
                        </div>
                                <!-- Tabs -->
                                <!-- Nav tabs -->
                                <div class="tabs-wrapper">
                                    <ul class="nav classic-tabs tabs-primary primary-color" role="tablist">
                                        <li class="nav-item">
                                            <a class="nav-link waves-light waves-effect waves-light active" data-toggle="tab" href="#panel83" role="tab" aria-selected="true">Categorías </a>
                                        </li>
                                    </ul>
                                </div>
                                <!-- Tab panels -->
                                <div class="tab-content card">
                                    <!--Panel 1-->
                                    <div class="tab-pane fade active show" id="panel83" role="tabpanel">
                                        <div class="table-responsive">
                                            <table class="table">
                                            <div id ="resultado"></div>
                                                <thead>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Esta en:</th>
                                                        <th>Caption</th>
                                                        <th>Visible</th>
                                                        <th>Min_rank</th>
                                                    </tr>
                                                </thead>
                                                <tbody>


                                                <?php
   $CantidadMostrar=15;
   
           $compag         =(int)(!isset($_GET['pag'])) ? 1 : $_GET['pag']; 
   	$TotalReg       =$db->query("SELECT * FROM catalog_pages");
   	
   	$TotalRegistro  =ceil($TotalReg->num_rows/$CantidadMostrar);
   	$consulta = $db->query("SELECT * FROM catalog_pages ORDER BY id DESC LIMIT ".(($compag-1)*$CantidadMostrar)." , ".$CantidadMostrar);
   	while($lista = $consulta->fetch_array()){
        $consulta2 = $db->query("SELECT * FROM catalog_pages WHERE id = '".$lista['parent_id']."'");
        $parent = $consulta2->fetch_array();
        if($lista['parent_id'] == '-1'){
            $captionil = 'Independiente';
        }else{
            $captionil = $parent['caption'];}
           if($lista['visible'] == 1){
               $visible = 'Sí';
            }else{
               $visible = 'No';}

                    echo '<tr><th scope="row">'.$lista['id'].'</th>
                    <td>'.$captionil.'</td>    
                    <td>'.$lista['caption'].'</td>                
                    <td>'.$visible.'</td>
                    <td>'.$lista['min_rank'].'</td>
                    <td>
                    <a href="?action=edit&id='.$lista['id'].'" target="_blank" class="teal-text" data-toggle="tooltip" data-placement="top" title="Editar"><i class="fa fa-pencil"></i></a>
                    <a href="" target="_blank" class="red-text" data-toggle="tooltip" data-placement="top" title="Remove"><i class="fa fa-times"></i></a>
                    </td>
                    </tr>';
   
   	}
     
   ?>
                              
                                              </tbody>
                                            </table>
                                            
                                        </div>
                                        <nav>
                                <ul class="pagination pg-blue">
                                        <?php
   	$IncrimentNum =(($compag +1)<=$TotalRegistro)?($compag +1):1;
     	$DecrementNum =(($compag -1))<1?1:($compag -1);
     
        $Desde=$compag-(ceil($CantidadMostrar/2)-1);
        $Hasta=$compag+(ceil($CantidadMostrar/2)-1);
        
        $Desde=($Desde<1)?1: $Desde;
        $Hasta=($Hasta<$CantidadMostrar)?$CantidadMostrar:$Hasta;
        for($i=$Desde; $i<=$Hasta;$i++){
        	if($i<=$TotalRegistro){
        	  if($i==$compag){
              echo '<li class="page-item active"><a class="page-link">'.$i.'</a></li>';
        	  }else {
        	  	echo '<li class="page-item"><a class="page-link" href="?pag='.$i.'">'.$i.'</a></li>';
        	  }     		
        	}
        }
   	echo "";
     
     
   ?></ul>
   </nav>
                                    </div>
                                    <!--/.Panel 1-->
 
                                </div>
                                <!-- /.Tabs -->
                            </div>
                        </div>
                        
                        <?php } ?>
   </section>
   <!--Section: Table-->
   </div>
   <!--/.Card-->
   <!--Section: Main panel-->
</main>
<!--Main layout-->
<?php
   //COLUMNA FOOTER
   $TplClass->AddTemplateHK("templates", "footer");
   ?>

<script>
        function buscador()
        {
        var xmlhttp;
        
        var n=document.getElementById('buscar').value;
        
        if(n==''){
        document.getElementById("resultado").innerHTML="";
        return;
        }
        
        if (window.XMLHttpRequest)
        {// code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp=new XMLHttpRequest();
        }
        else
        {// code for IE6, IE5
        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange=function()
        {
        if (xmlhttp.readyState==4 && xmlhttp.status==200)
        {
        document.getElementById('resultado').innerHTML="<p align='center'>cargando chaval</p>";
        document.getElementById("resultado").innerHTML=xmlhttp.responseText;
        }
        }
        xmlhttp.open("POST","/PrivateFolder/reload/catalogp.php",true);
        xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
        xmlhttp.send("q="+n);
        }
    </script>