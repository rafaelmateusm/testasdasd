<?php
   ob_start();
   	require_once '../global.php';
   	$TplClass->SetParam('title', 'Subir placa');
   	$TplClass->SetParam('zone', 'Subir placa');
    $Functions->LoggedHk("true");
          
   	$users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
   	$user = $users->fetch_array();
   	$action = $Functions->FilterText($_GET['action']);
    $id = $Functions->FilterText($_GET['id']);
   
   
   	$TplClass->SetAll();
       if( $_SESSION['ERROR_RETURN'] ){
   $TplClass->SetParam('error', '<script>toastr.error(\''.$_SESSION['ERROR_RETURN'].'\');</script>');
   unset($_SESSION['ERROR_RETURN']);
   }
   if( $_SESSION['GOOD_RETURN'] ){
   $TplClass->SetParam('error', '<script>toastr.success(\''.$_SESSION['GOOD_RETURN'].'\');</script>');
   unset($_SESSION['GOOD_RETURN']);
    }
   	$result = $db->query("SELECT * FROM cms_settings WHERE id = 1 LIMIT 1");
   	$data = $result->fetch_array();
   	$SHORTNAME = $data['hotelname'];
   	$FACE = $data['facebook'];
    $LOGO = $data['logo'];
       
   
    $nombre_img = $_FILES['imagen']['name'];
    $tipo = $_FILES['imagen']['type'];
    $tamano = $_FILES['imagen']['size'];

    $cadena = $nombre_img;
    $tutorial = explode('.gif',$cadena);
    

    if (($nombre_img == !NULL) && ($_FILES['imagen']['size'] <= 500000)) 
    {
       if (($_FILES["imagen"]["type"] == "image/gif"))
       {
          $directorio = $_SERVER['DOCUMENT_ROOT'].'/game/c_images/album1584/';
          move_uploaded_file($_FILES['imagen']['tmp_name'],$directorio.$nombre_img);
          header("LOCATION: ". HK ."upload-bad");
        } 
        
    } 
    else 
    {
       if($nombre_img == !NULL) $_SESSION['ERROR_RETURN'] = "La imagen es demasiado grande "; 
    }


    $nombre_img2 = $_FILES['imagen2']['name'];
    $tipo2 = $_FILES['imagen2']['type'];
    $tamano2 = $_FILES['imagen2']['size'];
    
    if (($nombre_img2 == !NULL) && ($_FILES['imagen2']['size'] <= 500000)) 
    {
       if (($_FILES["imagen2"]["type"] == "image/png"))
       {
          $directorio2 = $_SERVER['DOCUMENT_ROOT'].'/game/c_images/notifications/badge/';
          move_uploaded_file($_FILES['imagen2']['tmp_name'],$directorio2.$nombre_img2);
          header("LOCATION: ". HK ."upload-bad");
        } 
        
    } 
    else 
    {
       if($nombre_img2 == !NULL) $_SESSION['ERROR_RETURN'] = "La imagen es demasiado grande "; 
    }

    if(isset($_POST['subirColor'])){
		$titulo = $Functions->FilterText($_POST['titulo']);
		$des = $Functions->FilterText($_POST['des']);
		$repeat = $db->query("SELECT * FROM badge_definitions WHERE code = '".$tutorial[0]."'");
       if($repeat->num_rows > 0){
			$_SESSION['ERROR_RETURN'] = "Ya existe una placa con el mismo C&oacute;digo";
			header("LOCATION: ". HK ."upload-bad");
		}else{
            $db->query("INSERT INTO cms_logs_upbadges (username, badge, type, time) VALUES ('". $user['username'] ."', '".$tutorial[0]."', 'badge', '". time() ."')");            
			$db->query("INSERT INTO cms_stafflogs (username, action, message, rank, userid, timestamp) VALUES ('". $user['username'] ."','Agrego una nueva placa', 'Agrego la placa ".$tutorial[0]."', '". $user['rank'] ."', '". $user['id'] ."', '".date("Y-m-d ")."')");
			$db->query("INSERT INTO badge_definitions (code) VALUES ('".$tutorial[0]."')");
			$db->query("INSERT INTO client_external_badge_texts (badge_code, badge_title, badge_desc) VALUES ('".$tutorial[0]."', '".$titulo ."', '".$des."')");
			$_SESSION['GOOD_RETURN'] = "placa agregada correctamente";
			header("LOCATION: ". HK ."upload-bad");
		}
	}

   	$TplClass->AddTemplateHK("templates", "menu");
   	ob_end_flush(); 
   ?>
<!--Main layout-->
<main>
   <div class="container-fluid">
      <!--Panel-->
      <div class="card text-center" style="width:50%;float:right;margin-right:-10px;">
         <h3 class="card-header primary-color white-text">Placas subidas por mi</h3>
         <div class="card-body">
            <p class="card-text">Para copiar la ID de una placa, haga click en ella (se requiere javascript).</p>
            <?php 	global $db;
          $badge = $db->query("SELECT * FROM cms_logs_upbadges WHERE username = '".$user['username'] ."'  AND type = 'badge'");
           while($badgess = $badge->fetch_array()){

            $badges2 = $db->query("SELECT * FROM client_external_badge_texts WHERE badge_code = '".$badgess['badge']."'");
            $badge2 = $badges2->fetch_array();
               ?>
               <div style="background:rgba(0,0,0,0.6);border-radius:3px;padding:4px;margin-right:5px;vertical-align:middle;" class="badge clipboard" code="<?php echo $badgess['badge'] ?>">
               <img draggable="false" oncontextmenu="return false" src="<?php echo BADGEURL . $badgess['badge']; ?>.gif" data-toggle="tooltip" data-original-title="Haga clic en mi para copiar mi ID">
               </div>
            <?php } ?>
         </div>
      </div>
      <!--/.Panel-->
      <!--Section: Inputs-->
      <section class="section card mb-5" style="width:50%;">
         <h3 class="card-header primary-color white-text">Subir placa</h3>
         <div class="card-body">
            <i><font size="2"><b>INSTRUCCION</b>: 1. <b>Placa GIF</b>: Es la que ira a la swf, para lucirla en el perfil. <br>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2. <b>Placa PNG</b>: Es la que ira a las notificaciones (OPCIONAL).</font></i></p>
            <b>RECUERDA RENOMBRAR LA PLACA CON EL CÓDIGO DESEADO</b>
            <form action="" method="post" enctype="multipart/form-data">
            <div class="row">
               <div class="col-md-4 mb-r" style="margin-top: 11px;">
                  <div class="md-form form-sm" style="width:335%;">
                     <input type="text" id="form1" class="form-control" name="titulo">
                     <label for="form1" class="">Titulo de la placa </label>
                  </div>
               </div></div>
               <div class="row">
               <div class="col-md-4 mb-r" style="margin-top: -30px;">
               <div class="md-form form-sm" style="width:335%;">
                  <input type="text" id="form11" class="form-control" name="des">
                  <label for="form11" class="">Descripción </label>
               </div>
            </div>
            </div>
            <div class="row">
               <!--Grid column-->
               <div class="col-md-6 mb-r" style="margin-top:-30px;margin-left:-10px;">
                  <div class="file-field" style="width:120%;">
                     <div class="btn btn-primary btn-sm waves-effect waves-light">
                        <span>Placa GIF</span>
                        <input type="file" name="imagen" accept="image/gif">
                     </div>
                     <div class="file-path-wrapper">
                        <input class="file-path validate" type="text" placeholder="Upload your file" disabled style="width:80%;">
                     </div>
                  </div>
               </div>
               <!--Grid column-->
               <div class="col-md-6 mb-r" style="margin-top:-30px;">
                     <div class="file-field" style="width:120%;">
                        <div class="btn btn-primary btn-sm waves-effect waves-light">
                           <span>Placa PNG</span>
                           <input type="file" name="imagen2" accept="image/png">
                        </div>
                        <div class="file-path-wrapper">
                           <input class="file-path validate" type="text" placeholder="Upload your file" disabled style="width:80%;">
                        </div>
                     </div>
               </div>
            <!--Grid column-->
            <button style="margin-top: -20px;width:100%;" name="subirColor" type="submit" class="btn btn-success waves-effect waves-light">Success</button>
            </form>
            </div>
   </section>
   <!--Section: Inputs-->
   </div>
</main>
<!--Main layout-->
<?php
   //COLUMNA FOOTER
   $TplClass->AddTemplateHK("templates", "footer");
   ?>
      <script data-cfasync="false" src="/app/assets/js/jquery.shop.js" charset="utf-8"></script>
