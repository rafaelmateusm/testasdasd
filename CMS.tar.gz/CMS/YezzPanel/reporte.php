<?php
ob_start();
	require_once '../global.php';
	$TplClass->SetParam('title', 'Reportes');
	$TplClass->SetParam('zone', 'Reportes');
	$Functions->LoggedHk("true");
	
	$users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
	$user = $users->fetch_array();
	$do = $Functions->FilterText($_GET['do']);
	$key = $Functions->FilterText($_GET['key']);

	$TplClass->SetAll();
	if( $_SESSION['ERROR_RETURN'] ){
		$TplClass->SetParam('error', '<div id="generic"><div id="error">'.$_SESSION['ERROR_RETURN'].'</div></div>');
		unset($_SESSION['ERROR_RETURN']);
	}
	if( $_SESSION['GOOD_RETURN'] ){
		$TplClass->SetParam('error', '<div id="generic"><div id="error" style="background: #88B600;border: 1px solid #88B600;">'.$_SESSION['GOOD_RETURN'].'</div></div>');
		unset($_SESSION['GOOD_RETURN']);
	}
	$result = $db->query("SELECT * FROM cms_settings WHERE id = 1 LIMIT 1");
	while($data = $result->fetch_array()){
		$SHORTNAME = $data['hotelname'];
		$FACE = $data['facebook'];
		$LOGO = $data['logo'];
	}

	$TplClass->AddTemplateHK("templates", "menu");
	ob_end_flush(); 
?>


<!--Main layout-->
<main>
        <div class="container-fluid">
            <div style="height: 5px"></div>

            <!--Section: Main panel-->
            <section class="mb-5">

                <!--Card-->
                <div class="card card-cascade narrower">

                     <!--Section: Table-->
                    <section>


                        <div class="card card-cascade narrower z-depth-0">

                            <!--Card image-->

                            <div class="view gradient-card-header blue-gradient narrower py-2 mx-4 mb-3 d-flex justify-content-between align-items-center">
                            
                                                    <div>
                                                        <button type="button" class="btn btn-outline-white btn-rounded btn-sm px-2 waves-effect waves-light"><i class="fa fa-th-large mt-0"></i></button>
                                                        <button type="button" class="btn btn-outline-white btn-rounded btn-sm px-2 waves-effect waves-light"><i class="fa fa-columns mt-0"></i></button>
                                                    </div>
                            
                                                    <a href="" class="white-text mx-3">Reportes</a>
                            
                                                    <div>
                                                        <button type="button" class="btn btn-outline-white btn-rounded btn-sm px-2 waves-effect waves-light"><i class="fa fa-pencil mt-0"></i></button>
                                                        <button type="button" class="btn btn-outline-white btn-rounded btn-sm px-2 waves-effect waves-light"><i class="fa fa-remove mt-0"></i></button>
                                                        <button type="button" class="btn btn-outline-white btn-rounded btn-sm px-2 waves-effect waves-light"><i class="fa fa-info-circle mt-0"></i></button>
                                                    </div>
                            
                                                </div>

                            </div>
                            <!--/Card image-->

                            <div class="px-4">

                                <div class="table-responsive">
                                    <!--Table-->
                                    <table class="table table-hover mb-0">

                                        <!--Table head-->
                                        <thead>
                                            <tr>
                                                <th>
                                                    <input type="checkbox" id="checkbox">
                                                    <label for="checkbox" class="mr-2 label-table"></label>
                                                </th>
                                                <th class="th-lg"><a>Nombre de usuario <i class="fa fa-sort ml-1"></i></a></th>
                                                <th class="th-lg"><a>Sobre<i class="fa fa-sort ml-1"></i></a></th>
                                                <th class="th-lg"><a>Prioridad<i class="fa fa-sort ml-1"></i></a></th>
                                                <th class="th-lg"><a>Categoría<i class="fa fa-sort ml-1"></i></a></th>
                                                <th class="th-lg"><a>Fecha<i class="fa fa-sort ml-1"></i></a></th>
                                                <th class="th-lg"><a>IP<i class="fa fa-sort ml-1"></i></a></th>
                                            </tr>
                                        </thead>
                                        <!--Table head-->

                                        <!--Table body-->
                                        <tbody>
                                            <?php
   $CantidadMostrar=10;
   
           $compag         =(int)(!isset($_GET['pag'])) ? 1 : $_GET['pag']; 
   	$TotalReg       =$db->query("SELECT * FROM cms_tickets WHERE type = 'ticket'");
   	
   	$TotalRegistro  =ceil($TotalReg->num_rows/$CantidadMostrar);
   	$consulta = $db->query("SELECT * FROM cms_tickets WHERE type = 'ticket' ORDER BY visto = '0' DESC LIMIT ".(($compag-1)*$CantidadMostrar)." , ".$CantidadMostrar);
   	
   	while($lista = $consulta->fetch_array()){
   $result2 = $db->query("SELECT * FROM users WHERE username = '".$lista['username'] ."'");
    while($userinfo = $result2->fetch_array()){
        if($lista['priority'] == 1){
            $priority = 'No es urgente';}elseif($lista['priority'] == 2){
                $priority = 'Poco urgente';}elseif($lista['priority'] == 3){
                    $priority = 'Bastante urgente';}elseif($lista['priority'] == 4){
                        $priority = 'Urgente';}elseif($lista['priority'] == 5){
                            $priority = 'Muy urgente';}

        if($lista['category'] == 1){
            $category = 'Problema técnico';}elseif($lista['category'] == 2){
                $category = 'Problema en la tienda';}elseif($lista['category'] == 3){
                    $category = 'Problema de moderación';}elseif($lista['category'] == 4){
                        $category = 'Problema de animación';}elseif($lista['category'] == 5){
                            $category = 'Problema con los furnis';}elseif($lista['category'] == 6){
                                $category = 'Problema con el foro';}elseif($lista['category'] == 7){
                                    $category = 'Los furnis faltantes';}  

                                    if($lista['visto'] == 1){
                                        $visto = 'checked';
                                    }else{
                                        $visto = '';} 

                    echo '<tr>
                    <th scope="row">
                    <input type="checkbox" '.$visto.'>
                    <label class="label-table" ></label>
                </th>
                    <td><a href="/PrivateFolder/reports-view?id='.$lista['id'].'">'.$lista['username'].'</a></td>
                    <td><a href="/PrivateFolder/reports-view?id='.$lista['id'].'">'.$lista['title'].'</a></td>
                    <td><a href="/PrivateFolder/reports-view?id='.$lista['id'].'">'.$priority.'</a></td>
                    <td><a href="/PrivateFolder/reports-view?id='.$lista['id'].'">'.$category.'</a></td>
                    <td><a href="/PrivateFolder/reports-view?id='.$lista['id'].'">'.$Functions->GetLast($lista['time']).'</a></td>
                    <td><a href="/PrivateFolder/reports-view?id='.$lista['id'].'">'.$userinfo['ip_last'].'</a></td>
                 </tr>';
   
   	}}
     
   ?>




                                        </tbody>
                                        <!--Table body-->
                                    </table>
                                    <!--Table-->
                                </div>

                                <hr class="my-0">

                                <!--Bottom Table UI-->
                                <div class="d-flex justify-content-between">

                                    <!--Pagination -->
                                    <nav class="my-4">
                                        <ul class="pagination pagination-circle pg-blue mb-0">

                                            <!--First-->
                                            <li class="page-item disabled clearfix d-none d-md-block"><a class="page-link">First</a></li>

                                            <!--Arrow left-->
                                            <li class="page-item disabled">
                                                <a class="page-link" aria-label="Previous">
                                                <span aria-hidden="true">&laquo;</span>
                                                <span class="sr-only">Previous</span>
                                            </a>
                                            </li>

                                            <?php
   	$IncrimentNum =(($compag +1)<=$TotalRegistro)?($compag +1):1;
     	$DecrementNum =(($compag -1))<1?1:($compag -1);
     
        $Desde=$compag-(ceil($CantidadMostrar/2)-1);
        $Hasta=$compag+(ceil($CantidadMostrar/2)-1);
        
        $Desde=($Desde<1)?1: $Desde;
        $Hasta=($Hasta<$CantidadMostrar)?$CantidadMostrar:$Hasta;
        for($i=$Desde; $i<=$Hasta;$i++){
        	if($i<=$TotalRegistro){
        	  if($i==$compag){
              echo '<li class="page-item active"><a class="page-link">'.$i.'</a></li>';
        	  }else {
        	  	echo '<li class="page-item"><a class="page-link" href="?pag='.$i.'">'.$i.'</a></li>';
        	  }     		
        	}
        }
   	echo "";
     
     
   ?>

                                            <!--Arrow right-->
                                            <li class="page-item">
                                                <a class="page-link" aria-label="Next">
                                                    <span aria-hidden="true">&raquo;</span>
                                                    <span class="sr-only">Next</span>
                                                </a>
                                            </li>

                                            <!--First-->
                                            <li class="page-item clearfix d-none d-md-block"><a class="page-link">Last</a></li>

                                        </ul>
                                    </nav>
                                    <!--/Pagination -->

                                </div>
                                <!--Bottom Table UI-->

                            </div>
                        </div>

                    </section>
                    <!--Section: Table-->

                </div>
                <!--/.Card-->

            </section>
            <!--Section: Main panel-->

            </div>
    </main>
    <!--Main layout-->


   <?php
   //COLUMNA FOOTER
   $TplClass->AddTemplateHK("templates", "footer");
   ?>
