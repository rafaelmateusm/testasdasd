<?php
   ob_start();
   	require_once '../global.php';
   	$TplClass->SetParam('title', 'Bienvenid@');
   	$TplClass->SetParam('zone', 'Bienvenido');
   	$Functions->LoggedHk("true");
   	
   	$users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
   	$user = $users->fetch_array();
   	
   	$a = $db->query("SELECT * FROM users WHERE rank >= 3");
   	$cntranks = $a->num_rows;
   	
   	$TplClass->SetAll();
       if( $_SESSION['ERROR_RETURN'] ){
		$TplClass->SetParam('error', '<script>toastr.error(\''.$_SESSION['ERROR_RETURN'].'\');</script>');
		unset($_SESSION['ERROR_RETURN']);
	}
	if( $_SESSION['GOOD_RETURN'] ){
		$TplClass->SetParam('error', '<script>toastr.success(\''.$_SESSION['GOOD_RETURN'].'\');</script>');
		unset($_SESSION['GOOD_RETURN']);
    }
   	
   	$result = $db->query("SELECT * FROM cms_settings WHERE id = 1 LIMIT 1");
   	while($data = $result->fetch_array()){
   		$SHORTNAME = $data['hotelname'];
   		$FACE = $data['facebook'];
   		$LOGO = $data['logo'];
       }
       
       $TplClass->AddTemplateHK("templates", "menu");
       
       $user_agent = $_SERVER['HTTP_USER_AGENT'];
       function getBrowser($user_agent){
       if(strpos($user_agent, 'MSIE') !== FALSE)
          return 'Internet explorer';
        elseif(strpos($user_agent, 'Edge') !== FALSE) //Microsoft Edge
          return 'Microsoft Edge';
        elseif(strpos($user_agent, 'Trident') !== FALSE) //IE 11
           return 'Internet explorer';
        elseif(strpos($user_agent, 'Opera Mini') !== FALSE)
          return "Opera Mini";
        elseif(strpos($user_agent, 'Opera') || strpos($user_agent, 'OPR') !== FALSE)
          return "Opera";
        elseif(strpos($user_agent, 'Firefox') !== FALSE)
          return 'Mozilla Firefox';
        elseif(strpos($user_agent, 'Chrome') !== FALSE)
          return 'Google Chrome';
        elseif(strpos($user_agent, 'Safari') !== FALSE)
          return "Safari";
        else
          return 'Otro';
       }
       function getPlatform($user_agent) {
        $plataformas = array(
           'Windows 10' => 'Windows NT 10.0+',
           'Windows 8.1' => 'Windows NT 6.3+',
           'Windows 8' => 'Windows NT 6.2+',
           'Windows 7' => 'Windows NT 6.1+',
           'Windows Vista' => 'Windows NT 6.0+',
           'Windows XP' => 'Windows NT 5.1+',
           'Windows 2003' => 'Windows NT 5.2+',
           'Windows' => 'Windows otros',
           'iPhone' => 'iPhone',
           'iPad' => 'iPad',
           'Mac OS X' => '(Mac OS X+)|(CFNetwork+)',
           'Mac otros' => 'Macintosh',
           'Android' => 'Android',
           'BlackBerry' => 'BlackBerry',
           'Linux' => 'Linux',
        );
        foreach($plataformas as $plataforma=>$pattern){
           if (eregi($pattern, $user_agent))
              return $plataforma;
        }
        return 'Otra';
     }

       $db->query("INSERT INTO cms_stats_admin (username, ip, value, time) VALUES ('".$user['username']."', '".$Functions->getRealIP()."', 'Entro al panel de administración desde <b>".getBrowser($user_agent)."</b>, usando la plataforma <b>".getPlatform($user_agent)."</b>', '".time()."')");
       
       $Max = time() - 1209600;
       $Min = time() - 2592000;
       
       $users_stats = $db->query("SELECT * FROM cms_stats WHERE time >= '".$Min."' AND time <= '".$Max."' ORDER BY time");
       $users_stats2 = $db->query("SELECT * FROM cms_stats");       
       $users_stats_reg = $db->query("SELECT * FROM users WHERE account_created >= '".$Min."' AND account_created <= '".$Max."' ORDER BY account_created");
       $users_stats_on = $db->query("SELECT * FROM users WHERE online = '1'");
    
   	ob_end_flush(); 
   ?>
<!--Main layout-->
<main>
<div class="container-fluid">

    <!--Section: Button icon-->
    <section>

        <!--Grid row-->
        <div class="row">

            <!--Grid column-->
            <div class="col-xl-3 col-md-6 mb-r">

                <!--Card-->
                <div class="card">

                    <!--Card Data-->
                    <div class="row mt-3">
                        <div class="col-md-5 col-5 text-left pl-4">
                            <a type="button" class="btn-floating btn-lg primary-color ml-4"><i class="fa fa-eye" aria-hidden="true"></i></a>
                        </div>

                        <div class="col-md-7 col-7 text-right pr-5">
                            <h5 class="ml-4 mt-4 mb-2 font-bold"><?php echo $users_stats2->num_rows; ?></h5>
                            <p class="font-small grey-text">Visitantes total</p>
                        </div>
                    </div>
                    <!--/.Card Data-->

                    <!--Card content-->
                    <div class="row my-3">
                        <div class="col-md-7 col-7 text-left pl-4">
                            <p class="font-small dark-grey-text font-up ml-4 font-bold">ESTE MES</p>
                        </div>

                        <div class="col-md-5 col-5 text-right pr-5">
                            <p class="font-small grey-text"><?php echo $users_stats->num_rows; ?></p>
                        </div>
                    </div>
                    <!--/.Card content-->

                </div>
                <!--/.Card-->

            </div>
            <!--Grid column-->

            <!--Grid column-->
            <div class="col-xl-3 col-md-6 mb-r">

                <!--Card-->
                <div class="card">

                    <!--Card Data-->
                    <div class="row mt-3">
                        <div class="col-md-5 col-5 text-left pl-4">
                            <a type="button" class="btn-floating btn-lg warning-color ml-4"><i class="fa fa-user" aria-hidden="true"></i></a>
                        </div>

                        <div class="col-md-7 col-7 text-right pr-5">
                            <h5 class="ml-4 mt-4 mb-2 font-bold"><?php echo $Functions->GetCount('users'); ?> </h5>
                            <p class="font-small grey-text">Registrados total</p>
                        </div>
                    </div>
                    <!--/.Card Data-->

                    <!--Card content-->
                    <div class="row my-3">
                        <div class="col-md-7 col-7 text-left pl-4">
                            <p class="font-small dark-grey-text font-up ml-4 font-bold">ESTE MES</p>
                        </div>

                        <div class="col-md-5 col-5 text-right pr-5">
                            <p class="font-small grey-text"><?php echo $users_stats_reg->num_rows; ?></p>
                        </div>
                    </div>
                    <!--/.Card content-->

                </div>
                <!--/.Card-->

            </div>
            <!--Grid column-->

            <!--Grid column-->
            <div class="col-xl-3 col-md-6 mb-r">

                <!--Card-->
                <div class="card">

                    <!--Card Data-->
                    <div class="row mt-3">
                        <div class="col-md-5 col-5 text-left pl-4">
                            <a type="button" class="btn-floating btn-lg light-blue lighten-1 ml-4"><i class="fa fa-plus" aria-hidden="true"></i></a>
                        </div>

                        <div class="col-md-7 col-7 text-right pr-5">
                            <h5 class="ml-4 mt-4 mb-2 font-bold"><?php echo $users_stats_on->num_rows; ?> </h5>
                            <p class="font-small grey-text">Usuarios online</p>
                        </div>
                    </div>
                    <!--/.Card Data-->

                    <!--Card content-->
                    <div class="row my-3">
                        <div class="col-md-7 col-7 text-left pl-4">
                            <p class="font-small dark-grey-text font-up ml-4 font-bold">TOTAL</p>
                        </div>

                        <div class="col-md-5 col-5 text-right pr-5">
                            <p class="font-small grey-text"><?php echo $users_stats_on->num_rows; ?></p>
                        </div>
                    </div>
                    <!--/.Card content-->

                </div>
                <!--/.Card-->

            </div>
            <!--Grid column-->

            <!--Grid column-->
            <div class="col-xl-3 col-md-6 mb-r">

                <!--Card-->
                <div class="card">

                    <!--Card Data-->
                    <div class="row mt-3">
                        <div class="col-md-5 col-5 text-left pl-4">
                            <a type="button" class="btn-floating btn-lg red accent-2 ml-4"><i class="fa fa-user-times" aria-hidden="true"></i></a>
                        </div>

                        <div class="col-md-7 col-7 text-right pr-5">
                            <h5 class="ml-4 mt-4 mb-2 font-bold"><?php echo $Functions->GetCount('bans'); ?></h5>
                            <p class="font-small grey-text" style="width:110%; word-break: break-all; word-wrap: break-word;">Usuarios baneados</p>
                        </div>
                    </div>
                    <!--/.Card Data-->

                    <!--Card content-->
                    <div class="row my-3">
                        <div class="col-md-7 col-7 text-left pl-4">
                            <p class="font-small dark-grey-text font-up ml-4 font-bold">TOTAL</p>
                        </div>

                        <div class="col-md-5 col-5 text-right pr-5">
                            <p class="font-small grey-text"><?php echo $Functions->GetCount('bans'); ?></p>
                        </div>
                    </div>
                    <!--/.Card content-->

                </div>
                <!--/.Card-->

            </div>
            <!--Grid column-->

        </div>
        <!--Grid row-->

    </section>
    <!--/Section: Button icon-->

    <div style="height: 5px"></div>

    <!--Section: Analytical panel-->
    <section class="mb-5">

        <!--Card-->
        <div class="card card-cascade narrower">

            <!--Section: Chart-->
            <section>

                <!--Grid row-->
                <div class="row">

                    <!--Grid column-->
                    <div class="col-xl-5 col-md-12 mr-0">

                        <!--Card image-->
                        <div class="view gradient-card-header light-blue lighten-1">
                            <h4 class="h4-responsive mb-0 font-bold">Tráfico</h4>
                        </div>
                        <!--/Card image-->

                        <!--Card content-->
                        <div class="card-body pb-0">

                            <!--Panel data-->
                            <div class="row card-body pt-3">

                                <!--First column-->
                                <div class="col-md-12">

                                    <!--Date select-->
                                    <p class="font-small dark-grey-text font-up ml-4 font-bold">
                                    En el Yezz Panel, ahora podrás ver un tráfico de los usuarios registrados, 
                                    como ven en el gráfico de al lado se mostrará el total de los usuarios 
                                    registrados. El gráfico se divide en 5 partes: Hoy, Ayer, Esta semana, Semana anterior y Este mes. <br><br><br><h4>- GRACIAS FORBI</h4></p>

                                </div>
                                <!--/First column-->

                            </div>
                            <!--/Panel data-->

                        </div>
                        <!--/.Card content-->

                    </div>
                    <!--Grid column-->

                    <!--Grid column-->
                    <div class="col-xl-7 col-md-12 mb-r">

                        <!--Card image-->
                        <div class="view gradient-card-header white">

                            <!-- Chart -->
                            <canvas id="barChart"></canvas>

                        </div>
                        <!--/Card image-->

                    </div>
                    <!--Grid column-->

                </div>
                <!--Grid row-->

            </section>
            <!--Section: Chart-->

        </div>
        <!--/.Card-->

    </section>
    <!--Section: Analytical panel-->

    <!-- Section: data tables -->
    <section class="section">

        <div class="row">
            <div class="col-md-12 col-lg-4 ">

                <div class="card mb-r">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table large-header">
                                <thead>
                                    <tr>
                                        <th class="font-bold dark-grey-text"><strong>SO</strong></th>
                                        <th class="font-bold dark-grey-text"><strong>Visitas</strong></th>
                                        <th class="font-bold dark-grey-text"><strong>CRACK</strong></th>
                                    </tr>
                                </thead>
                                <tbody>

                    <?php global $db;
					$sql = $db->query("SELECT count(so), so FROM cms_stats GROUP BY so ORDER BY count(so) DESC LIMIT 5");
					if($sql->num_rows > 0){
					while($so = $sql->fetch_array()){

						$socount = $db->query("SELECT * FROM cms_stats WHERE so = '".$so['so']."'");
                   ?>
                                <tr>
                                    <td><?php echo $so['so']; ?></td>
                                    <td><?php echo $socount->num_rows; ?></td>
                                    <td>FORBI</td>
                                </tr>
                                
                                <?php }} ?>

                                </tbody>
                            </table>
                        </div>

                        <button class="btn-flat grey lighten-3 btn-rounded waves-effect float-right font-bold dark-grey-text">View full report</button>

                    </div>

                </div>

            </div>

            <div class="col-lg-8 col-md-12">
            
                <div class="card mb-r">
                    <div class="card-body">
                        <table class="table large-header">
                            <thead>
                                <tr>
                                    <th class="font-bold dark-grey-text"><strong>Navegador</strong></th>
                                    <th class="font-bold dark-grey-text"><strong>Visitas</strong></th>
                                    <th class="font-bold dark-grey-text"><strong>CRACK</strong></th>
                                </tr>
                            </thead>
                            <tbody>

                            <?php global $db;
					$sql = $db->query("SELECT count(navegador), navegador FROM cms_stats GROUP BY navegador ORDER BY count(navegador) DESC LIMIT 5");
					if($sql->num_rows > 0){
					while($navegador = $sql->fetch_array()){

						$navegadorcount = $db->query("SELECT * FROM cms_stats WHERE navegador = '".$navegador['navegador']."'");
                   ?>
                                <tr>
                                    <td><?php echo $navegador['navegador']; ?></td>
                                    <td><?php echo $navegadorcount->num_rows; ?></td>
                                    <td>HLATINO.NET / FORBI</td>
                                </tr>
                                
                                <?php }} ?>

                            </tbody>
                        </table>

                        <button class="btn-flat grey lighten-3 btn-rounded waves-effect font-bold dark-grey-text float-right">View full report</button>

                    </div>

                </div>

            </div>
        </div>

        <div class="row">

                <!-- First column -->

                <div class="col-lg-6 col-md-12">

                    <!--Panel-->
                    <div class="card mb-r">
                        <div class="card-header white-text primary-color">
                        Últimos usuarios en registrarse   
                        </div>
                        <div class="card-body">

                            <table class="table no-header mt-1">
                                <tbody>
                                <?php global $db;
					$sql = $db->query("SELECT * FROM users ORDER BY id DESC LIMIT 5");
					if($sql->num_rows > 0){
					while($usersinfo = $sql->fetch_array()){
                   ?>
                                    <tr>
                                        <td><?php echo $usersinfo['username']; ?></td>
                                        <td><?php echo $Functions->FilterText($usersinfo['ip_reg']); ?></td>
                                        <td class="hour"><small><span class="grey-text float-right"><i class="fa fa-clock-o" aria-hidden="true"></i> <?php echo $Functions->GetLastFace($usersinfo['account_created']); ?></span></small></td>
                                        <td>
                                                            <a class="blue-text" data-toggle="tooltip" data-placement="top" title="Ver perfil" href="<?php echo PATH ?>/profile/<?php echo $usersinfo['username']; ?>" target="_blank"><i class="fa fa-user"></i></a>
                                                        </td>
                                                        </tr>
                                    <?php }} ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!--/.Panel-->

                </div>

                <!-- /.First column -->

                <div class="col-lg-6 col-md-12">

                    <!--Panel-->
                    <div class="card mb-r">
                    <div class="card-header white-text primary-color">
                    Miembros del equipo ausentes
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">

                            <table class="table">

                                <tbody>
                                <?php global $db;
					$sql = $db->query("SELECT * FROM cms_aus ORDER BY id DESC LIMIT 5");
					if($sql->num_rows > 0){
					while($usersinfo = $sql->fetch_array()){
                   ?>
                                    <tr>
                                        <td><span class="badge warning-color">Ausente</span></td>
                                        <td><?php echo $usersinfo['username']; ?></td>
                                        <td>Desde <b><?php echo $usersinfo['desde']; ?></b> hasta <b><?php echo $usersinfo['hasta']; ?><b/></td>
                                        <td class="hour"><small><span class="grey-text"><i class="fa fa-clock-o" aria-hidden="true"></i> <?php echo $Functions->GetLastFace($usersinfo['time']); ?></span></small></td>
                                    </tr>
                                    <?php }} ?>
                                </tbody>
                            </table>

                        </div>

                    </div>
                </div>

                <!-- /.Panel -->

                    <!-- /.Second column -->

                </div>

                <!-- /.Second row -->
            </div>

    </section>
    <!-- /.Section: data tables -->



    

</div>
</main>
<!--Main layout-->
<!--Main layout-->
<?php
   //COLUMNA FOOTER
   $TplClass->AddTemplateHK("templates", "footer");
   ?>

<?php
$hoyMax = time();
$hoyMin = time() - 86400;

$ayerMax = time() - 86400;
$ayerMin = time() - 172800;

$thissMax = time() - 172800;
$thissMin = time() - 604800;

$seanMax = time() - 604800;
$seanMin = time() - 1209600;

$mesMax = time() - 1209600;
$mesMin = time() - 2592000;

$result = $db->query("SELECT * FROM users WHERE account_created >= '".$hoyMin."' AND account_created <= '".$hoyMax."' ORDER BY account_created");
$result2 = $db->query("SELECT * FROM users WHERE account_created >= '".$ayerMin."' AND account_created <= '".$ayerMax."' ORDER BY account_created");
$result3 = $db->query("SELECT * FROM users WHERE account_created >= '".$thissMin."' AND account_created <= '".$thissMax."' ORDER BY account_created");
$result4 = $db->query("SELECT * FROM users WHERE account_created >= '".$seanMin."' AND account_created <= '".$seanMax."' ORDER BY account_created");
$result5 = $db->query("SELECT * FROM users WHERE account_created >= '".$mesMin."' AND account_created <= '".$mesMax."' ORDER BY account_created");

?>
        
    <!-- Charts -->
    <script>
        // Small chart
        $(function () {
            $('.min-chart#chart-sales').easyPieChart({
                barColor: "#4285F4",
                onStep: function (from, to, percent) {
                    $(this.el).find('.percent').text(Math.round(percent));
                }
            });
        });



        //bar
        var ctxB = document.getElementById("barChart").getContext('2d');
        var myBarChart = new Chart(ctxB, {
            type: 'bar',
            data: {
                labels: ["Hoy", "Ayer", "Esta semana", "Semana anterior", "Este mes"],
                datasets: [{
                    label: 'Ususarios registrados',
                    data: ['<?php echo $result->num_rows; ?>', '<?php echo $result2->num_rows; ?>', '<?php echo $result3->num_rows; ?>', '<?php echo $result4->num_rows; ?>', '<?php echo $result5->num_rows; ?>'],
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.3)',
                        'rgba(41, 182, 246, 0.3)',
                        'rgba(255, 187, 51, 0.3)',
                        'rgba(66, 133, 244, 0.3)',
                        'rgba(153, 102, 255, 0.3)',

                    ],
                    borderColor: [
                        'rgba(255,99,132,1)',
                        'rgba(41, 182, 246, 1)',
                        'rgba(255, 187, 51, 1)',
                        'rgba(66, 133, 244, 1)',
                        'rgba(153, 102, 255, 1)',

                    ],
                    borderWidth: 2
                }]
            },
            optionss: {
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero: true
                        }
                    }]
                }
            }
        });

        </script>

