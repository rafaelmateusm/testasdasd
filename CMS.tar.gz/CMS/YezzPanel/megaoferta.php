<?php
ob_start();
	require_once '../global.php';
	$TplClass->SetParam('title', 'Mejorar la Mega oferta');
	$TplClass->SetParam('zone', 'Mejorar la Mega Oferta');
	$Functions->LoggedHk("true");
	$Functions->LoggedHkADMIN("true");
	
	$users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
	$user = $users->fetch_array();

	$TplClass->SetAll();
	if( $_SESSION['ERROR_RETURN'] ){
		$TplClass->SetParam('error', '<script>toastr.error(\''.$_SESSION['ERROR_RETURN'].'\');</script>');
		unset($_SESSION['ERROR_RETURN']);
	}
	if( $_SESSION['GOOD_RETURN'] ){
		$TplClass->SetParam('error', '<script>toastr.success(\''.$_SESSION['GOOD_RETURN'].'\');</script>');
		unset($_SESSION['GOOD_RETURN']);
	}
	$result = $db->query("SELECT * FROM cms_settings WHERE id = 1 LIMIT 1");
	while($data = $result->fetch_array()){
		$SHORTNAME = $data['hotelname'];
		$FACE = $data['facebook'];
		$LOGO = $data['logo'];
	}
	if(isset($_POST['iconfig'])){
		if(empty($_POST['price']) || empty($_POST['limit']) || empty($_POST['time']) || empty($_POST['title']) || empty($_POST['description']) || empty($_POST['items']) || empty($_POST['active']) || empty($_POST['expire_time'])){
			$_SESSION['ERROR_RETURN'] = "Has dejado campos vac&iacute;os";
			header("LOCATION: ". HK ."mega-oferta");
		}else{

            $db->query("UPDATE targeted_offers SET price = '". $Functions->FilterText($_POST['price']) ."', money_type = '". $Functions->FilterText($_POST['money_type']) ."', time = '". $Functions->FilterText($_POST['time']) ."', title = '". $Functions->FilterText($_POST['title']) ."', description = '". $_POST['description'] ."', image = '". $Functions->FilterText($_POST['image']) ."', icon = '". $Functions->FilterText($_POST['icon']) ."', items = '". $Functions->FilterText($_POST['items']) ."', active = '". $Functions->FilterText($_POST['active']) ."', expire_time = '". $Functions->FilterText($_POST['expire_time']) ."' WHERE id = '1'");

            $db->query("UPDATE targeted_offers SET `limit` = '". $Functions->FilterText($_POST['limit']) ."' WHERE id = '1'");
            
			$db->query("INSERT INTO cms_stafflogs (username, action, message, rank, userid, timestamp) VALUES ('". $user['username'] ."','Mega oferta del Hotel', 'Ha Actualizado la Mega oferta del Hotel', '". $user['rank'] ."', '". $user['id'] ."', '".date("Y-m-d ")."')");
			
				$_SESSION['GOOD_RETURN'] = "Mega oferta actualizada";
				header("LOCATION: ". HK ."mega-oferta");
			
		}
    }
    
    $targeted_offerss = $db->query("SELECT * FROM targeted_offers WHERE id = '1'");
    $megaoferta = $targeted_offerss->fetch_array();
    
	$TplClass->AddTemplateHK("templates", "menu");
	ob_end_flush(); 
?>

 <!--Main layout-->
 <main>
 <div class="container-fluid">

     <!--Section: Inputs-->
     <section class="section card mb-5">

     <div class="card-body"><br><br>
         <div class="form-header blue accent-1">
                                    <h3><i class="fa fa-cog"></i> Configuraci&oacute;n Mega Oferta</h3>
                                </div>

             <h5 class="pb-5">Configura aquí la mega oferta del Hotel </h5>

             <form action="" method="post">
             <!--Grid row-->
             <div class="row text-left">

                 <!--Grid column-->
                 <div class="col-md-6 mb-r">

                     <!--Email validation-->
                     <div class="md-form">
                         <i class="fa fa-usd prefix"></i>
                         <input type="text" id="form9" name="price" class="form-control validate" value="<?php echo $megaoferta['price']; ?>">
                         <label for="form9" data-error="wrong" data-success="right">Lado izquierdo: créditos. -- Lado derecho: duckets o diamantes</label>
                     </div>

                 </div>
                 <!--Grid column-->

                 <!--Grid column-->
                 <div class="col-md-6 mb-r">
                 <div class="md-form">
                 <select class="mdb-select colorful-select dropdown-info mx-2" name="money_type" style="width:513%;">
                     <option value="" disabled selected>Moneda</option>
                     <?php if($megaoferta['money_type'] == 'duckets'){
                             $skere2 = 'selected';
                            }else{
                                $skere2 = '';}

                                if($megaoferta['money_type'] == 'diamonds'){
                                    $skere22 = 'selected';
                                   }else{
                                       $skere22 = '';}
                             ?>
                     <option value="duckets" <?php echo $skere2; ?>>Duckets</option>
                     <option value="diamonds" <?php echo $skere22; ?>>Diamantes</option>
                  </select>

                     <!--Password validation-->
                     
                         
                     </div>

                 </div>
                 <!--Grid column-->

             </div>
             <!--Grid row-->

                          <!--Grid row-->
                          <div class="row text-left">

                 <!--Grid column-->
                 <div class="col-md-6 mb-r">

                     <!--Password validation-->
                     <div class="md-form">
                         <i class="fa fa-diamond prefix"></i>
                         <input type="text" id="form10" class="form-control validate" name="limit" value="<?php echo $megaoferta['limit']; ?>">
                         <label for="form10" data-error="wrong" data-success="right">Límite de compra</label>
                     </div>

                 </div>
                 <!--Grid column-->

                 <!--Grid column-->
                 <div class="col-md-6 mb-r">

                     <!--Email validation-->
                     <div class="md-form">
                         <i class="fa fa-home prefix"></i>
                         <input type="text" id="form9" class="form-control validate" name="time" value="<?php echo $megaoferta['time']; ?>">
                         <label for="form9" data-error="wrong" data-success="right">NO TOCAR</label>
                     </div>

                 </div>
                 <!--Grid column-->

             </div>
             <!--Grid row-->

             <!--Grid row-->
             <div class="row text-left">

                 <!--Grid column-->
                 <div class="col-md-6 mb-r">

                     <!--Password validation-->
                     <div class="md-form">
                         <i class="fa fa-male prefix"></i>
                         <input type="text" id="form10" class="form-control validate" name="title" value="<?php echo $megaoferta['title']; ?>">
                         <label for="form10" data-error="wrong" data-success="right">Titulo</label>
                     </div>

                 </div>
                 <!--Grid column-->

                 <!--Grid column-->
                 <div class="col-md-6 mb-r">

                 <div class="md-form mb-0">
                           <textarea style="height: 25%;" type="text" id="form447" class="md-textarea" name="description"><?php echo $megaoferta['description']; ?></textarea>
                           <label for="form447">Descripción</label>
                        </div>

                 </div>
                 <!--Grid column-->

             </div>




                          <!--Grid row-->
                          <div class="row text-left">

                 <!--Grid column-->
                 <div class="col-md-6 mb-r">

                     <!--Password validation-->
                     <div class="md-form">
                         <i class="fa fa-diamond prefix"></i>
                         <input type="text" id="form10" class="form-control validate" name="image" value="<?php echo $megaoferta['image']; ?>">
                         <label for="form10" data-error="wrong" data-success="right">Imagen grande</label>
                     </div>

                 </div>
                 <!--Grid column-->

                 <!--Grid column-->
                 <div class="col-md-6 mb-r">

                     <!--Email validation-->
                     <div class="md-form">
                         <i class="fa fa-home prefix"></i>
                         <input type="text" id="form9" class="form-control validate" name="icon" value="<?php echo $megaoferta['icon']; ?>">
                         <label for="form9" data-error="wrong" data-success="right">Icono de la Oferta</label>
                     </div>

                 </div>
                 <!--Grid column-->

             </div>
             <!--Grid row-->


                                       <!--Grid row-->
                                       <div class="row text-left">

<!--Grid column-->
<div class="col-md-6 mb-r">

    <!--Password validation-->
    <div class="md-form">
        <i class="fa fa-diamond prefix"></i>
        <input type="text" id="form10" class="form-control validate" name="items" value="<?php echo $megaoferta['items']; ?>">
        <label for="form10" data-error="wrong" data-success="right">Para agregar más de un furni tienes que poner -"item,102;"-</label>
    </div>

</div>
<!--Grid column-->

<!--Grid column-->
<div class="col-md-6 mb-r">

    <!--Email validation-->
    <div class="md-form">
    <select class="mdb-select colorful-select dropdown-info mx-2" name="active" style="width:513%;">
    <option value="" disabled selected>Moneda</option>
    <?php if($megaoferta['active'] == 'false'){
            $skere = 'selected';
           }else{
               $skere = '';}

               if($megaoferta['active'] == 'true'){
                   $skere1 = 'selected';
                  }else{
                      $skere1 = '';}
            ?>
    <option value="true" <?php echo $skere1; ?>>Activa</option>
    <option value="false" <?php echo $skere; ?>>Inactiva </option>
 </select>

    </div>

</div>
<!--Grid column-->

<div class="col-md-6 mb-r">

    <!--Password validation-->
    <div class="md-form">
        <i class="fa fa-diamond prefix"></i>
        <input type="text" id="form10" class="form-control validate" name="expire_time" value="<?php echo $megaoferta['expire_time']; ?>">
        <label for="form10" data-error="wrong" data-success="right">Tiempo en que termina la oferta"-</label>
    </div>

</div>
</div>
<!--Grid row-->

             <!--Grid row-->
             <center><input type="submit" name="iconfig" class="btn btn-primary waves-effect waves-light" style="width:100%;"></center>
          </div>
          </form>
     </section>
     <!--Section: Inputs-->

     
 </div>
</main>
<!--Main layout-->

   <?php
   //COLUMNA FOOTER
   $TplClass->AddTemplateHK("templates", "footer");
   ?>
