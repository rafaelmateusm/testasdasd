<?php
   ob_start();
   	require_once '../global.php';
   	$TplClass->SetParam('title', 'Logs de la cms');
   	$TplClass->SetParam('zone', 'Logs de la cms');
       $Functions->LoggedHk("true");
       $Functions->LoggedHkADMIN("true");
          
   	$users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
   	$user = $users->fetch_array();
   	$action = $Functions->FilterText($_GET['action']);
    $id = $Functions->FilterText($_GET['id']);
   
   
   	$TplClass->SetAll();
       if( $_SESSION['ERROR_RETURN'] ){
   $TplClass->SetParam('error', '<script>toastr.error(\''.$_SESSION['ERROR_RETURN'].'\');</script>');
   unset($_SESSION['ERROR_RETURN']);
   }
   if( $_SESSION['GOOD_RETURN'] ){
   $TplClass->SetParam('error', '<script>toastr.success(\''.$_SESSION['GOOD_RETURN'].'\');</script>');
   unset($_SESSION['GOOD_RETURN']);
    }
   	$result = $db->query("SELECT * FROM cms_settings WHERE id = 1 LIMIT 1");
   	$data = $result->fetch_array();
   	$SHORTNAME = $data['hotelname'];
   	$FACE = $data['facebook'];
    $LOGO = $data['logo'];
       

   	$TplClass->AddTemplateHK("templates", "menu");
   	ob_end_flush(); 
   ?>
<!--Main layout-->
<main>
   <div class="container-fluid">
   <div style="height: 5px"></div>
   <section class="mb-5" >


   <div class="row">
                            <div class="col-md-12 mb-1">
                                <!-- Tabs -->
                                <!-- Nav tabs -->
                                <div class="tabs-wrapper">
                                    <ul class="nav classic-tabs tabs-primary primary-color" role="tablist">
                                        <li class="nav-item">
                                            <a class="nav-link waves-light waves-effect waves-light active" data-toggle="tab" href="#panel83" role="tab" aria-selected="true">Logs de la CMS</a>
                                        </li>
                                    </ul>
                                </div>
                                <!-- Tab panels -->
                                <div class="tab-content card">
                                    <!--Panel 1-->
                                    <div class="tab-pane fade active show" id="panel83" role="tabpanel">
                                        <div class="table-responsive">
                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th>Rango</th>
                                                        <th>Usuario</th>
                                                        <th>Acción</th>
                                                        <th>Value</th>
                                                        <th>Tiempo</th>
                                                    </tr>
                                                </thead>
                                                <tbody>


                                                <?php
   $CantidadMostrar=15;
   
           $compag         =(int)(!isset($_GET['pag'])) ? 1 : $_GET['pag']; 
   	$TotalReg       =$db->query("SELECT * FROM cms_stafflogs");
   	
   	$TotalRegistro  =ceil($TotalReg->num_rows/$CantidadMostrar);
   	$consulta = $db->query("SELECT * FROM cms_stafflogs ORDER BY id DESC LIMIT ".(($compag-1)*$CantidadMostrar)." , ".$CantidadMostrar);
   	
   	while($lista = $consulta->fetch_array()){
                    echo '<tr><th scope="row">'.$lista['rank'].'</th>
                    <td><a href="/profile/'.$lista['username'].'" target="_blank">'.$lista['username'].'</a></td>    
                    <td>'.$lista['action'].'</td>                
                    <td>'.$lista['message'].'</td>
                    <td>'.$lista['timestamp'].'</td>
                    </tr>';
   
   	}
     
   ?>
                              
                                              </tbody>
                                            </table>
                                            
                                        </div>
                                        <nav>
                                <ul class="pagination pg-blue">
                                        <?php
   	$IncrimentNum =(($compag +1)<=$TotalRegistro)?($compag +1):1;
     	$DecrementNum =(($compag -1))<1?1:($compag -1);
     
        $Desde=$compag-(ceil($CantidadMostrar/2)-1);
        $Hasta=$compag+(ceil($CantidadMostrar/2)-1);
        
        $Desde=($Desde<1)?1: $Desde;
        $Hasta=($Hasta<$CantidadMostrar)?$CantidadMostrar:$Hasta;
        for($i=$Desde; $i<=$Hasta;$i++){
        	if($i<=$TotalRegistro){
        	  if($i==$compag){
              echo '<li class="page-item active"><a class="page-link">'.$i.'</a></li>';
        	  }else {
        	  	echo '<li class="page-item"><a class="page-link" href="?pag='.$i.'">'.$i.'</a></li>';
        	  }     		
        	}
        }
   	echo "";
     
     
   ?></ul>
   </nav>
                                    </div>
                                    <!--/.Panel 1-->
 
                                </div>
                                <!-- /.Tabs -->
                            </div>
                        </div>
                        

   </section>
   <!--Section: Table-->
   </div>
   <!--/.Card-->
   <!--Section: Main panel-->
</main>
<!--Main layout-->
<?php
   //COLUMNA FOOTER
   $TplClass->AddTemplateHK("templates", "footer");
   ?>