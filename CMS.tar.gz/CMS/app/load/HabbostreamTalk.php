<?php
   ob_start();
   require_once '../../global.php';
   ob_end_flush();	
   
   $users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
   $user = $users->fetch_array();
   
   $userid = $Functions->FilterText($_GET['userid']);
   $type = $Functions->FilterText($_GET['type']);
   
   $userss = $db->query("SELECT * FROM users WHERE id = '".$userid."'");
   $userinfo = $userss->fetch_array();
   
   
   
   
   ?>
<?php if($type == "support" && !empty($userid)){ ?>
<div id="thechat">
   <div id="stream19">
      <div onclick="CloseChat('<?php echo $userid; ?>')" id="stream20"></div>
      <div id="stream21">Discusión de soporte</div>
      <div id="stream22" style="background:url(/app/assets/img/soporte.png);"></div>
   </div>
   <div id="chatbox">
      <div class="chatscroll" id="chatinlive<?php echo $userid; ?>">
         <?php global $db;
            $rticket = $db->query("SELECT * FROM cms_tickets WHERE id = '".$userid."'");
            while($ticket = $rticket->fetch_array()){
            		
                         ?>
         <div id="stream26">
            <a place="<?php echo $user['username']; ?>" href="profile/<?php echo $user['username']; ?>">
               <div id="stream27" style="background:url(<?php echo AVATARIMAGE . $user['look']; ?>);"></div>
            </a>
            <div id="stream29"></div>
            <div id="stream30">
               <div id="motto">
                  <div id="stream33"></div>
                  <b><?php echo $user['username']; ?></b>: <?php echo $Functions->FilterText2($ticket['content']); ?> 
               </div>
               <div id="stream31">
                  <?php echo $Functions->GetLastFace($ticket['time']); ?> 
               </div>
            </div>
            <?php if($ticket['visto'] == 0){ ?> 
            <div class="chatvue"></div>
            <?php }else{ ?>
            <div class="chatnovue"></div>
            <?php } ?>
         </div>
         <?php } ?>
         <?php global $db;
            $rticket = $db->query("SELECT * FROM cms_tickets WHERE posted_in = '".$userid."' ORDER BY id ASC");
            if($rticket->num_rows > 0){
            while($ticket = $rticket->fetch_array()){
            	
            	$userinfo = $db->query("SELECT * FROM users WHERE username = '".$ticket['username']."'");
            	while($userrinf = $userinfo->fetch_array()){
            		
            		if($ticket['username'] == $user['username']){
                         ?>
         <div id="stream26">
            <a place="<?php echo $user['username']; ?>" href="profile/<?php echo $user['username']; ?>">
               <div id="stream27" style="background:url(<?php echo AVATARIMAGE . $user['look']; ?>);"></div>
            </a>
            <div id="stream29"></div>
            <div id="stream30">
               <div id="motto">
                  <div id="stream33"></div>
                  <b><?php echo $user['username']; ?></b>: <?php echo $Functions->FilterText2($ticket['content']); ?> 
               </div>
               <div id="stream31">
                  <?php echo $Functions->GetLastFace($ticket['time']); ?> 
               </div>
            </div>
            <?php if($ticket['visto'] == 0){ ?> 
            <div class="chatvue"></div>
            <?php }else{ ?>
            <div class="chatnovue"></div>
            <?php } ?>
         </div>
         <?php }elseif($ticket['type'] == 'respuestaticket'){ ?>
         <div id="stream26">
            <a place="<?php echo $userrinf['username']; ?>" href="/profile/<?php echo $userrinf['username']; ?>">
               <div id="stream28" style="background:url(<?php echo AVATARIMAGE . $userrinf['look']; ?>&direction=4&head_direction=4);"></div>
            </a>
            <div id="stream29"></div>
            <div id="stream35">
               <div id="motto">
                  <div id="stream34"></div>
                  <b><?php echo $userrinf['username']; ?></b>: <?php echo $Functions->FilterText2($ticket['content']); ?> 
               </div>
               <div id="stream31">
                  <?php echo $Functions->GetLastFace($ticket['time']); ?> 
               </div>
            </div>
         </div>
         <?php }}}} ?>
      </div>
   </div>
   <?php global $db;
      $rrticket = $db->query("SELECT * FROM cms_tickets WHERE id = '".$userid."'");
      $ticket2 = $rrticket->fetch_array();
      if($ticket2['abierto'] == 0){
      
      		
                   ?>
   <div style="visibility: visible;" id="stream46">Esperando al administrador de soporte...</div>
   <?php }else{ ?>
   <div style="" id="stream46">Esperando al administrador de soporte...</div>
   <?php } ?>
   <div style="display:none;" id="run">run</div>
   <div style="display:none;" id="chatmyid"><?php echo $userid; ?></div>
   <div style="display:none;" id="chatmypseudo"><?php echo $user['username']; ?></div>
   <div style="display:none;" id="chatmyavatar"><?php echo AVATARIMAGE . $user['look']; ?>&gesture=sml</div>
   <div id="motto">
      <div id="editeurchat" contenteditable="">Escribe algo...</div>
   </div>
   <div id="sendchat" onclick="SupportSendMsg('<?php echo $userid; ?>','<?php echo AVATARIMAGE . $user['look']; ?>','<?php echo $user['username']; ?>')">
      Enviar
   </div>
</div>
<?php }else{ $db->query("UPDATE cms_message SET visto = '1' WHERE from_id = '".$userid."' AND for_id = '".$user['id']."'"); ?>
<div id="chatemojishelp">
   <div id="stream38" onclick="CloseHelpChat();"><u>Cerrar</u></div>
</div>
<div id="thechat">
   <div id="stream19">
      <div onclick="CloseChat('<?php echo $userid; ?>')" id="stream20"></div>
      <div id="stream21">Chatear con <b><?php echo $userinfo['username']; ?></b></div>
      <div id="stream22" style="background:url(<?php echo AVATARIMAGE . $userinfo['look']; ?>&direction=4&head_direction=4&size=n&headonly=1"></div>
   </div>
   <div id="chatbox">
      <div onclick="OpenSupport('user','app/load/HelpPage.php?page=user&userid=<?php echo $userid; ?>')" id="stream40">
         <div id="stream41"></div>
         <div style="position:absolute;left:50px;top:14px;color:rgb(70,70,70);font-size:125%;">Informe habbo</div>
      </div>
      <div id="stream23">
         <div id="stream24"></div>
         <div id="stream25">
            <b>
               Habbo Staff
               <div id="stream39" onclick="OpenHelpChat();"><u>Ver la guía de emojis</u></div>
            </b>
            <br>Atención, los mensajes son observados muy de cerca por los moderadores. ¡si abusas serás castigado/a!
         </div>
      </div>
      <div class="chatscroll" id="chatinlive<?php echo $userid; ?>">
         <?php 	global $db;
            $result = $db->query("SELECT * FROM cms_message WHERE for_id = '".$userid."' AND from_id = '".$user['id']."' OR from_id = '".$userid."' AND for_id = '".$user['id']."' ORDER BY id ASC");
            while($data = $result->fetch_array()){
              ?>
			  <?php if($data['time'] >= time() - 864000){ ?> 
         <?php if($data['from_id'] == $user['id']){ ?> 
         <div id="stream26">
            <a place="<?php echo $user['username']; ?>" href="/profile/<?php echo $user['username']; ?>">
               <div id="stream27" style="background:url(<?php echo AVATARIMAGE . $user['look']; ?>);"></div>
            </a>
            <div id="stream29"></div>
            <div id="stream30">
               <div id="motto">
                  <div id="stream33"></div>
                  <b><?php echo $user['username']; ?></b>: <?php echo $Functions->FilterText($data['message']); ?> 
               </div>
               <div id="stream31">
                  <?php echo $Functions->GetLastFace($data['time']); ?> 
               </div>
            </div>
            <?php $result2 = $db->query("SELECT * FROM cms_message WHERE id = '".$data['id']."'");
               $data2 = $result2->fetch_array();
               
               if($data2['visto'] == 0){ ?> 
            <div class="chatvue"></div>
            <?php }else{ ?>
            <div class="chatnovue"></div>
            <?php } ?>
         </div>
         <?php }else{ ?>
         <div id="stream26">
            <a place="<?php echo $userinfo['username']; ?>" href="/profile/<?php echo $userinfo['username']; ?>">
               <div id="stream28" style="background:url(<?php echo AVATARIMAGE . $userinfo['look']; ?>&direction=4&head_direction=4);"></div>
            </a>
            <div id="stream29"></div>
            <div id="stream35">
               <div id="motto">
                  <div id="stream34"></div>
                  <b><?php echo $userinfo['username']; ?></b>: <?php echo $Functions->FilterText($data['message']); ?> 
               </div>
               <div id="stream31">
                  <?php echo $Functions->GetLastFace($data['time']); ?> 
               </div>
            </div>
         </div>
         <?php }}else{}} ?>
      </div>
   </div>
   <div style="display:none;" id="run">run</div>
   <div style="display:none;" id="chatmyid"><?php echo $userid; ?></div>
   <div style="display:none;" id="chatmypseudo"><?php echo $user['username']; ?></div>
   <div style="display:none;" id="chatmyavatar"><?php echo AVATARIMAGE . $user['look']; ?>&gesture=sml</div>
   <div style="display:none;" id="chattype">normal</div>
   <div id="motto">
      <div class="editeurchat" id="editeurchat" contenteditable="">Escribe algo...</div>
   </div>
   <div id="sendchat" onclick="SendMsg('<?php echo $userid; ?>','<?php echo AVATARIMAGE . $user['look']; ?>','<?php echo $user['username']; ?>', 'normal')">
      Enviar
   </div>
</div>
<?php } ?>