<?php
   require_once '../../global.php';
   
     //HOTEL CONFIG
   $result2 = $db->query("SELECT * FROM cms_settings WHERE id = 1 LIMIT 1");
   $yezz = $result2->fetch_array();
   //END HOTEL CONFIG
   
   
     $users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
     $user = $users->fetch_array();
   ?>
<div id="support" style="display: block;">
   <div onclick="CloseSupport()" id="fermeture"></div>
   <div id="footer30">
      <div id="footer31">¿Necesita ayuda? </div>
      <div onclick="LoadPageSupport('/app/load/HelpIndex.php','¿Necesita ayuda?')" id="footer36"></div>
      <div id="footer23">
         <div id="footer32"></div>
         <div id="footer33">Bienvenido al Centro de ayuda de <?php echo $yezz['hotelname']; ?>, aquí podrá contactar al personal para hacer una petición de ayuda o informar todo tipo de cosas. Comience por elegir su categoría.</div>
         <div class="end"></div>
         <div id="helpmenu">
            <div onclick="LoadPageSupport('app/load/HelpCategory.php','Las llaves del juego')" id="footer34">Necesito ayuda
               cualquier cosa
            </div>
            <div onclick="LoadPageSupport('app/load/HelpSupport.php','Contacto de soporte')" id="footer34">Contacto de soporte</div>
            <div id="footer35">¿Moderación en <?php echo $yezz['hotelname']; ?>? </div>
         </div>
         <img style="width:100%;" draggable="false" oncontextmenu="return false" src="app/assets/img/moderation.png">
      </div>
   </div>
</div>