<?php
   ob_start();
   require_once '../../global.php';
   
      $users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
      $user = $users->fetch_array();
   
      $userid = $Functions->FilterText($_GET['userid']);
   
      $ruser = $db->query("SELECT * FROM users WHERE id = '".$userid."'");
      $userinfo = $ruser->fetch_array();
   
   $resultview = $db->query("SELECT * FROM cms_stories ORDER BY id DESC LIMIT 1");
                 
                    $view = $resultview->fetch_array();
   				 
   				 $result2 = $db->query("SELECT * FROM cms_stories WHERE user_id = '".$userid."'");
   
   				 if($result2->num_rows > 0){
   ?>
<div id="rydHSG45s" style="transform: scale(1); display: block; transition: 0.3s;">
   <div onclick="fghjk()" id="stories7"></div>
   <script>
      var currentIndex = 0;
      var ePanes = $('.vistoriecontent'),
          time = 5000,
          bar = $('.progress_bar');
      
      $('.storieviewlist li').click(function (ev) {
          bar.stop();
          run();
          var currentIndex = $(this).index();
          showPane($(this).index());
      });
      $('.previous').click(function () {
          bar.stop();
          run();
          showPane(currentIndex - 1);
          showPane(currentIndex - 1);
      });
      $('.next').click(function () {
          bar.stop();
          run();
      });
      showPane(-1);
      
      run();
   </script>
   <div id="stories8">
      <div id="stories9">
         Historias de <?php echo $userinfo['username']; ?> <?php if($userinfo['username'] == $user['username']){?>
         <div id="stories9n"></div>
         <div id="stories23"><?php echo $view['views']; ?></div>
         <?php }else{} ?> 
      </div>
      <div onmouseover="StopStory()" id="viewstorie">
         <div id="contentbar">
            <div id="progress_bar" class="progress_bar" style="width: 74.0132px; overflow: hidden;"></div>
         </div>
         <div class="wrap">
            <?php 	global $db;
               $result = $db->query("SELECT * FROM cms_stories WHERE user_id = '".$userid."'");
               if($result->num_rows > 0){
               while($data = $result->fetch_array()){
               	$resultlikes = $db->query("SELECT * FROM cms_stories_likes WHERE photo_id = '".$data['id']."' AND user_id = '".$user['id']."'");
               	$resultlikes2 = $db->query("SELECT * FROM cms_stories_likes WHERE photo_id = '".$data['id']."'");
               	$likes = $resultlikes->fetch_array();
               	if($resultlikes->num_rows > 0){
               					$likecheck = '<div id="stories27" class="df'.$data['id'].'" style="transform: scale(1.5); top: 26px;"></div>';
               		}else{
               						$likecheck = '<div id="stories27" class="df'.$data['id'].'" style="transform:scale(1.0);"></div>';
               
               
               }
               $rstoriesv = $db->query("SELECT * FROM cms_stories_views WHERE user_id = '".$user['id']."' AND photo_id = '".$data['id']."'");
               if($rstoriesv->num_rows > 0){
               	}else{
                   $dbRegister = array();
                  $dbRegister['user_id'] = $user['id'];
                  $dbRegister['photo_id'] = $data['id'];
                  $dbRegister['time'] = time();
                  $query = $db->insertInto('cms_stories_views', $dbRegister);}
               ?>
            <div class="vistoriecontent" style="height: 100%; width: 100%; background: url(<?php echo PATH ?>/newfoto/camera/<?php echo $data['photo']; ?>.png); display: none;">
               <div id="stories24">
                  <div id="stories25"></div>
                  <div onclick="LikeStories(<?php echo $data['id']; ?>)" id="stories26">
                     <?php echo $likecheck; ?>
                     <div id="stories28" class="dx<?php echo $data['id']; ?>"><?php echo $resultlikes2->num_rows; ?></div>
                  </div>
                  <div id="stories29"><?php echo $Functions->GetLast($data['time']); ?></div>
               </div>
            </div>
            <?php }} ?>
         </div>
      </div>
      <div id="stories10" class="previous"></div>
      <div id="stories11" class="next"></div>
      <div id="stories30"></div>
      <div class="storieviewlist">
         <?php 	global $db;
            $result = $db->query("SELECT * FROM cms_stories WHERE user_id = '".$userid."'");
            if($result->num_rows > 0){
            foreach(range(0, $result->num_rows - 1) as $numero){
                             $data = $result->fetch_array();
            $db->query("UPDATE cms_stories SET views = views + '1' WHERE id = '".$data['id']."'");
            
            ?>
         <li class="">
            <div class="nowstor" id="nowstor-<?php echo $numero; ?>" style="background: url(<?php echo PATH ?>/newfoto/camera/<?php echo $data['photo']; ?>.png) 0% 0% / contain; transform: scale(0.8); transition: 0.3s;"></div>
         </li>
         <?php }} ?>
      </div>
   </div>
</div>
<?php }else{ ?>
<div id="rydHSG45s" style="transform: scale(1); display: block; transition: 0.3s;">
   <div onclick="fghjk()" id="stories7"></div>
   <div id="strload2">
      <div id="strload3"></div>
      <br>Aún no tienes una historia
   </div>
</div>
<?php } ?>