<?php
   require_once '../../global.php';
   
      $users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
      $user = $users->fetch_array();
   
      $id = $Functions->FilterText($_GET['id']);
   
      $r = $db->query("SELECT * FROM cms_comments_forum WHERE id = '".$id."'");
      $info = $r->fetch_array();
   
   
   ?>
<div class="dhsjd44" id="lecture42">
   <div id="lecture43"></div>
   <div class="4dsSs" id="lecture44"></div>
</div>
<div id="indexformsepare"></div>
<button id="articlescombbcode" type="button" onclick="balise('bold');"><b>B</b></button>
<button id="articlescombbcode" type="button" onclick="balise('underline')"><u>U</u></button>
<button id="articlescombbcode" type="button" onclick="balise('italic')"><i>I</i></button>
<button id="articlescombbcode" type="button" onclick="balise('createLink');">Link</button>
<button id="articlescombbcode" type="button" onclick="balise('insertImage');">Imagen</button>
<button id="articlescombbcode" style="background:#ED1C24;" type="button" onclick="balise('redcolor');">Rojo</button>
<button id="articlescombbcode" style="background:#22B14C;" type="button" onclick="balise('vertcolor');">Verde</button>
<button id="articlescombbcode" style="background:#4286CA;" type="button" onclick="balise('bleucolor');">Azul</button>
<div style="position:relative;height:48px;"></div>
<div class="messediteur" id="editeur" style="width:calc(100% - 20px);left:0px;height:auto;min-height:120px;background:rgb(206,206,206);font-size:120%;" contenteditable="true"><?php echo $Functions->FilterText2($info['commentary']); ?></div>
<div id="indexformsepare"></div>
<div id="forum39">
   <div id="forum40"
      style="background:url(<?php echo AVATARIMAGE . $user['look']; ?>&action=std&gesture=std&direction=2&head_direction=2&size=l&headonly=1&img_format=png);"></div>
   <div id="forum41">Editar como <?php echo $user['username']; ?></div>
</div>
<button class="editf24" id="forum42" onclick="ForumPostEdit('<?php echo $id; ?>')" type="submit">Enviar mensaje
</button>
<div class="end"></div>