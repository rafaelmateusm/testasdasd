<?php
   require_once '../../global.php';
   
   $users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
   $user = $users->fetch_array();
   
   $userss = $db->query("SELECT * FROM cms_message WHERE for_id = '".$user['id']."' AND visto = '0'");
     $userinfo = $userss->fetch_array();
     if($userss->num_rows > 0){
       $noti = 'block';
    
      }else{
       $noti = 'none';
    
    }
   ?>
<div style="display:<?php echo $noti; ?>" id="usernotif">
   <div id="usernotifimg"></div>
</div>