<?php
   ob_start();
   require_once '../../global.php';
   
      $users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
      $user = $users->fetch_array();
   
   ?>
<div id="rydHSG45s" style="transform: scale(1); display: block; transition: 0.3s;">
   <div onclick="fghjk()" id="stories7"></div>
   <div id="stories18">
      <div id="stories9">Mi galería de fotos</div>
      <div id="stories12">
         <?php 	global $db;
            $result = $db->query("SELECT * FROM items_camera WHERE creator_id = '".$user['id']."'");
            if($result->num_rows > 0){
            while($data = $result->fetch_array()){
            	
            $room = $db->query("SELECT * FROM rooms WHERE id = '".$data['room_id']."'");
            $roominfo = $room->fetch_array();
            
            $rstories = $db->query("SELECT * FROM cms_stories WHERE photo = '".$data['id']."'");
            
            
            ?>
         <?php if($rstories->num_rows > 0){ ?>
         <div id="mypic<?php echo $data['id']; ?>" class="stories13" style="background: url(<?php echo PATH ?>/newfoto/camera/<?php echo $data['id']; ?>.png); transform: scale(1); transition: 0.3s;">
            <div id="stories21">
               <div id="stories22"></div>
            </div>
         </div>
         <?php }else{ ?>
         <div id="mypic<?php echo $data['id']; ?>" onclick="SelctStorie('<?php echo PATH ?>/newfoto/camera/<?php echo $data['id']; ?>.png','<?php echo $data['id']; ?>','<?php echo $Functions->FilterText($roominfo['caption']); ?>','<?php echo $Functions->GetLastFace($data['time2']); ?>')" class="stories13" style="background:url(<?php echo PATH ?>/newfoto/camera/<?php echo $data['id']; ?>.png);"></div>
         <?php }} } ?>
         <div class="end"></div>
      </div>
      <div id="stories14">
         <div id="stories15">
            <div id="stories16"></div>
            <div id="stories19"></div>
            <div id="strid" style="display:none;"></div>
            <div onclick="StoriePost()" id="stories17"></div>
            <div id="stories20">Añadir a mi historia</div>
         </div>
      </div>
   </div>
</div>