<?php
   require_once '../../global.php';
   
     //HOTEL CONFIG
   $result2 = $db->query("SELECT * FROM cms_settings WHERE id = 1 LIMIT 1");
   $yezz = $result2->fetch_array();
   //END HOTEL CONFIG
   
   
     $users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
     $user = $users->fetch_array();
   ?>
<div id="support" style="display: block;">
   <div onclick="CloseSupport()" id="fermeture"></div>
   <div id="footer30">
      <div id="footer31">Contacto de soporte</div>
      <div onclick="LoadPageSupport('/app/load/HelpIndex.php','Besoin d\'aide ?')" id="footer36"></div>
      <div id="footer23">
         <a style="font-size:100%;color:white;">*<b>Se le notificará de las respuestas a sus solicitudes de ayuda. </b>No se tomarán en cuenta todo lo que sea broma, así como a los problemas mal explicados </a>
         <br><br>
         <div id="supporterreur"></div>
         <input type="text" id="sujetTitle" placeholder="Mi tema" class="indexinput" style="width:calc(100% - 25px)">
         <div id="indexformsepare"></div>
         <a style="font-size:130%;color:white;">Muéstranos la categoría</a>
         <div id="indexformsepare"></div>
         <select id="category" class="indexinput" style="width:100%;height:80px;">
            <option value="1">Problema técnico</option>
            <option value="2">Problema en la tienda</option>
            <option value="3">Problema de moderación</option>
            <option value="4">Problema de animación</option>
            <option value="5">Problema con los furnis</option>
            <option value="6">Problema con el foro</option>
            <option value="7">Los furnis faltantes</option>
         </select>
         <div id="indexformsepare"></div>
         <a style="font-size:130%;color:white;">¿Qué prioridad tiene?</a>
         <div id="indexformsepare"></div>
         <select id="priority" class="indexinput" style="width:100%;height:80px;">
            <option value="1">No es urgente</option>
            <option value="2">Poco urgente</option>
            <option value="3">Bastante urgente</option>
            <option value="4">Urgente</option>
            <option value="5">Muy urgente</option>
         </select>
         <div style="position:relative;height:12px;"></div>
         <button id="articlescombbcode" type="button" onclick="balise('bold');"><b>B</b></button>
         <button id="articlescombbcode" type="button" onclick="balise('underline')"><u>U</u></button>
         <button id="articlescombbcode" type="button" onclick="balise('italic')"><i>I</i></button>
         <button id="articlescombbcode" type="button" onclick="balise('createLink');">Link</button>
         <button id="articlescombbcode" type="button" onclick="balise('insertImage');">Imagen</button>
         <div style="position:relative;height:48px;"></div>
         <div id="editeur" style="width:calc(100% - 20px);left:0px;height:auto;min-height:150px;background:rgb(245,245,245);color:rgb(127,127,127);" contenteditable="" type="text"></div>
         <div id="indexformsepare"></div>
         <button id="indexsubmit" style="width:100%;" onclick="SupportStart()">Enviar mi solicitud de ayuda</button>
      </div>
   </div>
</div>