<?php
   require_once '../../global.php';
   
   $users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
   $user = $users->fetch_array();
   
   $page = $Functions->FilterText($_GET['page']);

   ?>

   <?php if($page == "historique"){ ?>
   
   
   
         <?php 	global $db; 
                        $result = $db->query("SELECT * FROM cms_trans_logs WHERE username = '".$user['username']."' ORDER BY id DESC");
                        if($result->num_rows > 0){
									        while($data = $result->fetch_array()){
                    ?>
   
 <div id="b201">
<div id="b202"></div>
<div id="b203"><?php echo $Functions->GetLastFace($data['time']); ?></div>
<div id="b204"><b>Realizado bajo la dirección IP <?php echo $Functions->FilterText($data['ip_user']); ?></b><br><?php echo $Functions->FilterText($data['value']); ?></div>
</div>

   <?php }}else{ echo '<div id="b144">
<center>
<div id="b145"></div>
</center>
<br>
No se han registrado transacciones en su cuenta.</div>';} ?>
   
   
   
   
   
   
   
   
   
   <?php }elseif($page == "mobis"){ ?>
   
   
   <?php global $db;
					$sql = $db->query("SELECT user_id, room_id, GROUP_CONCAT(base_item) base_item FROM items WHERE room_id = '0' AND user_id = '".$user['id']."' GROUP BY base_item HAVING COUNT(base_item)>0 ORDER BY id DESC;");
					if($sql->num_rows > 0){
					while($furni = $sql->fetch_array()){

						$sql2 = $db->query("SELECT * FROM items WHERE base_item = '". $furni['base_item'] ."' && room_id = '0'");

						$sql3 = $db->query("SELECT * FROM furniture WHERE id = '". $furni['base_item'] ."' LIMIT 1");
						$item = $sql3->fetch_array();
						
               ?>
   
    <div class="ysnz<?php echo $furni['base_item']; ?>" onclick="BoutiqueInventaireObjet('mobis','<?php echo $furni['base_item']; ?>');" id="b104">
<img style="transform:scale(2);" draggable="false" oncontextmenu="return false" src="<?php echo SWFICON . str_replace("*","_", $item['item_name']); ?>_icon.png">
<div id="b105"><?php echo $sql2->num_rows; ?></div>
</div>


<?php }}else{echo'<div id="b144">
<center>
<div id="b145"></div>
</center>
<br>
Tu inventario esta vacio.</div>';} ?>
  
   
   
   
      <?php }elseif($page == "badges"){ ?>
   
   
<?php global $db;
			   $sql = $db->query("SELECT * FROM user_badges WHERE user_id = '". $user['id'] ."' ORDER BY id");
			   if($sql->num_rows > 0){
			   while($badge = $sql->fetch_array()){

				if($badge['badge_slot'] == 1){
				$text = 'Haz click en mí para retirarme';}else{ $text = 'Haz click en mí para usarme';}
				
				if($badge['badge_slot'] == 0){
               ?>
   
<div class="bsnz<?php echo $badge['id']; ?>" onclick="BoutiqueInventaireObjet('badges','<?php echo $badge['id']; ?>');" id="b104">
<img style="transform:scale(1);" draggable="false" oncontextmenu="return false" src="<?php echo BADGEURL . $badge['badge_id'] ?>.gif">
</div>

<?php }}}else{echo'<div id="b144">
<center>
<div id="b145"></div>
</center>
<br>No tienes placas.</div>';} ?>
  
   
   
   
   <?php } ?>