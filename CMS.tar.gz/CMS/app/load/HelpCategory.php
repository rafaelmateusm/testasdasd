<?php
   require_once '../../global.php';
   
     //HOTEL CONFIG
   $result2 = $db->query("SELECT * FROM cms_settings WHERE id = 1 LIMIT 1");
   $yezz = $result2->fetch_array();
   //END HOTEL CONFIG
   
   
     $users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
     $user = $users->fetch_array();
   ?>
<div id="support" style="display: block;">
   <div onclick="CloseSupport()" id="fermeture"></div>
   <div id="footer30">
      <div id="footer31">Las llaves del juego</div>
      <div onclick="LoadPageSupport('/app/load/HelpIndex.php','¿Necesita ayuda?')" id="footer36"></div>
      <div id="footer23">
         <div id="footer32"></div>
         <div id="footer33">Usted acaba de registrarse, probablemente ya se haya conectado al hotel para descubrir el mundo increíble de <?php echo $yezz['hotelname']; ?>, ¿pero no sabes qué hacer o cómo hacerlo? Elija lo que quiere saber:</div>
         <div class="end"></div>
         <div id="helpmenu">
            <div onclick="LoadPageSupport('app/load/HelpContent.php?content=1','¿Qué es <?php echo $yezz['hotelname']; ?>?')" id="footer34">
               ¿Qué es <?php echo $yezz['hotelname']; ?>?
            </div>
            <div onclick="LoadPageSupport('app/load/HelpContent.php?content=2','¿Cómo jugar?  ')" id="footer34">¿Cómo jugar?  </div>
            <div onclick="LoadPageSupport('app/load/HelpContent.php?content=3','Manera <?php echo $yezz['hotelname']; ?>')" id="footer34">Manera <?php echo $yezz['hotelname']; ?></div>
            <div onclick="LoadPageSupport('app/load/HelpContent.php?content=4','Consejo de Seguridad')" id="footer34">Consejo de Seguridad</div>
            <div onclick="LoadPageSupport('app/load/HelpContent.php?content=5','¿Cómo lidiar con un problema?')" id="footer34">¿Cómo lidiar con un problema?</div>
            <div onclick="LoadPageSupport('app/load/HelpContent.php?content=6','Jugar casinos')" id="footer34">Como jugar a los
               casinos?
            </div>
         </div>
      </div>
   </div>
</div>