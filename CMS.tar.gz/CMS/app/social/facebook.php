<?php
   ob_start();
   require_once '../../global.php';
   
   //HOTEL CONFIG
   $result2 = $db->query("SELECT * FROM cms_settings WHERE id = 1 LIMIT 1");
   $yezz = $result2->fetch_array();
   //END HOTEL CONFIG
   


   ob_end_flush();
   ?>
            <script>(function(d, s, id) {
               var js, fjs = d.getElementsByTagName(s)[0];
               if (d.getElementById(id)) return;
               js = d.createElement(s); js.id = id;
               js.src = 'https://connect.facebook.net/es_ES/sdk.js#xfbml=1&version=v2.11';
               fjs.parentNode.insertBefore(js, fjs);
               }(document, 'script', 'facebook-jssdk'));
            </script>
            <div id="fb-root"></div>
            <div class="fb-page" data-width="600" data-href="<?php echo $yezz['facebook']; ?>" data-tabs="timeline" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true">
               <blockquote cite="<?php echo $yezz['facebook']; ?>" class="fb-xfbml-parse-ignore"><a href="<?php echo $yezz['facebook']; ?>">Familia <?php echo $yezz['hotelname']; ?></a></blockquote>
            </div>
