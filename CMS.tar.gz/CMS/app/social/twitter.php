
 <a class="twitter-timeline" href="https://twitter.com/flavioroller1">Tweets by <?php echo $yezz['hotelname']; ?>ES</a>
<script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>