<?php
   ob_start();
   require_once '../../global.php';
   ob_end_flush();	
   
   $users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
   $user = $users->fetch_array();
   
    //HOTEL CONFIG
   $result2 = $db->query("SELECT * FROM cms_settings WHERE id = 1 LIMIT 1");
   $yezz = $result2->fetch_array();
   //END HOTEL CONFIG
   
   if($_POST)
   {
    $pin = $Functions->FilterText($_POST['pin']);
	$t = $Functions->FilterText($_POST['t']);
   
      
   if($t == 1){
    if($user['pin_client'] == $pin){
   	$json["reponse"] = 'ok';
   	echo json_encode($json);
   	
    $db->query("UPDATE users SET pin_intentos = '3'  WHERE id = '".$user['id']."' LIMIT 1");
    $db->query("UPDATE users SET cms_pin = '2'  WHERE id = '".$user['id']."' LIMIT 1");
	$db->query("UPDATE users SET pin_time = '".time()."'  WHERE id = '".$user['id']."' LIMIT 1");
   
   
   }elseif($user['pin_intentos'] == 3 AND $user['pin_client'] !== $pin){

   $json["reponse"] = 'erreur';
   	echo json_encode($json);
   	
	$db->query("UPDATE users SET pin_intentos = pin_intentos - '1' WHERE id = '".$user['id']."' LIMIT 1");
   
   }elseif($user['pin_intentos'] == 2 AND $user['pin_client'] !== $pin){
   
   $json["reponse"] = 'erreur2';
   	echo json_encode($json);
   	
	$db->query("UPDATE users SET pin_intentos = pin_intentos - '1' WHERE id = '".$user['id']."' LIMIT 1");
   
   
   }elseif($user['pin_intentos'] == 1 AND $user['pin_client'] !== $pin){
   
   $json["reponse"] = 'erreur3';
   	echo json_encode($json);
	$db->query("UPDATE users SET pin_intentos = pin_intentos - '1' WHERE id = '".$user['id']."' LIMIT 1");
    $db->query("UPDATE users SET pin_time = '".time()."'  WHERE id = '".$user['id']."' LIMIT 1");
   if($user['rank'] > 5){
   $dbQuery= array();
          $dbQuery['username'] = $user['username'];
          $dbQuery['content'] = 'Esto es un mensaje staff. El usuario '.$user['username'].' ha perdido su código pin, y se le han agotado los 3 intentos.';
          $dbQuery['time'] = time();
          $dbQuery['type'] = "ticket";
          $dbQuery['priority'] = '5';
          $dbQuery['title'] = '[ADM] Se le olvido el código';
          $query = $db->insertInto('cms_tickets', $dbQuery);
		  
		  }
   
   }
   
   }elseif($t == 2){
   
   $json["reponse"] = 'ok';
   	echo json_encode($json);
	
$titulo = $user['username'].', confirme su dirección de correo electrónico';
$mensaje = '<tbody>
   <tr>
      <td align="center">
         <table border="0" cellpadding="0" cellspacing="0" width="595">
            <tbody>
               <tr>
                  <td align="left" height="70" valign="middle" style="border-bottom:1px solid #aaaaaa">
                     <table border="0" cellpadding="0" cellspacing="0">
                        <tbody>
                           <tr>
                              <td><img data-imagetype="External" src="'.PATH.'/app/assets/img/logos/menu_logo.png" alt="'.$yezz['hotelname'].'" style="display:block"> </td>
                           </tr>
                        </tbody>
                     </table>
                  </td>
               </tr>
               <tr>
                  <td align="left" valign="middle" style="border-bottom:1px dashed #aaaaaa">
                     <table border="0" cellpadding="0" cellspacing="0" style="padding:0 0 10px 0; width:100%">
                        <tbody>
                           <tr>
                              <td valign="top">
                                 <p style="color:black; font-family:Verdana,Arial,sans-serif; font-size:20px; padding-top:15px">
                                    Hola <b><span style="font-weight:bold"><a href="mailto:'.$user['mail'].'" target="_blank" rel="noopener noreferrer">'.$user['username'].'</a></span></b> 
                                 </p>
                                 <p style="color:black; font-family:Verdana,Arial,sans-serif; font-size:12px; padding-bottom:5px">
                                    Para confirmar la validez de su direcci&oacute;n de correo electr&oacute;nico, copie el c&oacute;digo a continuaci&oacute;n en '.$yezz['hotelname'].' donde se le indica. <br>
                                    <br>
                                    Si ha recibido este correo electr&oacute;nico por error, ign&oacute;relo.
                                 </p>
                              </td>
                           </tr>
                        </tbody>
                     </table>
                  </td>
               </tr>
               <tr>
                  <td align="left" height="100" valign="middle" style="border-bottom:1px solid #aaaaaa">
                     <table border="0" cellpadding="0" cellspacing="0" style="">
                        <tbody>
                           <tr>
                              <td valign="middle">
                                 <table cellpadding="0" cellspacing="0" style="background-color:#51b708; height:50px">
                                    <tbody>
                                       <tr>
                                          <td valign="middle" style="height:100%; vertical-align:middle; border:solid 2px #000000">
                                             <p style="font-family:Verdana,Arial,sans-serif; font-weight:bold; font-size:18px; color:#ffffff">
                                               Cod : '.$user['pin_client'].' 
                                             </p>
                                          </td>
                                       </tr>
                                    </tbody>
                                 </table>
                              </td>
                           </tr>
                        </tbody>
                     </table>
                  </td>
               </tr>
            </tbody>
         </table>
         <div style="text-decoration:none; padding:15px 20px; color:#ffffff; margin-top:5px; font-size:13px">
            <a href="#" target="_blank" rel="noopener noreferrer" style="color:black">Pol&iacute;tica de confidencialidad</a> | 
			<a href="#" target="_blank" rel="noopener noreferrer" style="color:black">Condiciones de uso</a> | 
			<a href="#" target="_blank" rel="noopener noreferrer" style="color:black">Cont&aacute;ctenos</a> | 
			<a href="'.PATH.'/register" target="_blank" rel="noopener noreferrer" style="color:black">Registrarme</a> | 
			<a href="'.PATH.'/index" target="_blank" rel="noopener noreferrer" style="color:black">&iquest;Contrase&ntilde;a olvidada?</a> 
         </div>
         <div style="color:black; margin-top:9px; font-size:11px; margin-bottom:9px">&copy; <span data-markjs="true" class="mark1r5zpt0nk" style="background-color: yellow; color: black;">'.$yezz['hotelname'].'</span> 2017-2018 </div>
      </td>
   </tr>
</tbody>';

$cabeceras  = 'MIME-Version: 1.0' . "\r\n";
$cabeceras .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$cabeceras .= 'To: '.$user['username'].' <'.$user['mail'].'>' . "\r\n";
$cabeceras .= 'From: '.$yezz['hotelname'].' <pixeled.soporte@gmail.com>' . "\r\n";

mail($mail, $titulo, $mensaje, $cabeceras);
   
   
   }
   
   }
   
   ?>