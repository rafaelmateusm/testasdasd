<?php
   ob_start();
   require_once '../../global.php';
   ob_end_flush();	
   
   //HOTEL CONFIG
   $result2 = $db->query("SELECT * FROM cms_settings WHERE id = 1 LIMIT 1");
   $yezz = $result2->fetch_array();
   //END HOTEL CONFIG
   
   if($_POST)
   {
    $user = $Functions->FilterText($_POST['pseudo']);
   $mail = $Functions->FilterText($_POST['mail']);
   $pass = $Functions->FilterText($_POST['password']);
   $rpass = $Functions->FilterText($_POST['repassword']);
   $captcha = $Functions->FilterText($_POST['captcha']);
   $figure = $Functions->FilterText($_POST['figure']);
   $look = $Functions->FilterText($_POST['look']);
   $gender = $Functions->FilterText($_POST['gender']);
   
   $result = $db->query("SELECT * FROM users WHERE username = '{$user}' OR mail = '{$mail}' LIMIT 1");
   $resultuser = $db->query("SELECT * FROM users WHERE username = '{$user}'LIMIT 1");
   $resultmail = $db->query("SELECT * FROM users WHERE mail = '{$mail}' LIMIT 1");
   $filter = preg_replace("/[^a-z\d\-=\!@:\.,]/i", "", $user);
   $email_check = preg_match("/^[a-z0-9_\.-]+@([a-z0-9]+([\-]+[a-z0-9]+)*\.)+[a-z]{2,7}$/i", $mail);
   
    if($resultuser->num_rows > 0){
   	$json["reponse"] = 'pseudo';
   	echo json_encode($json);
   	
   }elseif($user !== $filter || strlen($user) < 2 || strlen($user) > 18){
   	$json["reponse"] = 'pseudo';
   	echo json_encode($json);
   	
   }elseif($resultmail->num_rows > 0){
   	$json["reponse"] = 'email';
   	echo json_encode($json);
   	
   }elseif($email_check !== 1){
   	$json["reponse"] = 'email';
   	echo json_encode($json);
   	
   }elseif($_SESSION['captcha'] !== strtoupper($captcha)){
   	$json["reponse"] = 'captcha';
   	echo json_encode($json);
   	
   }elseif(strlen($pass) !== strlen($rpass)){
   	$json["reponse"] = 'password';
   	echo json_encode($json);
   	
   	}else{
   	$json["reponse"] = 'ok';
   	echo json_encode($json);
   	
   $dbRegister = array();
   $dbRegister['username'] = $user;
   $dbRegister['password'] = md5($pass);
   $dbRegister['mail'] = $mail;
   $dbRegister['rank'] = 1;
   $dbRegister['account_created'] = time();
   $dbRegister['last_online'] = time();
   $dbRegister['ip_last'] = $Functions->getRealIP();
   $dbRegister['ip_reg'] = $Functions->getRealIP();
   $dbRegister['gender'] = $gender;
   $dbRegister['look'] = $look;
   $query = $db->insertInto('users', $dbRegister);
   
   if( $Functions->CheckLogged($user, md5($pass)) ){
   session_start();
   $_SESSION['connection_type'] = "id";
   }}
   }
   
   ?>