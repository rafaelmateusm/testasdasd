<?php
   ob_start();
   require_once '../../global.php';
   ob_end_flush();	
   
   $users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
   $user = $users->fetch_array();
   
   if($_POST)
   {
    $message = $Functions->FilterText($_POST['message']);
    $userid = $Functions->FilterText($_POST['userid']);
	$type = $Functions->FilterText($_POST['type']);
   
   
   if($type == 'normal'){
   
   $ruser = $db->query("SELECT * FROM users WHERE id = '".$userid."'");
   $userinfo = $ruser->fetch_array();
   
   
   
   if($ruser->num_rows == 0){
   $json["reponse"] = 'erreur';
   	echo json_encode($json);
    
    }else{
     
    $json["reponse"] = 'ok';
   	echo json_encode($json);
    
    $dbQuery= array();
          $dbQuery['username'] = $user['username'];
    $dbQuery['from_id'] = $user['id'];
          $dbQuery['message'] = $message;
          $dbQuery['for_id'] = $userid;
		  $dbQuery['type'] = $type;
          $dbQuery['time'] = time();
          $dbQuery['visto'] = 0;
          $query = $db->insertInto('cms_message', $dbQuery);
    
    }
    
    
   
   }elseif($type == 'adm'){
   

     
    $json["reponse"] = 'ok';
   	echo json_encode($json);
    
    $dbQuery= array();
          $dbQuery['username'] = $user['username'];
    $dbQuery['from_id'] = $user['id'];
          $dbQuery['message'] = $message;
          $dbQuery['for_id'] = $userid;
		  $dbQuery['type'] = $type;
          $dbQuery['time'] = time();
          $dbQuery['visto'] = 0;
          $query = $db->insertInto('cms_message', $dbQuery);
    
    }
    
    
   
   } 
   
   ?>