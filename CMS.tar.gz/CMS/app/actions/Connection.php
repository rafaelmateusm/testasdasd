<?php
   ob_start();
   require_once '../../global.php';
   ob_end_flush();	
   
   if($_POST)
   {
    $user = $Functions->FilterText($_POST['identifiant']);
   $pass = $Functions->FilterText($_POST['password']);
   
   
   $checkban = $db->query("SELECT * FROM bans WHERE value = '{$user}' LIMIT 1");
   
   $us = $db->query("SELECT * FROM users WHERE username = '".$user."'");
   $u = $us->fetch_array();
   
   if( $checkban->num_rows > 0 ){
    $json["id"] = $user;
   	$json["reponse"] = 'bannis';
   	echo json_encode($json);
	
   } else if( $u['cuenta_suspendida'] == 1 ){
    $json["message"] = 'Cuenta suspendida temporalmente';
   	$json["reponse"] = 'suspendida';
   	echo json_encode($json);
	
	
   } else if(isset($user) AND isset($pass)){
				$a = $Functions->FilterText($user);
				$b = $Functions->FilterText($pass);
				if( empty($a) || empty($b) ){
					$json["reponse"] = 'erreur';
    echo json_encode($json);
					}
				elseif( $Functions->CheckLogged($a, md5($b)) ){

					$json["reponse"] = 'ok';
   	echo json_encode($json);
				 }else{ 
				 $json["reponse"] = 'erreur';
    echo json_encode($json);
				 }
				
			}

   }
   
   ?>