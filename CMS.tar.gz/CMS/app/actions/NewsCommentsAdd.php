<?php
   ob_start();
   require_once '../../global.php';
   ob_end_flush();	
   
   $users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
   $user = $users->fetch_array();
   
   if($_POST)
   {
    $message = $Functions->FilterText2($_POST['contenu']);
    $newsid = $Functions->FilterText($_POST['newsid']);
   
   
   
   
   $result = $db->query("SELECT * FROM cms_comments_news WHERE new_id = '".$newsid."' AND username = '".$user['username']."'");
   $info = $result->fetch_array();
   
   
   
   if($info['time'] >= time() - 180){
   $json["reponse"] = 'erreur';
   $json["message"] = 'Debes esperar 3 min. para enviar otro mensaje.';
   	echo json_encode($json);
    
    }else{
     
    $json["reponse"] = 'ok';
   	echo json_encode($json);
    
    $dbQuery= array();
          $dbQuery['username'] = $user['username'];
          $dbQuery['commentary'] = $message;
          $dbQuery['new_id'] = $newsid;
          $dbQuery['time'] = time();
          $query = $db->insertInto('cms_comments_news', $dbQuery);
    
    }
    
    
   
   }
   
   ?>