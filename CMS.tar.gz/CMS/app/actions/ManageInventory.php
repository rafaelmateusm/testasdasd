<?php
   ob_start();
   require_once '../../global.php';
   ob_end_flush();	
   
   $users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
   $user = $users->fetch_array();
   
   if($_POST)
   {
    $type = $Functions->FilterText($_POST['type']);
    $id = $Functions->FilterText($_POST['id']);
   
   
   if($type == 'mobis'){
	   $sqlss = $db->query("SELECT * FROM items WHERE room_id = '0' AND user_id = '".$user['id']."' AND base_item = '". $id ."'");
	   
   $sql3 = $db->query("SELECT * FROM furniture WHERE id = '". $id ."'");
   $item = $sql3->fetch_array();

   
    if($sqlss->num_rows > 0){
   	$json["reponse"] = 'ok';
	$json["image"] = SWFICON . str_replace("*","_", $item['item_name']).'_icon.png';
	$json["nom"] = $item['public_name'];
   	echo json_encode($json);
   }else{
   $json["reponse"] = 'erreur';
   	echo json_encode($json);
   }
   
   
   }elseif($type == 'mobisdelete'){
   if($user['online'] == 1){

		}else{
			$db->query("DELETE FROM items WHERE user_id = '".$user['id']."' && base_item = '".$id."' && room_id = '0'");
			
		$json["reponse"] = 'ok';
		echo json_encode($json);
	  }
   
   
   }elseif($type == 'badges'){
$sql = $db->query("SELECT * FROM user_badges WHERE id = '". $id ."'");
$badge = $sql->fetch_array();

   
    if($sql->num_rows > 0){
   	$json["reponse"] = 'ok';
	$json["image"] = BADGEURL . $badge['badge_id'].'.gif';
	$json["nom"] = $badge['badge_id'];
   	echo json_encode($json);
   }else{
   $json["reponse"] = 'erreur';
   	echo json_encode($json);
   }
   
   
   }elseif($type == 'badgesdelete'){
  $db->query("DELETE FROM user_badges WHERE user_id = '".$user['id']."' && id = '".$id."' LIMIT 1");
		$json["reponse"] = 'ok';
		echo json_encode($json);
	  }
   
   
   }
   

   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   ?>