<?php
   ob_start();
   require_once '../../global.php';
   ob_end_flush();	
   
   $users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
   $user = $users->fetch_array();
   
   if($_POST)
   {
    $id = $Functions->FilterText($_POST['id']);
   
   
   $result = $db->query("SELECT * FROM cms_comments_news WHERE id = '{$id}' AND username = '{$user['username']}' LIMIT 1");
   
   
    if($result->num_rows > 0){
   	$json["reponse"] = 'ok';
   	echo json_encode($json);
   	
   $db->query("DELETE FROM cms_comments_news WHERE id = '{$id}' AND username = '{$user['username']}' LIMIT 1");
   
   
   }else{
   	$json["reponse"] = 'erreur';
   	echo json_encode($json);
   	   
   }
   }
   
   ?>