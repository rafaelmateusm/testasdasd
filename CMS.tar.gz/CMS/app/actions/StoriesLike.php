<?php
   ob_start();
   require_once '../../global.php';
   ob_end_flush();	
   
   $users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
   $user = $users->fetch_array();
   
   if($_POST)
   {
    $id = $Functions->FilterText($_POST['id']);
   
   
   $result = $db->query("SELECT * FROM cms_stories_likes WHERE photo_id = '{$id}' AND user_id = '{$user['id']}' LIMIT 1");
   
   
    if($result->num_rows > 0){
   	$json["type"] = '2';
   	echo json_encode($json);
   	
   $db->query("DELETE FROM cms_stories_likes WHERE photo_id = '{$id}' AND user_id = '{$user['id']}' LIMIT 1");
   
   
   }else{
   	$json["type"] = '1';
   	echo json_encode($json);
   	
   $dbRegister = array();
   $dbRegister['user_id'] = $user['id'];
   $dbRegister['photo_id'] = $id;
   $dbRegister['time'] = time();
   $query = $db->insertInto('cms_stories_likes', $dbRegister);
   
   }
   }
   
   ?>