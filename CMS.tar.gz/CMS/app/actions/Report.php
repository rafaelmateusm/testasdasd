<?php
   ob_start();
   require_once '../../global.php';
   ob_end_flush();	
   
   $users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
   $user = $users->fetch_array();
   
   if($_POST)
   {
    $type = $Functions->FilterText($_POST['type']);
   $content = $Functions->FilterText($_POST['content']);
   $contenu_text = $Functions->FilterText($_POST['contenu_text']);
   $signalement = $Functions->FilterText($_POST['signalement']);
   
   
   if($type == 'user'){
    
   $result = $db->query("SELECT * FROM cms_message WHERE id = '{$contenu_text}'");
   $data = $result->fetch_array();
   
    if($result->num_rows > 0){
   	$json["reponse"] = 'ok';
   	echo json_encode($json);
   	
   $dbRegister = array();
   $dbRegister['username'] = $user['username'];
   $dbRegister['from_id'] = $data['from_id'];
   $dbRegister['message'] = $Functions->FilterText($data['message']);
   $dbRegister['for_id'] = $user['id'];
   $dbRegister['type'] = $signalement;
   $dbRegister['category'] = $type;
   $dbRegister['time'] = time();
   $query = $db->insertInto('cms_reports', $dbRegister);   
   
   }else{
   	$json["reponse"] = 'erreur';
   	echo json_encode($json);
   }
   }elseif($type == 'news'){
   
   $result = $db->query("SELECT * FROM cms_comments_news WHERE id = '{$contenu_text}'");
   $data = $result->fetch_array();
   
   $resultu = $db->query("SELECT * FROM users WHERE username = '".$data['username']."'");
   $userinfo = $resultu->fetch_array();
   
    if($result->num_rows > 0){
   	$json["reponse"] = 'ok';
   	echo json_encode($json);
   	
   $dbRegister = array();
   $dbRegister['username'] = $user['username'];
   $dbRegister['from_id'] = $userinfo['id'];
   $dbRegister['message'] = $Functions->FilterText($data['commentary']);
   $dbRegister['for_id'] = $user['id'];
   $dbRegister['post_id'] = $contenu_text;
   $dbRegister['type'] = $signalement;
   $dbRegister['category'] = $type;
   $dbRegister['time'] = time();
   $query = $db->insertInto('cms_reports', $dbRegister);   
   
   }else{
   	$json["reponse"] = 'erreur';
   	echo json_encode($json);
   }
   
   }elseif($type == 'forum'){
   
   $result = $db->query("SELECT * FROM cms_comments_forum WHERE id = '{$contenu_text}'");
   $data = $result->fetch_array();
   
   $resultu = $db->query("SELECT * FROM users WHERE username = '".$data['username']."'");
   $userinfo = $resultu->fetch_array();
   
    if($result->num_rows > 0){
   	$json["reponse"] = 'ok';
   	echo json_encode($json);
   	
   $dbRegister = array();
   $dbRegister['username'] = $user['username'];
   $dbRegister['from_id'] = $userinfo['id'];
   $dbRegister['message'] = $Functions->FilterText($data['commentary']);
   $dbRegister['for_id'] = $user['id'];
   $dbRegister['post_id'] = $contenu_text;
   $dbRegister['type'] = $signalement;
   $dbRegister['category'] = $type;
   $dbRegister['time'] = time();
   $query = $db->insertInto('cms_reports', $dbRegister);   
   
   }else{
   	$json["reponse"] = 'erreur';
   	echo json_encode($json);
   }
   
   }
   }
   ?>