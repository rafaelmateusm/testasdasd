<?php
   ob_start();
   require_once '../../global.php';
   ob_end_flush();	
   
   $users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
   $user = $users->fetch_array();
   
   if($_POST)
   {
    $id = $Functions->FilterText($_POST['id']);
   
   
   $result = $db->query("SELECT * FROM cms_stories WHERE photo = '{$id}' LIMIT 1");
   
   
    if($result->num_rows > 0){
   	$json["reponse"] = 'error';
   	echo json_encode($json);
   	
   }else{
   	$json["reponse"] = 'ok';
   	echo json_encode($json);
   	
   
   $dbRegister = array();
   $dbRegister['user_id'] = $user['id'];
   $dbRegister['photo'] = $id;
   $dbRegister['time'] = time();
   $query = $db->insertInto('cms_stories', $dbRegister);
   
   $db->query("UPDATE users SET cms_stories = cms_stories + '1' WHERE id = '".$user['id']."'");
                 }
   	 }
   
   
   ?>