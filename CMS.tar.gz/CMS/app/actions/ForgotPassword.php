<?php
   ob_start();
   require_once '../../global.php';
   ob_end_flush();	
   
      //HOTEL CONFIG
   $result2 = $db->query("SELECT * FROM cms_settings WHERE id = 1 LIMIT 1");
   $yezz = $result2->fetch_array();
   //END HOTEL CONFIG
   
   function generarCodigo($longitud) {
      $key = '';
      $pattern = '0123456789';
      $max = strlen($pattern)-1;
      for($i=0;$i < $longitud;$i++) $key .= $pattern{mt_rand(0,$max)};
      return $key;
     }
	 
   if($_POST)
   {
	   $step = $Functions->FilterText($_POST['step']);
	   
	   
	   
if($step == 1)
   {  
$code = generarCodigo(6);

    $email = $Functions->FilterText($_POST['email']);
   $captcha = $Functions->FilterText($_POST['code']);
   $emailsql = $db->query("SELECT * FROM users WHERE mail = '{$email}'");
   $userinfo = $emailsql->fetch_array();
   
   if($_SESSION['captcha'] !== strtoupper($captcha)){
   	$json["reponse"] = 'captcha';
   	echo json_encode($json);
   	
   }elseif( $userinfo['cms_forgot_time'] >= time() - 3600 ){
   	$json["reponse"] = 'temps';
   	echo json_encode($json);
   
   }elseif( $userinfo['mail'] !== $email ){
   	$json["reponse"] = 'mail';
   	echo json_encode($json);
   
   }elseif($userinfo['mail'] == $email){
   	$json["reponse"] = 'ok';
    echo json_encode($json);
	$db->query("UPDATE users SET code_forgot = '".$code."', cms_forgot_time = '".time()."' WHERE id = '".$userinfo['id']."'");
	
	$dbQuery= array();
          $dbQuery['username'] = $userinfo['username'];
          $dbQuery['email'] = $email;
		  $dbQuery['time'] = time();
          $query = $db->insertInto('cms_forgot', $dbQuery);
		  
		  
$titulo = $userinfo['username'].' contrasena olvidada';
$mensaje = '<tbody>
   <tr>
      <td align="center">
         <table border="0" cellpadding="0" cellspacing="0" width="595">
            <tbody>
               <tr>
                  <td align="left" height="70" valign="middle" style="border-bottom:1px solid #aaaaaa">
                     <table border="0" cellpadding="0" cellspacing="0">
                        <tbody>
                           <tr>
                              <td><img data-imagetype="External" src="'.PATH.'/app/assets/img/logos/menu_logo.png" alt="'.$yezz['hotelname'].'" style="display:block"> </td>
                           </tr>
                        </tbody>
                     </table>
                  </td>
               </tr>
               <tr>
                  <td align="left" valign="middle" style="border-bottom:1px dashed #aaaaaa">
                     <table border="0" cellpadding="0" cellspacing="0" style="padding:0 0 10px 0; width:100%">
                        <tbody>
                           <tr>
                              <td valign="top">
                                 <p style="color:black; font-family:Verdana,Arial,sans-serif; font-size:20px; padding-top:15px">
                                    Hola <b><span style="font-weight:bold"><a href="mailto:'.$userinfo['mail'].'" target="_blank" rel="noopener noreferrer">'.$userinfo['username'].'</a></span></b> 
                                 </p>
                                 <p style="color:black; font-family:Verdana,Arial,sans-serif; font-size:12px; padding-bottom:5px">
                                    Para confirmar la validez de su direcci&oacute;n de correo electr&oacute;nico, copie el c&oacute;digo a continuaci&oacute;n en '.$yezz['hotelname'].' donde se le indica. <br>
                                    <br>
                                    Si ha recibido este correo electr&oacute;nico por error, ign&oacute;relo.
                                 </p>
                              </td>
                           </tr>
                        </tbody>
                     </table>
                  </td>
               </tr>
               <tr>
                  <td align="left" height="100" valign="middle" style="border-bottom:1px solid #aaaaaa">
                     <table border="0" cellpadding="0" cellspacing="0" style="">
                        <tbody>
                           <tr>
                              <td valign="middle">
                                 <table cellpadding="0" cellspacing="0" style="background-color:#51b708; height:50px">
                                    <tbody>
                                       <tr>
                                          <td valign="middle" style="height:100%; vertical-align:middle; border:solid 2px #000000">
                                             <p style="font-family:Verdana,Arial,sans-serif; font-weight:bold; font-size:18px; color:#ffffff">
                                                Cod : '.$code.' 
                                             </p>
                                          </td>
                                       </tr>
                                    </tbody>
                                 </table>
                              </td>
                           </tr>
                        </tbody>
                     </table>
                  </td>
               </tr>
            </tbody>
         </table>
         <div style="text-decoration:none; padding:15px 20px; color:#ffffff; margin-top:5px; font-size:13px">
            <a href="#" target="_blank" rel="noopener noreferrer" style="color:black">Pol&iacute;tica de confidencialidad</a> | <a href="#" target="_blank" rel="noopener noreferrer" style="color:black">Condiciones de uso</a> | <a href="#" target="_blank" rel="noopener noreferrer" style="color:black">Cont&aacute;ctenos</a> | 
			<a href="'.PATH.'/register" target="_blank" rel="noopener noreferrer" style="color:black">Registrarme</a> | <a href="'.PATH.'/index" target="_blank" rel="noopener noreferrer" style="color:black">&iquest;Contrase&ntilde;a olvidada?</a> 
         </div>
         <div style="color:black; margin-top:9px; font-size:11px; margin-bottom:9px">&copy; <span data-markjs="true" class="mark1r5zpt0nk" style="background-color: yellow; color: black;">'.$yezz['hotelname'].'</span> 2017-2018 </div>
      </td>
   </tr>
</tbody>';

$cabeceras  = 'MIME-Version: 1.0' . "\r\n";
$cabeceras .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$cabeceras .= 'To: '.$userinfo['username'].' <'.$userinfo['mail'].'>' . "\r\n";
$cabeceras .= 'From: '.$yezz['hotelname'].' <pixeled.soporte@gmail.com>' . "\r\n";

mail($email, $titulo, $mensaje, $cabeceras);

		
	
	
   	}
   }elseif($step == 2){
   
   
   $pass = $Functions->FilterText($_POST['mdp']);
   $rpass = $Functions->FilterText($_POST['mdpconfirm']);
   $code = $Functions->FilterText($_POST['clee']);
   $sql = $db->query("SELECT * FROM users WHERE code_forgot = '{$code}'");
   $userinfo = $sql->fetch_array();
   
    if($code == '' || $pass == '' || $rpass == ''){
   	$json["reponse"] = 'code';
	$json["reponse"] = 'error';
   	echo json_encode($json);
   	
   }elseif($userinfo['code_forgot'] !== $code){
   	$json["reponse"] = 'code';
   	echo json_encode($json);
   	
   }elseif( strlen($pass) !== strlen($rpass) ){
   	$json["reponse"] = 'error';
   	echo json_encode($json);
   
   }else{
   	$json["reponse"] = 'ok';
   	echo json_encode($json);
   $db->query("UPDATE users SET password = '".md5($pass)."' WHERE id = '{$userinfo['id']}' LIMIT 1");
   }
   
   }
   }
   ?>