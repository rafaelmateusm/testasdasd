<?php
   ob_start();
   require_once '../../global.php';
   ob_end_flush();	
   
   $users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
   $user = $users->fetch_array();
   
   
         //HOTEL CONFIG
   $result2 = $db->query("SELECT * FROM cms_settings WHERE id = 1 LIMIT 1");
   $yezz = $result2->fetch_array();
   //END HOTEL CONFIG
   
   function generarCodigo($longitud) {
      $key = '';
      $pattern = '0123456789';
      $max = strlen($pattern)-1;
      for($i=0;$i < $longitud;$i++) $key .= $pattern{mt_rand(0,$max)};
      return $key;
     }
	 $code = generarCodigo(6);
	 
   if($_POST)
   {
    $type = $Functions->FilterText($_POST['type']);
   
   
   
    if($type == 'password'){
   $n = $Functions->FilterText($_POST['n']);
   $v = $Functions->FilterText($_POST['v']);
   $o = $Functions->FilterText($_POST['o']);
   
   
   if(md5($o) !== $user['password']) {
   	$json["reponse"] = 'erreur';
   $json["message"] = 'Tu contraseña actual no coincide';
   	echo json_encode($json);
   	
   }elseif(strlen($n) < 6 || strlen($v) > 32) {
   	$json["reponse"] = 'erreur';
   $json["message"] = 'Inserta una contraseña válida';
   	echo json_encode($json);
   	
   }elseif($n !== $v) {
   	$json["reponse"] = 'erreur';
   $json["message"] = 'Las contraseñas no son iguales';
   	echo json_encode($json);
   	
   }elseif($user['time_pass'] >= time() - 180) {
   	$json["reponse"] = 'erreur';
   $json["message"] = 'Debes esperar 3 min. para volver a cambiar tu contraseña.';
   	echo json_encode($json);
   	
   }else{
   	$json["reponse"] = 'ok';
   $json["message"] = 'Actualizado con éxito';
   	echo json_encode($json);
   
   $db->query("UPDATE users SET password = '".md5($n)."', time_pass = '".time()."' WHERE id = '{$user['id']}' LIMIT 1");
   $_SESSION['password'] = md5($n);
   
   }
   }elseif($type == 'pinone'){
    
   $pin = $Functions->FilterText($_POST['pin']);
   $password = $Functions->FilterText($_POST['password']);
   $oldpin = $Functions->FilterText($_POST['oldpin']);
   
   if(md5($password) !== $user['password']){
   $json["reponse"] = 'erreur';
   $json["message"] = 'La contraseña no coincide';
   	echo json_encode($json);
   
   
   }elseif(strlen($pin) < 4){
    $json["reponse"] = 'erreur';
   $json["message"] = 'Tu PIN tiene que tener 4 dígitos.';
   	echo json_encode($json);
    
    }elseif($pin == ''){
   $json["reponse"] = 'erreur';
   $json["message"] = 'Ingrese un PIN';
   	echo json_encode($json);
   
   }else{
   
   $json["reponse"] = 'ok';
   $json["message"] = 'Actualizado con éxito';
   	echo json_encode($json);
   
   $db->query("UPDATE users SET pin_client = '{$pin}', cms_pin = '1' WHERE id = '{$user['id']}' LIMIT 1");
   
   }
   
   }elseif($type == 'pintwo'){
   
      $pin = $Functions->FilterText($_POST['pin']);
   $password = $Functions->FilterText($_POST['password']);
   $oldpin = $Functions->FilterText($_POST['oldpin']);
   $del = $Functions->FilterText($_POST['del']);
   
   if($del == 'supp'){
    
    if(md5($password) !== $user['password']){
   $json["reponse"] = 'erreur';
   $json["message"] = 'La contraseña no coincide';
   	echo json_encode($json);
    
    }elseif($oldpin !== $user['pin_client']){
   $json["reponse"] = 'erreur';
   $json["message"] = 'Tu PIN actual no coincide';
   	echo json_encode($json);
     }else{
   
   $json["reponse"] = 'ok';
   $json["message"] = 'Actualizado con éxito';
   	echo json_encode($json);
   
   $db->query("UPDATE users SET pin_client = '', cms_pin = '0' WHERE id = '{$user['id']}' LIMIT 1");
   
   
   } }elseif(md5($password) !== $user['password']){
   $json["reponse"] = 'erreur';
   $json["message"] = 'La contraseña no coincide';
   	echo json_encode($json);
   
   
   }elseif(strlen($pin) < 4){
    $json["reponse"] = 'erreur';
   $json["message"] = 'Tu PIN tiene que tener 4 dígitos.';
   	echo json_encode($json);
    
    }elseif($pin == ''){
   $json["reponse"] = 'erreur';
   $json["message"] = 'Ingrese un PIN';
   	echo json_encode($json);
   
   }elseif($oldpin !== $user['pin_client']){
   $json["reponse"] = 'erreur';
   $json["message"] = 'Tu PIN actual no coincide';
   	echo json_encode($json);
   
   
   }else{
   
   $json["reponse"] = 'ok';
   $json["message"] = 'Actualizado con éxito';
   	echo json_encode($json);
   
   $db->query("UPDATE users SET pin_client = '{$pin}', cms_pin = '1' WHERE id = '{$user['id']}' LIMIT 1");
   
   }
   
   
   }elseif($type == 'mail1'){
	   $mail = $Functions->FilterText($_POST['mail']);
   $ru = $db->query("SELECT * FROM users WHERE mail = '{$mail}'");
   $u = $ru->fetch_array();
   

   if($mail == ''){
   $json["reponse"] = 'erreur';
   $json["message"] = 'Campos vacíos, inténtalo de nuevo.';
   	echo json_encode($json);
   
   }elseif($user['email_verificado'] == 1 AND $mail == $user['mail']){
   $json["reponse"] = 'erreur';
   $json["message"] = 'Correo electrónico existente, inténtalo de nuevo.';
   	echo json_encode($json);
   
   }elseif($mail !== $user['mail'] AND $ru->num_rows == 1){
   $json["reponse"] = 'erreur';
   $json["message"] = 'Correo electrónico existente, inténtalo de nuevo.';
   	echo json_encode($json);
   
   }else{
   $json["reponse"] = 'ok';
   	echo json_encode($json);

	$db->query("UPDATE users SET code_forgot = '".$code."' WHERE id = '".$user['id']."'");
	
	   $titulo = $user['username'].' confirme su cuenta';
$mensaje = '<tbody>
   <tr>
      <td align="center">
         <table border="0" cellpadding="0" cellspacing="0" width="595">
            <tbody>
               <tr>
                  <td align="left" height="70" valign="middle" style="border-bottom:1px solid #aaaaaa">
                     <table border="0" cellpadding="0" cellspacing="0">
                        <tbody>
                           <tr>
                              <td><img data-imagetype="External" src="'.PATH.'/app/assets/img/logos/menu_logo.png" alt="'.$yezz['hotelname'].'" style="display:block"> </td>
                           </tr>
                        </tbody>
                     </table>
                  </td>
               </tr>
               <tr>
                  <td align="left" valign="middle" style="border-bottom:1px dashed #aaaaaa">
                     <table border="0" cellpadding="0" cellspacing="0" style="padding:0 0 10px 0; width:100%">
                        <tbody>
                           <tr>
                              <td valign="top">
                                 <p style="color:black; font-family:Verdana,Arial,sans-serif; font-size:20px; padding-top:15px">
                                    Hola <b><span style="font-weight:bold"><a href="mailto:'.$mail.'" target="_blank" rel="noopener noreferrer">'.$user['username'].'</a></span></b> 
                                 </p>
                                 <p style="color:black; font-family:Verdana,Arial,sans-serif; font-size:12px; padding-bottom:5px">
                                    Para confirmar la validez de su direcci&oacute;n de correo electr&oacute;nico, copie el c&oacute;digo a continuaci&oacute;n en '.$yezz['hotelname'].' donde se le indica. <br>
                                    <br>
                                    Si ha recibido este correo electr&oacute;nico por error, ign&oacute;relo.
                                 </p>
                              </td>
                           </tr>
                        </tbody>
                     </table>
                  </td>
               </tr>
               <tr>
                  <td align="left" height="100" valign="middle" style="border-bottom:1px solid #aaaaaa">
                     <table border="0" cellpadding="0" cellspacing="0" style="">
                        <tbody>
                           <tr>
                              <td valign="middle">
                                 <table cellpadding="0" cellspacing="0" style="background-color:#51b708; height:50px">
                                    <tbody>
                                       <tr>
                                          <td valign="middle" style="height:100%; vertical-align:middle; border:solid 2px #000000">
                                             <p style="font-family:Verdana,Arial,sans-serif; font-weight:bold; font-size:18px; color:#ffffff">
                                               Cod : '.$code.' 
                                             </p>
                                          </td>
                                       </tr>
                                    </tbody>
                                 </table>
                              </td>
                           </tr>
                        </tbody>
                     </table>
                  </td>
               </tr>
            </tbody>
         </table>
         <div style="text-decoration:none; padding:15px 20px; color:#ffffff; margin-top:5px; font-size:13px">
            <a href="#" target="_blank" rel="noopener noreferrer" style="color:black">Pol&iacute;tica de confidencialidad</a> | <a href="#" target="_blank" rel="noopener noreferrer" style="color:black">Condiciones de uso</a> | <a href="#" target="_blank" rel="noopener noreferrer" style="color:black">Cont&aacute;ctenos</a> | 
			<a href="'.PATH.'/register" target="_blank" rel="noopener noreferrer" style="color:black">Registrarme</a> | <a href="'.PATH.'/index" target="_blank" rel="noopener noreferrer" style="color:black">&iquest;Contrase&ntilde;a olvidada?</a> 
         </div>
         <div style="color:black; margin-top:9px; font-size:11px; margin-bottom:9px">&copy; <span data-markjs="true" class="mark1r5zpt0nk" style="background-color: yellow; color: black;">'.$yezz['hotelname'].'</span> 2017-2018 </div>
      </td>
   </tr>
</tbody>';

$cabeceras  = 'MIME-Version: 1.0' . "\r\n";
$cabeceras .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$cabeceras .= 'To: '.$user['username'].' <'.$mail.'>' . "\r\n";
$cabeceras .= 'From: '.$yezz['hotelname'].' <pixeled.soporte@gmail.com>' . "\r\n";

mail($mail, $titulo, $mensaje, $cabeceras);

	$db->query("UPDATE users SET mail = '".$Functions->FilterText($mail)."', email_verificado = '0' WHERE id = '".$user['id']."'");
	
	
	
   }
   
   

   }elseif($type == 'mail2'){
   
   $code = $Functions->FilterText($_POST['code']);
   
   $ru = $db->query("SELECT * FROM users WHERE code_forgot = '{$code}'");
   $u = $ru->fetch_array();
   
   if($code == ''){
   $json["reponse"] = 'erreur';
   $json["message"] = 'Campos vacíos, inténtalo de nuevo.';
   	echo json_encode($json);
   
   }elseif($user['code_forgot'] !== $code){
   $json["reponse"] = 'erreur';
   $json["message"] = 'Código incorrecto, inténtalo de nuevo.';
   	echo json_encode($json);
   
   }else{
   
   $json["reponse"] = 'ok';
   $json["message"] = 'Tu dirección de correo electrónico ha sido confirmada.';
   	echo json_encode($json);
   	$db->query("UPDATE users SET email_verificado = '1' WHERE id = '".$user['id']."'");

   }
   }
   
   
   
   }
   
   
   
   
   ?>