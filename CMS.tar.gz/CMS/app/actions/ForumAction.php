<?php
   ob_start();
   require_once '../../global.php';
   ob_end_flush();	
   
   $users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
   $user = $users->fetch_array();
   
   if($_POST)
   {

   $type = $Functions->FilterText($_POST['type']);
   $id = $Functions->FilterText($_POST['threadid']);
   
   
   
   if($type == 'deletepostid'){
	   
	   $json["reponse"] = 'deletepostid';
   	echo json_encode($json);
	
	   $db->query("DELETE FROM cms_comments_forum WHERE id = '".$id."'");

    }elseif($type == 'close'){
	   
  $security = $db->query("SELECT * FROM cms_forum WHERE id = '".$id."'");
  $sec = $security->fetch_array();
  
  if($sec['cerrado'] == 1){
	   $json["reponse"] = 'close';
	  $json["type"] = 'cadd';
   	echo json_encode($json);
  $db->query("UPDATE cms_forum SET cerrado = '0' WHERE id = '".$id."'"); 
  }elseif($sec['cerrado'] == 0){
	  $json["reponse"] = 'close';
	   $json["type"] = 'crem';
   	echo json_encode($json);
  $db->query("UPDATE cms_forum SET cerrado = '1' WHERE id = '".$id."'"); 
	  }
	   
	 
	
    }elseif($type == 'delete'){
 
  
  $json["reponse"] = 'delete';
   	echo json_encode($json);
	
	   $db->query("DELETE FROM cms_forum WHERE id = '".$id."'");
	    $db->query("DELETE FROM cms_likes_publi WHERE publi_id = '".$id."' AND page = '2'");

	   
	 
	
    }elseif($type == 'fijo'){
	   
  $security = $db->query("SELECT * FROM cms_forum WHERE id = '".$id."'");
  $sec = $security->fetch_array();
  
  if($sec['fijo'] == 1){
	   $json["reponse"] = 'fijo';
	  $json["type"] = 'f1';
   	echo json_encode($json);
  $db->query("UPDATE cms_forum SET fijo = '0' WHERE id = '".$id."'"); 
  }elseif($sec['fijo'] == 0){
	  $json["reponse"] = 'fijo';
	   $json["type"] = 'f2';
   	echo json_encode($json);
  $db->query("UPDATE cms_forum SET fijo = '1' WHERE id = '".$id."'"); 
	  }
	   
	 
	
    }
    
    
   
   }
   
   ?>