<?php
   ob_start();
   require_once '../../global.php';
   
   $users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
   $user = $users->fetch_array();
   
   $q = $Functions->FilterText($_GET[username]);
   
   
   $result = $db->query("SELECT * FROM messenger_friendships WHERE user_one_id = '".$user['id']."' OR user_two_id = '".$user['id']."' ORDER BY id DESC");
   while($data = $result->fetch_array()){
   if($data['user_one_id'] == $user['id']){$friendv = $data['user_two_id'];}
   elseif($data['user_two_id'] == $user['id']){$friendv = $data['user_one_id'];}
   
   $sql = $db->query("SELECT * FROM users WHERE id = '".$friendv."' AND username LIKE '%".$q."%' ORDER BY username ASC"); 
   
   while($fila = $sql->fetch_array()){
    
    if($sql->num_rows == 0){
   
   
   }else{
   ?>
<div onclick="GetChat('<?php echo $fila['id']; ?>');" id="stream12">
   <div id="stream13" style="background:url(<?php echo AVATARIMAGE . $fila['look']; ?>&gesture=sml);"></div>
   <div id="stream14">
      <?php echo $fila['username']; ?> 
   </div>
   <div id="stream15" style="background:#<?php echo $online; ?>"></div>
   <?php
      $userss = $db->query("SELECT * FROM cms_message WHERE for_id = '".$user['id']."' AND visto = '0'");
      $userinfo = $userss->fetch_array();
      if($userinfo['from_id'] == $fila['id']){
        $noti = 'block';
       }else{
        $noti = 'none';}
      ?>
   <div class="msgnotif<?php echo $fila['id']; ?>" id="stream18" style="display:<?php echo $noti; ?>;"></div>
</div>
<?php }}}  ?>