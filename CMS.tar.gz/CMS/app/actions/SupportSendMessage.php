<?php
   ob_start();
   require_once '../../global.php';
   ob_end_flush();	
   
   $users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
   $user = $users->fetch_array();
   
   if($_POST)
   {
    $message = $Functions->FilterText2($_POST['message']);
    $ticketid = $Functions->FilterText($_POST['ticketid']);
   
   
   
   
   $rticket = $db->query("SELECT * FROM cms_tickets WHERE id = '".$ticketid."'");
   $ticketinfo = $rticket->fetch_array();
   
   
   
   if($rticket->num_rows == 0){
   $json["type"] = 'error';
   	echo json_encode($json);
    
    }else{
     
    $json["type"] = 'success';
   	echo json_encode($json);
    
    $dbQuery= array();
                    $dbQuery['username'] = $user['username'];
                    $dbQuery['content'] = $message;
                    $dbQuery['category'] = $ticketinfo['category'];
                    $dbQuery['time'] = time();
                    $dbQuery['type'] = "respuesta";
                    $dbQuery['priority'] = $$ticketinfo['priority'];
                    $dbQuery['title'] = $ticketinfo['title'];
                    $dbQuery['posted_in'] = $ticketid;
                    $query = $db->insertInto('cms_tickets', $dbQuery);
   		$db->query("UPDATE cms_tickets SET abierto = '0' WHERE id = '".$ticketid."'");  
    
    }
    
    
   
   }
   
   ?>