<?php
   ob_start();
   require_once '../../global.php';
   ob_end_flush();	
   
   $users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
   $user = $users->fetch_array();
   
   if($_POST)
   {
    $titre = $Functions->FilterText($_POST['titre']);
   $categorie = $Functions->FilterText($_POST['categorie']);
   $message = $Functions->FilterTextF($_POST['message']);
   $type = $Functions->FilterText($_POST['type']);
   $id = $Functions->FilterText($_POST['id']);
   
   
   
   if($type == 'new'){
   $security = $db->query("SELECT * FROM cms_forum WHERE username = '".$user['username']."' ORDER by id DESC");
   $sec = $security->fetch_array();
   
   
   
   if($titre == '' || $message == ''){
   $json["reponse"] = 'erreur';
   $json["message"] = 'Por favor complete los campos vacíos.';
   	echo json_encode($json);
    
    }elseif(strlen($message) < 50){
   $json["reponse"] = 'erreur';
   $json["message"] = 'Su tema debe tener al menos 50 caracteres de largo.';
   	echo json_encode($json);
    
    }elseif(strlen($titre) < 10){
   $json["reponse"] = 'erreur';
   $json["message"] = 'El título de su tema debe tener al menos 10 caracteres de largo.';
   	echo json_encode($json);
    
    }elseif($sec['time'] >= time() - 300){
   $json["reponse"] = 'erreur';
   $json["message"] = 'Debes esperar 5 min. para crear otro tema.';
   	echo json_encode($json);
    
    }else{
     
    $json["reponse"] = 'ok';
    
    $dbQuery= array();
          $dbQuery['username'] = $user['username'];
          $dbQuery['title'] = $titre;
		  $dbQuery['content'] = $message;
		  $dbQuery['category'] = $categorie;
		  $dbQuery['link'] = $Functions->FilterTextLink($titre);
		  $dbQuery['time'] = time();
		  $dbQuery['timec'] = time();
          $query = $db->insertInto('cms_forum', $dbQuery);
    
	$resultf = $db->query("SELECT * FROM cms_forum WHERE username = '".$user['username']."' ORDER BY id DESC LIMIT 1");
    $foruminfo = $resultf->fetch_array();
		$json["id"] = $foruminfo['id'].'-'.$foruminfo['link'];
	echo json_encode($json);
    }
    
    }elseif($type == 'edit'){
		
		
		$db->query("UPDATE cms_forum SET title = '".$titre."', content = '".$message."', link = '".$Functions->FilterTextLink($titre)."', timec = '".time()."', time = '".time()."' WHERE id = '".$id."'");
		$resultf = $db->query("SELECT * FROM cms_forum WHERE id = '".$id."'");
    $foruminfo = $resultf->fetch_array();
	$json["reponse"] = 'ok';
   $json["id"] = $foruminfo['id'].'-'.$foruminfo['link'];
	echo json_encode($json);
   }
   
   
   }
   ?>