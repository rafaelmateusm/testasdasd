<?php
   ob_start();
   require_once '../../global.php';
   ob_end_flush();	
   
   $users = $db->query("SELECT * FROM users WHERE username = '{$_SESSION['username']}' AND password = '{$_SESSION['password']}'");
   $user = $users->fetch_array();
   
   if($_POST)
   {
    $message = $Functions->FilterText2($_POST['message']);
    $threadid = $Functions->FilterText($_POST['threadid']);
   
   
   
   
   $result = $db->query("SELECT * FROM cms_comments_forum WHERE posted_in = '".$threadid."' AND username = '".$user['username']."'");
   $info = $result->fetch_array();
   
    $rf = $db->query("SELECT * FROM cms_forum WHERE id = '".$threadid."'");
     $forum = $rf->fetch_array();
	 
	 $r = $db->query("SELECT * FROM cms_comments_forum WHERE posted_in = '".$threadid."' AND username = '".$user['username']."' ORDER BY id DESC");
     $i = $r->fetch_array();
   
   
   if($info['time'] >= time() - 180){
   $json["reponse"] = 'erreur';
   $json["message"] = 'Debes esperar 3 min. para enviar otro mensaje.';
   	echo json_encode($json);
    
    }else{
     
    $json["reponse"] = 'ok';
	$json["id"] = $i['id'];
   	echo json_encode($json);
    
    $dbQuery= array();
          $dbQuery['username'] = $user['username'];
          $dbQuery['commentary'] = $message;
          $dbQuery['posted_in'] = $threadid;
		  $dbQuery['category'] = $forum['category'];
          $dbQuery['time'] = time();
          $query = $db->insertInto('cms_comments_forum', $dbQuery);
		  
		  $db->query("UPDATE cms_forum SET timec = '".time()."' WHERE id = '{$threadid}'");
		  $db->query("UPDATE cms_views SET type = '0' WHERE posted_in = '{$threadid}'");
    
    }
    
    
   
   }
   
   ?>